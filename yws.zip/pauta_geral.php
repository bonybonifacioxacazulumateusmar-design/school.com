<?php
include 'config.php';
include_once 'permissoes.php';
if (!isset($_SESSION['user'])) { header("Location: login.php"); exit; }

// Verificar permissão
if (!tem_permissao('pauta_geral')) {
    die("<script>alert('Acesso negado!'); window.location='home.php';</script>");
}

$cargo = $_SESSION['user']['cargo'] ?? '';
$id_prof = $_SESSION['user']['id'] ?? 0;

// Se for professor, filtra só pelas turmas dele
$where = ($cargo === 'Professor') ? "WHERE t.id_professor = $id_prof" : "";

// Buscar TODOS os níveis
$niveis = $conn->query("SELECT * FROM niveis ORDER BY id ASC")->fetchAll();

// Buscar alunos com seus níveis
$sql = "SELECT a.id, a.nome, n.nome_nivel, n.id as nivel_id, t.nome_turma, t.id as turma_id
        FROM alunos a
        JOIN niveis n ON a.nivel_id = n.id
        JOIN turmas t ON t.id_nivel = n.id
        $where
        ORDER BY n.id ASC, a.nome ASC";
$alunos = $conn->query($sql)->fetchAll();

// Buscar todas as avaliações
$avals_sql = "SELECT av.id_aluno, av.tipo_avaliacao, av.nota, av.nota_maxima
              FROM avaliacoes av
              JOIN alunos a ON av.id_aluno = a.id
              JOIN niveis n ON a.nivel_id = n.id
              JOIN turmas t ON t.id_nivel = n.id
              $where
              ORDER BY av.id_aluno, av.data_avaliacao";
$avals_stmt = $conn->query($avals_sql);
$avaliacoes = $avals_stmt->fetchAll();

// Agrupar avaliações por aluno
$notas_por_aluno = [];
foreach ($avaliacoes as $av) {
    $notas_por_aluno[$av['id_aluno']][] = $av;
}

// Agrupar alunos por nível
$alunos_por_nivel = [];
foreach ($alunos as $al) {
    $alunos_por_nivel[$al['nivel_id']]['nome'] = $al['nome_nivel'];
    $alunos_por_nivel[$al['nivel_id']]['alunos'][] = $al;
}

function calcular_media_pauta($notas) {
    if (empty($notas)) return 0;
    return array_sum($notas) / count($notas);
}
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Pauta Geral - YWS</title>
    <style>
        @page { size: landscape; margin: 1cm; }
        body { font-family: 'Times New Roman', Times, serif; font-size: 9px; margin: 0; padding: 10px; background: #f5f5f5; }
        .header-instituicao { text-align: center; border-bottom: 3px double #0D47A1; padding-bottom: 10px; margin-bottom: 15px; background: white; padding: 15px; border-radius: 6px; }
        .header-instituicao h1 { font-size: 20px; margin: 5px 0; text-transform: uppercase; letter-spacing: 2px; color: #0D47A1; }
        .header-instituicao h2 { font-size: 12px; margin: 0; letter-spacing: 3px; font-weight: normal; color: #333; }
        .titulo-pauta { text-align: center; font-size: 18px; font-weight: bold; margin: 15px 0; text-decoration: underline; color: #0D47A1; }
        .info-doc { text-align: center; font-size: 11px; margin-bottom: 15px; color: #666; }
        .nivel-separator { background: linear-gradient(135deg, #0D47A1, #1565C0); color: white; font-weight: bold; font-size: 13px; padding: 8px 15px; margin-top: 25px; border-radius: 6px 6px 0 0; display: flex; justify-content: space-between; align-items: center; }
        .nivel-separator .total-alunos { background: rgba(255,255,255,0.2); padding: 3px 10px; border-radius: 12px; font-size: 11px; }
        table { width: 100%; border-collapse: collapse; margin-bottom: 0; background: white; }
        th, td { border: 1px solid #000; padding: 3px 4px; text-align: center; vertical-align: middle; font-size: 8px; }
        th { background-color: #f0f0f0; font-weight: bold; font-size: 7px; }
        .num-col { width: 22px; }
        .nome-col { width: 130px; text-align: left; padding-left: 4px !important; }
        .nota-col { width: 28px; }
        .media-col { width: 32px; font-weight: bold; background: #fff9c4; }
        .status-col { width: 55px; }
        .assinaturas { margin-top: 40px; display: flex; justify-content: space-between; }
        .assinatura { width: 30%; text-align: center; border-top: 1px solid #000; padding-top: 5px; font-size: 10px; }
        .legenda { margin-top: 20px; font-size: 8px; line-height: 1.5; background: white; padding: 10px; border-radius: 6px; border-left: 3px solid #0D47A1; }
        .resumo-final { margin-top: 30px; background: white; border: 2px solid #0D47A1; padding: 15px; border-radius: 6px; }
        .resumo-final h3 { margin: 0 0 10px 0; font-size: 14px; text-align: center; color: #0D47A1; }
        .resumo-final table { margin-top: 5px; }
        .resumo-final th { background: #0D47A1; color: white; }
        .total-nivel { background: #e3f2fd; font-weight: bold; }
        @media print { .no-print { display: none; } body { padding: 0; background: white; } }
    </style>
</head>
<body>
    <div class="no-print" style="text-align:center; margin-bottom:15px; padding:10px; background:white; border-radius:6px;">
        <button onclick="window.print()" style="padding:10px 20px; background:#0D47A1; color:white; border:none; cursor:pointer; font-size:14px; border-radius:4px;">🖨️ Imprimir Pauta Geral</button>
        <a href="home.php" style="margin-left:10px; padding:10px 20px; background:#666; color:white; text-decoration:none; border-radius:4px;">← Voltar ao Início</a>
    </div>

    <div class="header-instituicao">
        <img src="logo.png" alt="Logo" style="max-width:80px;" onerror="this.style.display='none'">
        <h1>THE YOUNG WISE SCHOOL</h1>
        <h2>CENTRO DE FORMAÇÃO</h2>
    </div>

    <div class="titulo-pauta">PAUTA GERAL DE AVALIAÇÕES</div>
    <div class="info-doc">
        Ano Lectivo: <?= date('Y') ?> | Documento: <?= $cargo === 'Professor' ? 'Pauta do Professor' : 'Pauta Geral da Instituição' ?> | 
        <?php if ($cargo === 'Professor'): ?>
            Professor: <?= htmlspecialchars($_SESSION['user']['nome']) ?>
        <?php else: ?>
            Gerado por: <?= htmlspecialchars($_SESSION['user']['nome']) ?> (<?= htmlspecialchars($cargo) ?>)
        <?php endif; ?>
    </div>

    <?php if (empty($alunos_por_nivel)): ?>
        <p style="text-align:center; padding:30px; background:white; border-radius:6px;">Nenhum aluno encontrado.</p>
    <?php else: 
        $total_geral_aprovados = 0;
        $total_geral_reprovados = 0;
        $total_geral_alunos = 0;
        
        foreach ($niveis as $nivel):
            $nivel_id = $nivel['id'];
            $nivel_nome = $nivel['nome_nivel'];
            
            if (!isset($alunos_por_nivel[$nivel_id])) continue;
            
            $alunos_nivel = $alunos_por_nivel[$nivel_id]['alunos'];
            $aprovados_nivel = 0;
            $reprovados_nivel = 0;
    ?>
    
    <div class="nivel-separator">
        <span>📚 NÍVEL: <?= strtoupper(htmlspecialchars($nivel_nome)) ?></span>
        <span class="total-alunos"><?= count($alunos_nivel) ?> alunos</span>
    </div>

    <table>
        <thead>
            <tr>
                <th class="num-col">Nº</th>
                <th class="nome-col">Nome do Aluno</th>
                <th>A1 E.</th><th>A2 E.</th><th>A3 E.</th><th>A4 E.</th>
                <th>A1 O.</th><th>A2 O.</th><th>A3 O.</th><th>A4 O.</th>
                <th>D1</th><th>D2</th><th>D3</th><th>D4</th>
                <th>M.D</th><th>M.E</th><th>M.O</th>
                <th>Ex.E</th><th>Ex.O</th>
                <th>Mg.A</th><th>Mg.E</th>
                <th>Obs.</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $num = 1;
            foreach ($alunos_nivel as $aluno): 
                $notas = $notas_por_aluno[$aluno['id']] ?? [];
                
                $escritas = []; $orais = []; $ditados = [];
                $exame_escrito = 0; $exame_oral = 0;
                
                foreach ($notas as $n) {
                    $tipo = $n['tipo_avaliacao'];
                    if ($tipo === 'avaliacao_escrita' || $tipo === 'avaliacao') $escritas[] = $n['nota'];
                    elseif ($tipo === 'avaliacao_oral') $orais[] = $n['nota'];
                    elseif ($tipo === 'ditado') $ditados[] = $n['nota'];
                    elseif ($tipo === 'exame_escrito') $exame_escrito = $n['nota'];
                    elseif ($tipo === 'exame_oral') $exame_oral = $n['nota'];
                }
                
                $media_ditados = calcular_media_pauta($ditados);
                $media_escritas = calcular_media_pauta($escritas);
                $media_orais = calcular_media_pauta($orais);
                
                $todas_avaliacoes = array_merge($escritas, $orais, $ditados);
                $mg_a = calcular_media_pauta($todas_avaliacoes);
                
                $exames = [];
                if ($exame_escrito > 0) $exames[] = $exame_escrito;
                if ($exame_oral > 0) $exames[] = $exame_oral;
                $mg_e = calcular_media_pauta($exames);
                
                $media_final = ($mg_a + $mg_e) / 2;
                $status = $media_final >= 10 ? 'Aprovado' : 'Reprovado';
                
                if ($status === 'Aprovado') $aprovados_nivel++; else $reprovados_nivel++;
            ?>
            <tr>
                <td class="num-col"><?= str_pad($num++, 2, '0', STR_PAD_LEFT) ?></td>
                <td class="nome-col"><strong><?= htmlspecialchars($aluno['nome']) ?></strong></td>
                
                <td class="nota-col"><?= $escritas[0] ?? '-' ?></td>
                <td class="nota-col"><?= $escritas[1] ?? '-' ?></td>
                <td class="nota-col"><?= $escritas[2] ?? '-' ?></td>
                <td class="nota-col"><?= $escritas[3] ?? '-' ?></td>
                
                <td class="nota-col"><?= $orais[0] ?? '-' ?></td>
                <td class="nota-col"><?= $orais[1] ?? '-' ?></td>
                <td class="nota-col"><?= $orais[2] ?? '-' ?></td>
                <td class="nota-col"><?= $orais[3] ?? '-' ?></td>
                
                <td class="nota-col"><?= $ditados[0] ?? '-' ?></td>
                <td class="nota-col"><?= $ditados[1] ?? '-' ?></td>
                <td class="nota-col"><?= $ditados[2] ?? '-' ?></td>
                <td class="nota-col"><?= $ditados[3] ?? '-' ?></td>
                
                <td class="media-col"><?= $media_ditados > 0 ? number_format($media_ditados, 1) : '-' ?></td>
                <td class="media-col"><?= $media_escritas > 0 ? number_format($media_escritas, 1) : '-' ?></td>
                <td class="media-col"><?= $media_orais > 0 ? number_format($media_orais, 1) : '-' ?></td>
                
                <td class="nota-col"><?= $exame_escrito > 0 ? number_format($exame_escrito, 1) : '-' ?></td>
                <td class="nota-col"><?= $exame_oral > 0 ? number_format($exame_oral, 1) : '-' ?></td>
                
                <td class="media-col"><?= $mg_a > 0 ? number_format($mg_a, 1) : '-' ?></td>
                <td class="media-col"><?= $mg_e > 0 ? number_format($mg_e, 1) : '-' ?></td>
                
                <td class="status-col" style="font-weight:bold; color:<?= $status === 'Aprovado' ? '#2E7D32' : '#D32F2F' ?>;"><?= $status ?></td>
            </tr>
            <?php endforeach; ?>
            
            <tr class="total-nivel">
                <td colspan="2">TOTAL DO NÍVEL</td>
                <td colspan="16"></td>
                <td style="color:#2E7D32;"><?= $aprovados_nivel ?> Apr.</td>
                <td style="color:#D32F2F;"><?= $reprovados_nivel ?> Rep.</td>
                <td></td>
            </tr>
        </tbody>
    </table>
    
    <?php 
            $total_geral_aprovados += $aprovados_nivel;
            $total_geral_reprovados += $reprovados_nivel;
            $total_geral_alunos += count($alunos_nivel);
        endforeach; 
    endif; // <--- AQUI ESTAVA FALTANDO O FECHAMENTO!
    ?>

    <!-- RESUMO GERAL FINAL -->
    <div class="resumo-final">
        <h3>📊 RESUMO GERAL DA INSTITUIÇÃO</h3>
        <table>
            <tr>
                <th>Total de Alunos</th>
                <th>Total Aprovados</th>
                <th>Total Reprovados</th>
                <th>% de Aprovação</th>
            </tr>
            <tr>
                <td style="font-size:14px; font-weight:bold;"><?= $total_geral_alunos ?></td>
                <td style="font-size:14px; font-weight:bold; color:#2E7D32;"><?= $total_geral_aprovados ?></td>
                <td style="font-size:14px; font-weight:bold; color:#D32F2F;"><?= $total_geral_reprovados ?></td>
                <td style="font-size:14px; font-weight:bold;">
                    <?= $total_geral_alunos > 0 ? number_format(($total_geral_aprovados / $total_geral_alunos) * 100, 1) : 0 ?>%
                </td>
            </tr>
        </table>
    </div>

    <div class="legenda">
        <strong>Legenda:</strong><br>
        A1-A4 E. = Avaliações Escritas | A1-A4 O. = Avaliações Orais | D1-D4 = Ditados<br>
        M.D = Média dos Ditados | M.E = Média das Escritas | M.O = Média das Orais<br>
        Ex.E = Exame Escrito | Ex.O = Exame Oral | Mg.A = Média Geral das Avaliações | Mg.E = Média Geral dos Exames<br>
        Obs. = Aprovado/Reprovado | Critério de Aprovação: Média Final ≥ 10 valores
    </div>

    <div class="assinaturas">
        <div class="assinatura">
            <br>
            <strong>Direção Pedagógica</strong><br>
            Assinatura: _______________
        </div>
        <div class="assinatura">
            <br>
            <strong>CEO</strong><br>
            Assinatura: _______________
        </div>
        <div class="assinatura">
            <br>
            <strong>Professor(a) Responsável</strong><br>
            Assinatura: _______________
        </div>
    </div>

    <p style="text-align:center; font-size:8px; margin-top:20px; color:#666;">
        Documento gerado em <?= date('d/m/Y H:i') ?> pelo Sistema YWS - The Young Wise School
    </p>
</body>
</html>