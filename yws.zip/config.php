<?php
$host = 'localhost';
$db   = 'yws_db';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
];

try {
    $conn = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    die("Erro na conexão: " . $e->getMessage());
}

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ===== FUNÇÕES GLOBAIS =====
if (!function_exists('hash_senha')) {
    function hash_senha($senha) {
        return password_hash($senha, PASSWORD_DEFAULT);
    }
}

if (!function_exists('verificar_senha')) {
    function verificar_senha($senha, $hash) {
        return password_verify($senha, $hash);
    }
}

if (!function_exists('limpar')) {
    function limpar($texto) {
        return htmlspecialchars(trim($texto), ENT_QUOTES, 'UTF-8');
    }
}

if (!function_exists('pode_excluir')) {
    function pode_excluir() {
        if (!isset($_SESSION['user'])) return false;
        $cargo = $_SESSION['user']['cargo'] ?? '';
        return in_array($cargo, ['CEO', 'Coordenador Geral', 'Admin']);
    }
}

if (!function_exists('formatar_moeda')) {
    function formatar_moeda($valor) {
        return number_format($valor, 2, ',', '.') . ' Kz';
    }
}
?>