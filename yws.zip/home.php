<?php
include 'config.php';
include_once 'permissoes.php';
if (!isset($_SESSION['user'])) { header("Location: login.php"); exit; }

// Redirecionar quem não tem acesso ao Início
if (!tem_permissao('inicio')) {
    // Redirecionar para a primeira página disponível
    if (tem_permissao('estatistica_geral')) {
        header("Location: dashboard.php");
    } elseif (tem_permissao('avaliacoes')) {
        header("Location: avaliacoes.php");
    } elseif (tem_permissao('cadastro_alunos')) {
        header("Location: cadastro_alunos.php");
    } else {
        header("Location: avisos.php");
    }
    exit;
}

$nome = $_SESSION['user']['nome'] ?? '';
$cargo = $_SESSION['user']['cargo'] ?? '';
// ... resto do código do home.php
?>