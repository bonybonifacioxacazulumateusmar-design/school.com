<?php
include 'config.php';
if (!isset($_SESSION['user'])) { header("Location: login.php"); exit; }

$id = $_GET['id'] ?? 0;
$stmt = $conn->prepare("SELECT * FROM saidas WHERE id = ?");
$stmt->execute([$id]);
$saida = $stmt->fetch();

if (!$saida) die("Comprovativo não encontrado.");
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Comprovativo de Saída - YWS</title>
    <style>
        body { font-family: 'Times New Roman', serif; padding: 20px; background: #eee; }
        .via { background: white; border: 2px solid #333; padding: 20px; margin-bottom: 30px; position: relative; }
        .corte { border-top: 2px dashed #999; margin: 30px 0; text-align: center; color: #666; font-size: 12px; }
        .header-inst { text-align: center; border-bottom: 2px solid #000; padding-bottom: 10px; margin-bottom: 15px; }
        .header-inst h1 { font-size: 20px; margin: 5px 0; text-transform: uppercase; letter-spacing: 2px; }
        .header-inst h2 { font-size: 12px; margin: 0; letter-spacing: 3px; }
        .titulo-doc { text-align: center; font-weight: bold; font-size: 18px; margin: 15px 0; text-decoration: underline; }
        .info { line-height: 1.8; font-size: 14px; margin-bottom: 20px; }
        .valor-destaque { font-size: 20px; font-weight: bold; text-align: center; margin: 15px 0; border: 1px solid #000; padding: 10px; }
        .assinaturas { display: flex; justify-content: space-between; margin-top: 50px; }
        .assinatura { width: 40%; text-align: center; border-top: 1px solid #000; padding-top: 5px; font-size: 13px; }
        @media print { body { background: white; padding: 0; } .no-print { display: none; } }
    </style>
</head>
<body>
    <div class="no-print" style="text-align:center; margin-bottom:20px;">
        <button onclick="window.print()" style="padding:10px 20px; background:#0D47A1; color:white; border:none; cursor:pointer;">🖨️ Imprimir Comprovativo</button>
        <a href="financeiro_saidas.php" style="padding:10px 20px; background:#666; color:white; text-decoration:none;">Voltar</a>
    </div>

    <?php 
    $vias = ['VIA DO EMISSOR (Fica na Escola)', 'VIA DO RECEPTOR (Entregue ao Beneficiário)'];
    foreach ($vias as $via): 
    ?>
    <div class="via">
        <div style="position:absolute; top:10px; right:10px; font-size:11px; font-weight:bold; border:1px solid #000; padding:3px 8px;"><?= $via ?></div>
        <div class="header-inst">
            <h1>THE YOUNG WISE SCHOOL</h1>
            <h2>CENTRO DE FORMAÇÃO</h2>
        </div>
        <div class="titulo-doc">COMPROVATIVO DE SAída / PAGAMENTO Nº <?= str_pad($saida['id'], 4, '0', STR_PAD_LEFT) ?></div>
        
        <div class="info">
            <p><strong>Data:</strong> <?= date('d/m/Y', strtotime($saida['data'])) ?></p>
            <p><strong>Descrição / Motivo:</strong> <?= htmlspecialchars($saida['descricao']) ?></p>
            <p><strong>Tipo de Despesa:</strong> <?= strtoupper(str_replace('_', ' ', $saida['tipo'])) ?></p>
        </div>

        <div class="valor-destaque">
            VALOR PAGO: <?= number_format($saida['valor'], 2, ',', '.') ?> Kz
        </div>

        <p style="font-size:12px; text-align:center; margin-top:30px;">Declaro ter recebido a quantia acima mencionada, dando plena quitação.</p>

        <div class="assinaturas">
            <div class="assinatura">
                <br><br>
                <strong>Quem Entrega (Emissor)</strong><br>
                Tesouraria YWS
            </div>
            <div class="assinatura">
                <br><br>
                <strong>Quem Recebe (Receptor)</strong><br>
                Nome: _______________________<br>
                BI: ________________________
            </div>
        </div>
    </div>
    <div class="corte no-print">------------------------- Corte aqui para separar as vias -------------------------</div>
    <?php endforeach; ?>
</body>
</html>