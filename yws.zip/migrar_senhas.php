<?php
include 'config.php';

echo "<h2>Migração de Senhas para Hash Seguro</h2>";

// Migrar funcionários
$stmt = $conn->query("SELECT id, senha FROM funcionarios WHERE LENGTH(senha) < 40");
while ($row = $stmt->fetch()) {
    $nova = hash_senha($row['senha']);
    $conn->prepare("UPDATE funcionarios SET senha = ? WHERE id = ?")->execute([$nova, $row['id']]);
    echo "Funcionário ID {$row['id']} atualizado.<br>";
}

// Migrar alunos
$stmt = $conn->query("SELECT id, senha FROM alunos WHERE LENGTH(senha) < 40");
while ($row = $stmt->fetch()) {
    $nova = hash_senha($row['senha']);
    $conn->prepare("UPDATE alunos SET senha = ? WHERE id = ?")->execute([$nova, $row['id']]);
    echo "Aluno ID {$row['id']} atualizado.<br>";
}

echo "<hr><h3>✅ Migração concluída! DELETE este arquivo agora por segurança.</h3>";
?>