<?php
include 'config.php';

if (!isset($_SESSION['user'])) {
    header("Location: login.php"); exit;
}

$tipo_user = $_SESSION['user']['tipo'];
$id_user = $_SESSION['user']['id'];

// Buscar avisos relevantes
if ($tipo_user === 'aluno') {
    // Buscar nível e turma do aluno
    $stmt = $conn->prepare("SELECT a.nivel_id, t.id as turma_id FROM alunos a LEFT JOIN turmas t ON t.id_nivel = a.nivel_id WHERE a.id = ?");
    $stmt->execute([$id_user]);
    $dados = $stmt->fetch();
    $nivel_id = $dados['nivel_id'] ?? null;
    $turma_id = $dados['turma_id'] ?? null;
    
    $sql = "SELECT a.*, f.nome as criador 
            FROM avisos a
            LEFT JOIN funcionarios f ON a.criado_por = f.id
            WHERE a.status = 'ativo'
            AND (a.tipo = 'geral' 
                 OR (a.tipo = 'nivel' AND a.destinatario_id = $nivel_id)
                 OR (a.tipo = 'turma' AND a.destinatario_id = $turma_id)
                 OR (a.tipo = 'individual' AND a.destinatario_id = $id_user))
            ORDER BY a.data_criacao DESC";
} else {
    $sql = "SELECT a.*, f.nome as criador 
            FROM avisos a
            LEFT JOIN funcionarios f ON a.criado_por = f.id
            WHERE a.status = 'ativo' AND a.tipo = 'funcionarios'
            ORDER BY a.data_criacao DESC";
}

$avisos = $conn->query($sql)->fetchAll();

// Contar não lidos
$nao_lidos = $conn->query("SELECT COUNT(*) FROM avisos WHERE lido='nao' AND status='ativo'")->fetchColumn();
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Avisos - YWS</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .aviso-item {
            background: white;
            padding: 20px;
            margin: 15px 0;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            border-left: 5px solid #0D47A1;
        }
        .aviso-item.urgente { border-left-color: #D32F2F; background: #ffebee; }
        .aviso-item.nao-lido { background: #e3f2fd; }
        .badge-prioridade {
            display: inline-block;
            padding: 3px 10px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: bold;
            color: white;
            margin-right: 5px;
        }
    </style>
</head>
<body>
<div class="header">
    <h1>The Young Wise School - YWS</h1>
    <p style="font-style: italic; color: #ffcc00;">"More than just speak English"</p>
    <p>Avisos e Comunicados</p>
</div>

<div class="container">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
        <h2>📢 Avisos (<?= count($avisos) ?>)</h2>
        <?php if ($nao_lidos > 0): ?>
            <span style="background: #D32F2F; color: white; padding: 5px 15px; border-radius: 20px; font-weight: bold;">
                <?= $nao_lidos ?> novo(s)
            </span>
        <?php endif; ?>
    </div>

    <?php if (empty($avisos)): ?>
        <div class="card" style="text-align: center; padding: 40px;">
            <p style="font-size: 18px; color: #666;"> Nenhum aviso no momento</p>
        </div>
    <?php else: ?>
        <?php foreach ($avisos as $av): 
            $classe = '';
            if ($av['prioridade'] === 'urgente') $classe = 'urgente';
            if ($av['lido'] === 'nao') $classe .= ' nao-lido';
        ?>
        <div class="aviso-item <?= $classe ?>">
            <div style="display: flex; justify-content: space-between; align-items: start;">
                <div>
                    <h3 style="color: #0D47A1; margin: 0 0 10px 0;"><?= htmlspecialchars($av['titulo']) ?></h3>
                    <div style="font-size: 12px; color: #666; margin-bottom: 10px;">
                        <span class="badge-prioridade" style="background: <?= $av['prioridade'] === 'urgente' ? '#D32F2F' : ($av['prioridade'] === 'alta' ? '#F57C00' : '#0D47A1') ?>;">
                            <?= strtoupper($av['prioridade']) ?>
                        </span>
                        Por: <?= htmlspecialchars($av['criador']) ?> | 
                        <?= date('d/m/Y H:i', strtotime($av['data_criacao'])) ?>
                    </div>
                </div>
                <?php if ($av['lido'] === 'nao'): ?>
                    <a href="?marcar_lido=<?= $av['id'] ?>" class="btn-yws" style="padding: 5px 10px; font-size: 12px;">✅ Marcar como Lido</a>
                <?php endif; ?>
            </div>
            <p style="line-height: 1.6; margin: 15px 0;"><?= nl2br(htmlspecialchars($av['mensagem'])) ?></p>
        </div>
        <?php endforeach; ?>
    <?php endif; ?>

    <div style="text-align: center; margin-top: 30px;">
        <?php if ($tipo_user === 'aluno'): ?>
            <a href="portal_aluno.php" class="btn-yws"> Voltar ao Portal</a>
        <?php else: ?>
            <a href="dashboard.php" class="btn-yws">📊 Voltar ao Dashboard</a>
        <?php endif; ?>
    </div>
</div>
</body>
</html>