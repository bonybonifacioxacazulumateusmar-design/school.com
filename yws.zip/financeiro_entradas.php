<?php
include 'config.php';
if (!isset($_SESSION['user'])) { header("Location: login.php"); exit; }

// Exclusão
if (isset($_GET['excluir'])) {
    if (!pode_excluir()) {
        die("<script>alert('Apenas administradores podem excluir.'); window.history.back();</script>");
    }
    $conn->prepare("DELETE FROM entradas WHERE id = ?")->execute([$_GET['excluir']]);
    echo "<script>alert('Entrada excluída.'); window.location='financeiro_entradas.php';</script>";
    exit;
}

// Processar pagamento de PROPINA (com desconto)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao']) && $_POST['acao'] === 'pagar_propina') {
    try {
        $id_aluno = $_POST['id_aluno'];
        $mes = $_POST['mes'];
        $ano = date('Y');
        $valor_bruto = (float)$_POST['valor'];
        $desconto = (float)($_POST['desconto'] ?? 0);
        $valor_final = $valor_bruto - $desconto;
        $data = date('Y-m-d');
        $tipo_pagamento = $_POST['tipo_pagamento'] ?? 'propina';
        
        $stmt = $conn->prepare("SELECT nome FROM alunos WHERE id = ?");
        $stmt->execute([$id_aluno]);
        $aluno = $stmt->fetch();
        
        // Registrar entrada
        $descricao = $desconto > 0 ? "{$aluno['nome']} (com desconto de " . formatar_moeda($desconto) . ")" : $aluno['nome'];
        $conn->prepare("INSERT INTO entradas (tipo, origem, valor, data) VALUES (?, ?, ?, ?)")
             ->execute([$tipo_pagamento, $descricao, $valor_final, $data]);
        
        // Registrar histórico (sem campo tipo, apenas propinas_pagas)
        $conn->prepare("INSERT INTO propinas_pagas (id_aluno, mes, ano, valor_pago, data_pagamento) VALUES (?, ?, ?, ?, ?)")
             ->execute([$id_aluno, $mes, $ano, $valor_final, $data]);

        // 25% AUTOMÁTICO apenas para propinas
        if ($tipo_pagamento === 'propina') {
            $valor_financiador = $valor_final * 0.25;
            $conn->prepare("INSERT INTO saidas (tipo, descricao, valor, data) VALUES ('financiador_25%', ?, ?, ?)")
                 ->execute(["Repasse 25% - {$aluno['nome']} - $mes/$ano", $valor_financiador, $data]);
            $conn->prepare("INSERT INTO repasse_financiador (mes, ano, total_arrecadado, valor_25_porcento, status, data_repasse) VALUES (?, ?, ?, ?, 'pago', ?)")
                 ->execute([$mes, $ano, $valor_final, $valor_financiador, $data]);
        }
        
        $id_pagamento = $conn->lastInsertId();
        
        echo "<script>
            alert('✅ Pagamento registrado!');
            window.open('gerar_recibo.php?id=$id_pagamento&aluno=" . urlencode($aluno['nome']) . "&valor=$valor_final&mes=$mes&desconto=$desconto', '_blank');
            window.location='financeiro_entradas.php';
        </script>";
        exit;
    } catch (PDOException $e) {
        echo "<script>alert('❌ Erro: " . addslashes($e->getMessage()) . "'); window.history.back();</script>";
        exit;
    }
}

// Processar financiamento
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao']) && $_POST['acao'] === 'financiamento') {
    try {
        $descricao = $_POST['descricao'];
        $valor_parcela = $_POST['valor_parcela'];
        $numero_parcela = $_POST['numero_parcela'];
        $total_parcelas = $_POST['total_parcelas'];
        $data = date('Y-m-d');
        
        $conn->prepare("INSERT INTO financiamento (descricao, valor_total, valor_parcela, numero_parcela, total_parcelas, data_pagamento, status) VALUES (?, 300000.00, ?, ?, ?, ?, 'pago')")
             ->execute([$descricao, $valor_parcela, $numero_parcela, $total_parcelas, $data]);
        
        $conn->prepare("INSERT INTO entradas (tipo, origem, valor, data) VALUES ('financiamento', ?, ?, ?)")
             ->execute([$descricao, $valor_parcela, $data]);
        
        echo "<script>alert('✅ Parcela registrada! (Sem desconto de 25%)'); window.location='financeiro_entradas.php';</script>";
        exit;
    } catch (PDOException $e) {
        echo "<script>alert('Erro: " . addslashes($e->getMessage()) . "'); window.history.back();</script>";
        exit;
    }
}

// Buscar dados
$alunos = [];
$entradas = [];
$erro_tabela = false;

try {
    $alunos = $conn->query("SELECT a.id, a.nome, n.nome_nivel, n.valor_propina FROM alunos a LEFT JOIN niveis n ON a.nivel_id = n.id WHERE a.status='ativo' ORDER BY a.nome")->fetchAll();
    $entradas = $conn->query("SELECT * FROM entradas ORDER BY data DESC")->fetchAll();
    
    // Totais
    $total_entradas = $conn->query("SELECT COALESCE(SUM(valor),0) FROM entradas")->fetchColumn();
    $total_propinas = $conn->query("SELECT COALESCE(SUM(valor),0) FROM entradas WHERE tipo='propina'")->fetchColumn();
    $total_financiamento = $conn->query("SELECT COALESCE(SUM(valor),0) FROM entradas WHERE tipo='financiamento'")->fetchColumn();
    $total_inscricoes = $conn->query("SELECT COALESCE(SUM(valor),0) FROM entradas WHERE tipo IN ('inscricao','material','ambos')")->fetchColumn();
} catch (PDOException $e) {
    $erro_tabela = true;
}
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Entradas Financeiras - YWS</title>
    <link rel="stylesheet" href="style.css">
    <style>
        @media print {
            .no-print { display: none !important; }
            body { background: white; }
        }
        .header-print {
            text-align: center;
            border-bottom: 3px solid #0D47A1;
            padding-bottom: 15px;
            margin-bottom: 20px;
        }
        .header-print img { max-width: 80px; }
        .header-print h1 { color: #0D47A1; margin: 10px 0 5px 0; font-size: 24px; letter-spacing: 2px; }
        .header-print h2 { color: #333; margin: 0; font-size: 14px; letter-spacing: 3px; font-weight: normal; }
        .totais-box { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px; margin: 20px 0; }
        .total-card { background: white; padding: 15px; border-radius: 8px; border-left: 4px solid #0D47A1; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        .total-card h4 { margin: 0 0 5px 0; color: #666; font-size: 12px; text-transform: uppercase; }
        .total-card .valor { font-size: 22px; font-weight: bold; color: #0D47A1; }
    </style>
</head>
<body>
<div class="header" style="background: linear-gradient(135deg, #1B5E20 0%, #2E7D32 100%);">
    <h1>The Young Wise School</h1>
    <p style="font-size:14px; letter-spacing:2px;">CENTRO DE FORMAÇÃO</p>
    <p>Módulo Financeiro: Entradas</p>
</div>
<?php include 'menu_admin.php'; ?>

<div class="container">
    <?php if ($erro_tabela): ?>
        <div class="card" style="background:#ffebee;">
            <h3>⚠️ Execute o setup_completo.php primeiro</h3>
        </div>
    <?php else: ?>
        
        <!-- TOTAIS -->
        <h2>📊 Resumo Geral</h2>
        <div class="totais-box">
            <div class="total-card"><h4>Total Geral de Entradas</h4><div class="valor"><?= formatar_moeda($total_entradas) ?></div></div>
            <div class="total-card" style="border-left-color:#2E7D32;"><h4>Propinas</h4><div class="valor" style="color:#2E7D32;"><?= formatar_moeda($total_propinas) ?></div></div>
            <div class="total-card" style="border-left-color:#F57C00;"><h4>Financiamento</h4><div class="valor" style="color:#F57C00;"><?= formatar_moeda($total_financiamento) ?></div></div>
            <div class="total-card" style="border-left-color:#1565C0;"><h4>Inscrições/Material</h4><div class="valor" style="color:#1565C0;"><?= formatar_moeda($total_inscricoes) ?></div></div>
        </div>

        <!-- TABS -->
        <div style="display:flex; gap:10px; margin-bottom:20px; flex-wrap:wrap;" class="no-print">
            <button onclick="mostrarTab('propina')" class="btn-yws btn-green" id="tab-propina">Propina</button>
            <button onclick="mostrarTab('inscricao')" class="btn-yws" style="background:#1565C0;" id="tab-inscricao">Inscrição + Material</button>
            <button onclick="mostrarTab('financiamento')" class="btn-yws" style="background:#F57C00;" id="tab-financiamento">Financiamento (300.000 Kz)</button>
        </div>

        <!-- TAB PROPINA -->
        <div id="form-propina" class="tab-content">
            <h2>Registrar Pagamento de Propina</h2>
            <div class="card" style="background:#e8f5e9;">
                <p><strong>Valores por nível:</strong></p>
                <ul style="line-height:2;">
                    <li>Kindergarten: <strong>7.500,00 Kz</strong></li>
                    <li>Beginner's Level: <strong>10.000,00 Kz</strong></li>
                    <li>Upper Beginner's Level: <strong>10.000,00 Kz</strong></li>
                    <li>Pre-Intermediate Level: <strong>15.000,00 Kz</strong></li>
                    <li>Intermediate Level: <strong>15.000,00 Kz</strong></li>
                    <li>Advanced Level: <strong>21.000,00 Kz</strong></li>
                </ul>
            </div>
            <form method="POST" class="card">
                <input type="hidden" name="acao" value="pagar_propina">
                <input type="hidden" name="tipo_pagamento" value="propina">
                <div style="display:grid; grid-template-columns: 2fr 1fr 1fr 1fr; gap:15px;">
                    <div>
                        <label><strong>Aluno:</strong></label>
                        <select name="id_aluno" id="selectAluno" required onchange="preencherValor()" style="width:100%; padding:10px;">
                            <option value="">-- Selecione --</option>
                            <?php foreach ($alunos as $a): ?>
                                <option value="<?= $a['id'] ?>" data-valor="<?= $a['valor_propina'] ?>"><?= htmlspecialchars($a['nome']) ?> (<?= $a['nome_nivel'] ?>)</option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div>
                        <label><strong>Mês:</strong></label>
                        <input type="month" name="mes" value="<?= date('Y-m') ?>" required style="width:100%; padding:10px;">
                    </div>
                    <div>
                        <label><strong>Valor (Kz):</strong></label>
                        <input type="number" name="valor" id="inputValor" step="0.01" required style="width:100%; padding:10px;">
                    </div>
                    <div>
                        <label><strong>Desconto (Kz):</strong></label>
                        <input type="number" name="desconto" id="inputDesconto" step="0.01" value="0" style="width:100%; padding:10px;">
                    </div>
                </div>
                <br>
                <button type="submit" class="btn-yws btn-green">✅ Confirmar Pagamento e Gerar Recibo</button>
            </form>
        </div>

        <!-- TAB INSCRIÇÃO -->
        <div id="form-inscricao" class="tab-content" style="display:none;">
            <h2>Taxa de Inscrição + Material</h2>
            <form method="POST" class="card">
                <input type="hidden" name="acao" value="pagar_propina">
                <div style="display:grid; grid-template-columns: 2fr 1fr 1fr; gap:15px;">
                    <div>
                        <label><strong>Aluno:</strong></label>
                        <select name="id_aluno" required style="width:100%; padding:10px;">
                            <option value="">-- Selecione --</option>
                            <?php foreach ($alunos as $a): ?>
                                <option value="<?= $a['id'] ?>"><?= htmlspecialchars($a['nome']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div>
                        <label><strong>Tipo:</strong></label>
                        <select name="tipo_pagamento" required style="width:100%; padding:10px;">
                            <option value="inscricao">Inscrição (2.000 Kz)</option>
                            <option value="material">Material (5.000 Kz)</option>
                            <option value="ambos">Ambos (7.000 Kz)</option>
                        </select>
                    </div>
                    <div>
                        <label><strong>Valor (Kz):</strong></label>
                        <input type="number" name="valor" value="7000" step="0.01" required style="width:100%; padding:10px;">
                    </div>
                </div>
                <br>
                <button type="submit" class="btn-yws" style="background:#1565C0;">💾 Registrar</button>
            </form>
        </div>

        <!-- TAB FINANCIAMENTO -->
        <div id="form-financiamento" class="tab-content" style="display:none;">
            <h2>Financiamento Faseado (300.000,00 Kz)</h2>
            <form method="POST" class="card">
                <input type="hidden" name="acao" value="financiamento">
                <div style="display:grid; grid-template-columns: 2fr 1fr 1fr 1fr; gap:15px;">
                    <div><label><strong>Descrição:</strong></label><input type="text" name="descricao" value="Parcela Financiamento" required style="width:100%; padding:10px;"></div>
                    <div><label><strong>Valor Parcela (Kz):</strong></label><input type="number" name="valor_parcela" value="8333.33" step="0.01" required style="width:100%; padding:10px;"></div>
                    <div><label><strong>Parcela Nº:</strong></label><input type="number" name="numero_parcela" min="1" max="36" required style="width:100%; padding:10px;"></div>
                    <div><label><strong>Total Parcelas:</strong></label><input type="number" name="total_parcelas" value="36" required style="width:100%; padding:10px;"></div>
                </div>
                <br>
                <button type="submit" class="btn-yws" style="background:#F57C00;">💾 Registrar Parcela</button>
            </form>
        </div>

        <!-- HISTÓRICO -->
        <h2 style="margin-top:30px;"> Histórico de Entradas</h2>
        <button onclick="window.print()" class="btn-yws no-print">🖨️ Imprimir Histórico</button>
        <table>
            <tr><th>Data</th><th>Tipo</th><th>Origem</th><th>Valor</th><?php if (pode_excluir()): ?><th class="no-print">Ação</th><?php endif; ?></tr>
            <?php foreach ($entradas as $e): ?>
            <tr>
                <td><?= date('d/m/Y', strtotime($e['data'])) ?></td>
                <td><span class="status-badge" style="background:<?= $e['tipo'] === 'propina' ? '#2E7D32' : '#1565C0' ?>;"><?= strtoupper($e['tipo']) ?></span></td>
                <td><?= htmlspecialchars($e['origem']) ?></td>
                <td><strong><?= formatar_moeda($e['valor']) ?></strong></td>
                <?php if (pode_excluir()): ?>
                    <td class="no-print"><a href="?excluir=<?= $e['id'] ?>" class="btn-yws" style="padding:5px 10px; background:#D32F2F;" onclick="return confirm('Excluir?')">🗑️</a></td>
                <?php endif; ?>
            </tr>
            <?php endforeach; ?>
            <tr style="background:#0D47A1; color:white; font-weight:bold;">
                <td colspan="3">TOTAL GERAL</td>
                <td><?= formatar_moeda($total_entradas) ?></td>
                <?php if (pode_excluir()): ?><td class="no-print"></td><?php endif; ?>
            </tr>
        </table>
    <?php endif; ?>
</div>

<script>
function mostrarTab(tab) {
    document.querySelectorAll('.tab-content').forEach(el => el.style.display = 'none');
    document.getElementById('form-' + tab).style.display = 'block';
}
function preencherValor() {
    const select = document.getElementById('selectAluno');
    const valor = select.options[select.selectedIndex].getAttribute('data-valor');
    document.getElementById('inputValor').value = valor || '';
    document.getElementById('inputDesconto').value = '0';
}
</script>
</body>
</html>