<?php
// Sistema de Permissões por Cargo - YWS
if (!defined('PERMISSOES_CARREGADAS')) {
    define('PERMISSOES_CARREGADAS', true);
    
    // Mapa de permissões por cargo
    $permissoes = [
        'CEO' => [
            'inicio' => true,
            'financeiro' => true,
            'estatistica_geral' => true,
            'pauta_geral' => true,
            'cadastro_alunos' => true,
            'cadastro_funcionarios' => true,
            'turmas' => true,
            'avaliacoes' => true,
            'notas' => true,
            'avisos' => true,
            'estoque' => true,
            'backup' => true,
            'relatorios' => true,
            'todas_turmas' => true,
            'entradas_periodo' => false // CEO vê tudo, não só período
        ],
        'Coordenador Geral' => [
            'inicio' => true,
            'financeiro' => true,
            'estatistica_geral' => true,
            'pauta_geral' => true,
            'cadastro_alunos' => true,
            'cadastro_funcionarios' => true,
            'turmas' => true,
            'avaliacoes' => true,
            'notas' => true,
            'avisos' => true,
            'estoque' => true,
            'backup' => true,
            'relatorios' => true,
            'todas_turmas' => true,
            'entradas_periodo' => false
        ],
        'Professor' => [
            'inicio' => false,
            'financeiro' => false,
            'estatistica_geral' => false,
            'pauta_geral' => false,
            'cadastro_alunos' => false,
            'cadastro_funcionarios' => false,
            'turmas' => false,
            'avaliacoes' => true,
            'notas' => true,
            'avisos' => true,
            'estoque' => false,
            'backup' => false,
            'relatorios' => false,
            'todas_turmas' => false, // Só suas turmas
            'entradas_periodo' => false
        ],
        'Secretaria' => [
            'inicio' => false,
            'financeiro' => false,
            'estatistica_geral' => true, // Só visualizar
            'pauta_geral' => false,
            'cadastro_alunos' => true,
            'cadastro_funcionarios' => false,
            'turmas' => true, // Visualizar
            'avaliacoes' => false,
            'notas' => false,
            'avisos' => true,
            'estoque' => false,
            'backup' => false,
            'relatorios' => false,
            'todas_turmas' => true,
            'entradas_periodo' => true // Só entradas por período
        ],
        'Pedagogico' => [
            'inicio' => false,
            'financeiro' => false,
            'estatistica_geral' => true,
            'pauta_geral' => true,
            'cadastro_alunos' => true,
            'cadastro_funcionarios' => false,
            'turmas' => true, // Criar turmas
            'avaliacoes' => true,
            'notas' => true,
            'avisos' => true,
            'estoque' => false,
            'backup' => false,
            'relatorios' => true,
            'todas_turmas' => true,
            'entradas_periodo' => false
        ],
        'Marketing' => [
            'inicio' => false,
            'financeiro' => false,
            'estatistica_geral' => true,
            'pauta_geral' => false,
            'cadastro_alunos' => true,
            'cadastro_funcionarios' => false,
            'turmas' => true,
            'avaliacoes' => false,
            'notas' => false,
            'avisos' => true,
            'estoque' => false,
            'backup' => false,
            'relatorios' => true,
            'todas_turmas' => true,
            'entradas_periodo' => false
        ]
    ];
}

// Função para verificar permissão
function tem_permissao($recurso) {
    global $permissoes;
    if (!isset($_SESSION['user']['cargo'])) return false;
    $cargo = $_SESSION['user']['cargo'];
    return $permissoes[$cargo][$recurso] ?? false;
}

// Função para verificar se é CEO ou Coordenador
function eh_admin_geral() {
    if (!isset($_SESSION['user']['cargo'])) return false;
    return in_array($_SESSION['user']['cargo'], ['CEO', 'Coordenador Geral']);
}

// Função para verificar se é Professor
function eh_professor() {
    if (!isset($_SESSION['user']['cargo'])) return false;
    return $_SESSION['user']['cargo'] === 'Professor';
}

// Função para verificar se é Secretaria
function eh_secretaria() {
    if (!isset($_SESSION['user']['cargo'])) return false;
    return $_SESSION['user']['cargo'] === 'Secretaria';
}

// Função para verificar se é Pedagógico
function eh_pedagogico() {
    if (!isset($_SESSION['user']['cargo'])) return false;
    return $_SESSION['user']['cargo'] === 'Pedagogico';
}

// Função para verificar se é Marketing
function eh_marketing() {
    if (!isset($_SESSION['user']['cargo'])) return false;
    return $_SESSION['user']['cargo'] === 'Marketing';
}

// Função para buscar turmas do professor
function turmas_do_professor($conn, $id_professor) {
    $stmt = $conn->prepare("SELECT t.*, n.nome_nivel FROM turmas t LEFT JOIN niveis n ON t.id_nivel = n.id WHERE t.id_professor = ?");
    $stmt->execute([$id_professor]);
    return $stmt->fetchAll();
}
?>