<?php
include 'config.php';

$id = $_GET['id'] ?? 0;
$aluno = $_GET['aluno'] ?? 'Aluno';
$valor = $_GET['valor'] ?? 0;
$mes = $_GET['mes'] ?? date('Y-m');
$desconto = $_GET['desconto'] ?? 0;
$tipo = $_GET['tipo'] ?? 'propina';

$data_pag = date('Y-m-d');
try {
    $stmt = $conn->prepare("SELECT data_pagamento FROM propinas_pagas WHERE id = ?");
    $stmt->execute([$id]);
    $data_pag = $stmt->fetchColumn() ?: date('Y-m-d');
} catch (Exception $e) {}

$numero_recibo = str_pad($id, 6, '0', STR_PAD_LEFT);
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Recibo Nº <?= $numero_recibo ?> - YWS</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'Georgia', serif; padding: 30px; max-width: 750px; margin: auto; background: white; }
        .recibo { border: 3px double #0D47A1; padding: 30px; border-radius: 10px; position: relative; }
        .header-instituicao { text-align: center; border-bottom: 2px solid #D32F2F; padding-bottom: 15px; margin-bottom: 20px; }
        .header-instituicao img { max-width: 90px; }
        .header-instituicao h1 { color: #0D47A1; margin: 10px 0 5px 0; font-size: 26px; letter-spacing: 2px; }
        .header-instituicao h2 { color: #333; margin: 0; font-size: 13px; letter-spacing: 4px; font-weight: normal; }
        .numero-recibo { position: absolute; top: 20px; right: 30px; background: #D32F2F; color: white; padding: 8px 15px; border-radius: 20px; font-weight: bold; font-size: 14px; }
        .titulo { text-align: center; font-size: 22px; font-weight: bold; color: #0D47A1; margin: 20px 0; text-transform: uppercase; letter-spacing: 2px; }
        .info-box { background: #f5f7fa; padding: 20px; border-radius: 8px; margin: 20px 0; line-height: 2; }
        .info-box p { margin: 8px 0; font-size: 15px; }
        .info-box strong { color: #0D47A1; }
        .valor-box { background: linear-gradient(135deg, #0D47A1, #1565C0); color: white; padding: 20px; text-align: center; font-size: 28px; font-weight: bold; border-radius: 8px; margin: 20px 0; }
        .assinatura-section { margin-top: 60px; display: flex; justify-content: space-between; align-items: flex-end; }
        .assinatura { text-align: center; width: 40%; }
        .assinatura .linha { border-top: 1px solid #333; padding-top: 8px; margin-bottom: 5px; }
        .assinatura .cargo { font-weight: bold; font-size: 13px; color: #333; }
        .carimbo { width: 110px; height: 110px; border: 3px dashed #D32F2F; border-radius: 50%; display: flex; align-items: center; justify-content: center; color: #D32F2F; font-size: 11px; font-weight: bold; text-align: center; transform: rotate(-15deg); opacity: 0.7; }
        .footer { margin-top: 30px; text-align: center; font-size: 11px; color: #999; border-top: 1px solid #eee; padding-top: 15px; }
        @media print { .no-print { display: none; } body { padding: 0; } }
    </style>
</head>
<body>
    <div class="no-print" style="text-align:center; margin-bottom:20px;">
        <button onclick="window.print()" style="padding:12px 25px; background:#0D47A1; color:white; border:none; border-radius:5px; cursor:pointer; font-size:16px;">🖨️ Imprimir / Salvar PDF</button>
        <button onclick="window.close()" style="padding:12px 25px; background:#666; color:white; border:none; border-radius:5px; cursor:pointer; font-size:16px; margin-left:10px;">Fechar</button>
    </div>

    <div class="recibo">
        <div class="numero-recibo">Nº <?= $numero_recibo ?></div>
        
        <div class="header-instituicao">
            <img src="logo.png" alt="YWS" onerror="this.style.display='none'">
            <h1>THE YOUNG WISE SCHOOL</h1>
            <h2>CENTRO DE FORMAÇÃO</h2>
        </div>

        <div class="titulo">Recibo de Pagamento</div>

        <div class="info-box">
            <p><strong>Recebemos de:</strong> <?= htmlspecialchars($aluno) ?></p>
            <p><strong>Referente a:</strong> <?= ucfirst($tipo) ?> - Mensalidade do período de <strong><?= htmlspecialchars($mes) ?></strong></p>
            <?php if ($desconto > 0): ?>
                <p><strong>Desconto aplicado:</strong> <?= formatar_moeda($desconto) ?></p>
            <?php endif; ?>
            <p><strong>Data do pagamento:</strong> <?= date('d/m/Y', strtotime($data_pag)) ?></p>
        </div>

        <div class="valor-box">
            <?= formatar_moeda($valor) ?>
        </div>

        <p style="text-align:center; font-style:italic; color:#666; margin:20px 0;">
            Pelo presente recibo, declaramos ter recebido a quantia acima mencionada, 
            dando plena e geral quitação.
        </p>

        <div class="assinatura-section">
            <div class="assinatura">
                <div class="linha">
                    <div class="cargo">Pagador</div>
                    <div style="font-size:12px; color:#666;">(Aluno/Encarregado)</div>
                </div>
            </div>
            
            <div class="carimbo">
                CARIMBO<br>YWS
            </div>
            
            <div class="assinatura">
                <div class="linha">
                    <div class="cargo">Secretária Geral</div>
                    <div style="font-size:12px; color:#666;">The Young Wise School</div>
                </div>
            </div>
        </div>

        <div class="footer">
            Documento gerado eletronicamente pelo Sistema YWS em <?= date('d/m/Y H:i') ?><br>
            Este recibo é válido sem rasuras ou emendas.
        </div>
    </div>
</body>
</html>