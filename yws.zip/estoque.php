<?php
include 'config.php';
if (!isset($_SESSION['user'])) { header("Location: login.php"); exit; }

// Eliminar item
if (isset($_GET['eliminar'])) {
    if (!pode_excluir()) {
        die("<script>alert('Apenas administradores podem eliminar.'); window.history.back();</script>");
    }
    $conn->prepare("DELETE FROM estoque WHERE id_item = ?")->execute([$_GET['eliminar']]);
    echo "<script>alert('Item eliminado!'); window.location='estoque.php';</script>";
    exit;
}

// Processar Entrada ou Saída
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao'])) {
    $id_item = (int)$_POST['id_item'];
    $qtd = (int)$_POST['qtd'];
    $tipo = $_POST['acao'];
    
    if ($tipo === 'entrada') {
        $conn->prepare("UPDATE estoque SET qtd_entrada = qtd_entrada + ?, qtd_atual = qtd_atual + ? WHERE id_item = ?")
             ->execute([$qtd, $qtd, $id_item]);
    } else {
        $conn->prepare("UPDATE estoque SET qtd_saida = qtd_saida + ?, qtd_atual = qtd_atual - ? WHERE id_item = ?")
             ->execute([$qtd, $qtd, $id_item]);
    }
    echo "<script>alert('Estoque atualizado!'); window.location='estoque.php';</script>";
    exit;
}

// Editar item
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['editar_item'])) {
    if (!pode_excluir()) {
        die("<script>alert('Apenas administradores podem editar.'); window.history.back();</script>");
    }
    $id = (int)$_POST['id_item'];
    $nome = trim($_POST['nome']);
    $qtd = (int)$_POST['qtd_atual'];
    $conn->prepare("UPDATE estoque SET nome = ?, qtd_atual = ? WHERE id_item = ?")
         ->execute([$nome, $qtd, $id]);
    echo "<script>alert('Item editado!'); window.location='estoque.php';</script>";
    exit;
}

// Adicionar novo item
if (isset($_POST['novo_item'])) {
    $nome = trim($_POST['nome_item']);
    $qtd = (int)$_POST['qtd_inicial'];
    $conn->prepare("INSERT INTO estoque (nome, qtd_entrada, qtd_atual) VALUES (?, ?, ?)")
         ->execute([$nome, $qtd, $qtd]);
    echo "<script>alert('Item criado!'); window.location='estoque.php';</script>";
    exit;
}

$itens = $conn->query("SELECT * FROM estoque ORDER BY nome ASC")->fetchAll();
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Controle de Estoque - YWS</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="header" style="background: linear-gradient(135deg, #F57C00 0%, #FF9800 100%);">
    <h1>The Young Wise School - YWS</h1>
    <p style="font-style: italic; color: #ffcc00;">"More than just speak English"</p>
    <p>Controle de Estoque</p>
</div>
<?php include 'menu_admin.php'; ?>

<div class="container">
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
        <h2>📦 Itens em Estoque (<?= count($itens) ?>)</h2>
        <button onclick="document.getElementById('formNovo').style.display='block'" class="btn-yws btn-green">➕ Novo Item</button>
    </div>

    <!-- Form Novo Item -->
    <div id="formNovo" class="card" style="display:none; background:#fff3e0;">
        <h3>Adicionar Novo Item</h3>
        <form method="POST" style="display:flex; gap:10px; align-items:flex-end; flex-wrap:wrap;">
            <input type="hidden" name="novo_item" value="1">
            <div style="flex:2;"><label>Nome:</label><input type="text" name="nome_item" required style="width:100%; padding:8px;"></div>
            <div style="flex:1;"><label>Qtd. Inicial:</label><input type="number" name="qtd_inicial" value="0" required style="width:100%; padding:8px;"></div>
            <button type="submit" class="btn-yws">Salvar</button>
            <button type="button" onclick="document.getElementById('formNovo').style.display='none'" class="btn-yws" style="background:#666;">Cancelar</button>
        </form>
    </div>

    <table>
        <tr>
            <th>Item</th>
            <th>Entrada</th>
            <th>Saída</th>
            <th>Atual</th>
            <th>Status</th>
            <th>Ações</th>
        </tr>
        <?php foreach ($itens as $item): 
            $baixo = $item['qtd_atual'] <= 10;
        ?>
        <tr style="<?= $baixo ? 'background:#ffebee;' : '' ?>">
            <td><strong><?= htmlspecialchars($item['nome']) ?></strong></td>
            <td><?= $item['qtd_entrada'] ?></td>
            <td><?= $item['qtd_saida'] ?></td>
            <td><strong style="font-size:18px; color:<?= $baixo ? '#D32F2F' : '#2E7D32' ?>"><?= $item['qtd_atual'] ?></strong></td>
            <td><span class="status-badge" style="background:<?= $baixo ? '#D32F2F' : '#2E7D32' ?>;"><?= $baixo ? '⚠️ BAIXO' : '✅ OK' ?></span></td>
            <td style="display:flex; gap:5px; flex-wrap:wrap;">
                <button onclick="movimentar(<?= $item['id_item'] ?>, 'entrada')" class="btn-yws" style="padding:5px 8px; background:#2E7D32;"></button>
                <button onclick="movimentar(<?= $item['id_item'] ?>, 'saida')" class="btn-yws" style="padding:5px 8px; background:#F57C00;">📤</button>
                <?php if (pode_excluir()): ?>
                    <button onclick="editar(<?= $item['id_item'] ?>, '<?= addslashes($item['nome']) ?>', <?= $item['qtd_atual'] ?>)" class="btn-yws" style="padding:5px 8px; background:#1565C0;">✏️</button>
                    <a href="?eliminar=<?= $item['id_item'] ?>" class="btn-yws" style="padding:5px 8px; background:#D32F2F;" onclick="return confirm('Eliminar este item?')">🗑️</a>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
</div>

<!-- Modal Movimentação -->
<div id="modalMov" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.5); z-index:1000;">
    <div style="background:white; max-width:400px; margin:100px auto; padding:30px; border-radius:8px;">
        <h3 id="tituloMov">Movimentar</h3>
        <form method="POST">
            <input type="hidden" name="id_item" id="movId">
            <input type="hidden" name="acao" id="movAcao">
            <label>Quantidade:</label>
            <input type="number" name="qtd" min="1" required style="width:100%; padding:10px; margin:10px 0;">
            <div style="display:flex; gap:10px;">
                <button type="submit" class="btn-yws" style="flex:1;">Confirmar</button>
                <button type="button" onclick="document.getElementById('modalMov').style.display='none'" class="btn-yws" style="flex:1; background:#666;">Cancelar</button>
            </div>
        </form>
    </div>
</div>

<!-- Modal Edição -->
<div id="modalEdit" style="display:none; position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.5); z-index:1000;">
    <div style="background:white; max-width:400px; margin:100px auto; padding:30px; border-radius:8px;">
        <h3>✏️ Editar Item</h3>
        <form method="POST">
            <input type="hidden" name="editar_item" value="1">
            <input type="hidden" name="id_item" id="editId">
            <label>Nome:</label>
            <input type="text" name="nome" id="editNome" required style="width:100%; padding:10px; margin:10px 0;">
            <label>Quantidade Atual:</label>
            <input type="number" name="qtd_atual" id="editQtd" required style="width:100%; padding:10px; margin:10px 0;">
            <div style="display:flex; gap:10px;">
                <button type="submit" class="btn-yws" style="flex:1;">Salvar</button>
                <button type="button" onclick="document.getElementById('modalEdit').style.display='none'" class="btn-yws" style="flex:1; background:#666;">Cancelar</button>
            </div>
        </form>
    </div>
</div>

<script>
function movimentar(id, acao) {
    document.getElementById('movId').value = id;
    document.getElementById('movAcao').value = acao;
    document.getElementById('tituloMov').innerText = (acao === 'entrada' ? ' Entrada' : '📤 Saída') + ' de Estoque';
    document.getElementById('modalMov').style.display = 'block';
}
function editar(id, nome, qtd) {
    document.getElementById('editId').value = id;
    document.getElementById('editNome').value = nome;
    document.getElementById('editQtd').value = qtd;
    document.getElementById('modalEdit').style.display = 'block';
}
</script>
</body>
</html>