-- Backup automático YWS
-- Data: 2026-09-11 11:52:39
-- Usuário: Admin YWS

SET FOREIGN_KEY_CHECKS=0;


-- Tabela: alunos
DROP TABLE IF EXISTS `alunos`;
CREATE TABLE `alunos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(150) NOT NULL,
  `curso` varchar(100) DEFAULT 'Ingles',
  `nivel_id` int(11) DEFAULT NULL,
  `data_matricula` date NOT NULL,
  `status` varchar(20) DEFAULT 'ativo',
  `numero_telefone` varchar(20) DEFAULT NULL,
  `usuario` varchar(50) NOT NULL,
  `senha` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `usuario` (`usuario`),
  KEY `nivel_id` (`nivel_id`),
  CONSTRAINT `alunos_ibfk_1` FOREIGN KEY (`nivel_id`) REFERENCES `niveis` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `alunos` VALUES ('2', 'Bonifácio Xacazulu Mateus Maria Bony', 'Inglês', '2', '2026-09-10', 'ativo', '921263244', 'aluno@yws.com', '$2y$10$I0axG8X9fndpA8hqXn0rOeIblDsqdJLqeFlqi5l6iYbgwm9viGVYq');


-- Tabela: departamentos
DROP TABLE IF EXISTS `departamentos`;
CREATE TABLE `departamentos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `departamentos` VALUES ('1', 'CEO');
INSERT INTO `departamentos` VALUES ('2', 'Coordenacao Geral');
INSERT INTO `departamentos` VALUES ('3', 'Secretaria Geral');
INSERT INTO `departamentos` VALUES ('4', 'Direcao Pedagogica');
INSERT INTO `departamentos` VALUES ('5', 'Direcao de Marketing e Vendas');
INSERT INTO `departamentos` VALUES ('6', 'Professores');


-- Tabela: entradas
DROP TABLE IF EXISTS `entradas`;
CREATE TABLE `entradas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tipo` varchar(50) NOT NULL,
  `origem` varchar(100) NOT NULL,
  `valor` decimal(10,2) NOT NULL,
  `data` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `entradas` VALUES ('2', 'propina', 'Bonifácio Xacazulu Mateus Maria Bony', '5000.00', '2026-09-11');


-- Tabela: estoque
DROP TABLE IF EXISTS `estoque`;
CREATE TABLE `estoque` (
  `id_item` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(100) NOT NULL,
  `qtd_entrada` int(11) DEFAULT 0,
  `qtd_saida` int(11) DEFAULT 0,
  `qtd_atual` int(11) DEFAULT 0,
  PRIMARY KEY (`id_item`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `estoque` VALUES ('1', 'Marcadores', '50', '0', '50');
INSERT INTO `estoque` VALUES ('2', 'Folhas A4', '20', '0', '20');
INSERT INTO `estoque` VALUES ('3', 'Apagadores', '10', '0', '10');
INSERT INTO `estoque` VALUES ('4', 'baldes', '1', '1', '0');


-- Tabela: funcionarios
DROP TABLE IF EXISTS `funcionarios`;
CREATE TABLE `funcionarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(150) NOT NULL,
  `cargo` varchar(100) NOT NULL,
  `salario` decimal(10,2) NOT NULL,
  `iban` varchar(50) DEFAULT NULL,
  `data_admissao` date NOT NULL,
  `departamento_id` int(11) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'ativo',
  `usuario` varchar(50) NOT NULL,
  `senha` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `usuario` (`usuario`),
  KEY `departamento_id` (`departamento_id`),
  CONSTRAINT `funcionarios_ibfk_1` FOREIGN KEY (`departamento_id`) REFERENCES `departamentos` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `funcionarios` VALUES ('1', 'Admin YWS', 'CEO', '15000.00', NULL, '2023-01-01', '1', 'ativo', 'admin', '$2y$10$DdgLM.IxcB.yDEihasYTVOhWXTO6w8TrL/WDhohC57PBoofszFkS2');
INSERT INTO `funcionarios` VALUES ('4', 'Bonifácio Xacazulu Mateus Maria Bony', 'Professor', '12.00', '', '2026-09-10', '6', 'ativo', 'prof@yws.com', '$2y$10$pDqDm8TNQiifMcSAXyfXr.Z5zekq1NM3P7VjvjUxsPeLX0PyJ3jfu');
INSERT INTO `funcionarios` VALUES ('6', 'Rayana Batista', 'Secretária', '12.00', '', '2026-09-11', '3', 'ativo', 'secr@yws.com', '$2y$10$cpaTxg55T413HCe5PsdIUubUz70nlsnxgwyn3wpJlas8a4fvGTJlG');
INSERT INTO `funcionarios` VALUES ('7', 'NúnesAntónio', 'D. Pedagógico', '14.00', '', '2026-09-11', '4', 'ativo', 'pedag@yws.com', '$2y$10$xLrQSKuqtuj1pvsUWWgs8OoM9d2VBqaY12K7Hb.Mlr5U8Cp04o0hO');
INSERT INTO `funcionarios` VALUES ('8', 'Manuel Mendes', 'D. Marketing', '11.00', '', '2026-09-11', '5', 'ativo', 'mark@yws.com', '$2y$10$7uM2zFFrRnCHxTtggIHW0OvepAt1pkK9Sy5sLVwpA4TWy1fjOVyCy');
INSERT INTO `funcionarios` VALUES ('9', 'Bonifácio Xacazulu Mateus Maria Bony', 'Coordenador Geral', '13.00', '', '2026-09-11', '2', 'ativo', 'coord@yws.com', '$2y$10$zPRVJc02kwt/DUZCKZPYkuMsIZk6Mi4NcMjM7.oYjxeZfhvCNCLCK');


-- Tabela: mensalidades
DROP TABLE IF EXISTS `mensalidades`;
CREATE TABLE `mensalidades` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_aluno` int(11) NOT NULL,
  `mes_referencia` varchar(7) NOT NULL,
  `valor` decimal(10,2) NOT NULL,
  `status_pagamento` varchar(20) DEFAULT 'pendente',
  `data_pagamento` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_aluno` (`id_aluno`),
  CONSTRAINT `mensalidades_ibfk_1` FOREIGN KEY (`id_aluno`) REFERENCES `alunos` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Tabela: niveis
DROP TABLE IF EXISTS `niveis`;
CREATE TABLE `niveis` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome_nivel` varchar(100) NOT NULL,
  `duracao` varchar(50) DEFAULT NULL,
  `valor_propina` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `niveis` VALUES ('1', 'Kindergarten', '1 ano', '5000.00');
INSERT INTO `niveis` VALUES ('2', 'Beginners Level', '4 a 5 meses', '4000.00');
INSERT INTO `niveis` VALUES ('3', 'Upper Beginners Level', '5 a 6 meses', '4500.00');
INSERT INTO `niveis` VALUES ('4', 'Pre-Intermediate Level', '4 a 5 meses', '5000.00');
INSERT INTO `niveis` VALUES ('5', 'Intermediate Level', '5 a 6 meses', '5500.00');
INSERT INTO `niveis` VALUES ('6', 'Advanced Level', '4 a 5 meses', '6000.00');


-- Tabela: notas
DROP TABLE IF EXISTS `notas`;
CREATE TABLE `notas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_aluno` int(11) NOT NULL,
  `id_turma` int(11) NOT NULL,
  `exercicios` decimal(5,2) DEFAULT NULL,
  `exame` decimal(5,2) DEFAULT NULL,
  `total` decimal(5,2) GENERATED ALWAYS AS (`exercicios` + `exame`) STORED,
  `data_lancamento` date NOT NULL,
  `status_aprovacao` varchar(20) DEFAULT 'pendente',
  PRIMARY KEY (`id`),
  KEY `id_aluno` (`id_aluno`),
  KEY `id_turma` (`id_turma`),
  CONSTRAINT `notas_ibfk_1` FOREIGN KEY (`id_aluno`) REFERENCES `alunos` (`id`),
  CONSTRAINT `notas_ibfk_2` FOREIGN KEY (`id_turma`) REFERENCES `turmas` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `notas` VALUES ('2', '2', '1', '30.00', '120.00', '150.00', '2026-09-10', 'aprovado');
INSERT INTO `notas` VALUES ('3', '2', '1', '30.00', '115.00', '145.00', '2026-09-11', 'aprovado');
INSERT INTO `notas` VALUES ('4', '2', '1', '19.00', '120.00', '139.00', '2026-09-11', 'aprovado');


-- Tabela: propinas_pagas
DROP TABLE IF EXISTS `propinas_pagas`;
CREATE TABLE `propinas_pagas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_aluno` int(11) NOT NULL,
  `mes` varchar(20) NOT NULL,
  `ano` int(11) NOT NULL,
  `valor_pago` decimal(10,2) NOT NULL,
  `data_pagamento` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `propinas_pagas` VALUES ('1', '2', '2026-09', '2026', '5000.00', '2026-09-11');
INSERT INTO `propinas_pagas` VALUES ('2', '2', '2026-09', '2026', '5000.00', '2026-09-11');


-- Tabela: repasse_financiador
DROP TABLE IF EXISTS `repasse_financiador`;
CREATE TABLE `repasse_financiador` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mes` varchar(20) NOT NULL,
  `ano` int(11) NOT NULL,
  `total_arrecadado` decimal(10,2) NOT NULL,
  `valor_25_porcento` decimal(10,2) NOT NULL,
  `status` varchar(20) DEFAULT 'pendente',
  `data_repasse` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `repasse_financiador` VALUES ('1', '2026-09', '2026', '5000.00', '1250.00', 'pago', '2026-09-11');
INSERT INTO `repasse_financiador` VALUES ('2', '2026-09', '2026', '5000.00', '1250.00', 'pago', '2026-09-11');


-- Tabela: rh_movimentos
DROP TABLE IF EXISTS `rh_movimentos`;
CREATE TABLE `rh_movimentos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_funcionario` int(11) NOT NULL,
  `tipo_movimento` varchar(50) NOT NULL,
  `data` date NOT NULL,
  `observacao` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_funcionario` (`id_funcionario`),
  CONSTRAINT `rh_movimentos_ibfk_1` FOREIGN KEY (`id_funcionario`) REFERENCES `funcionarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Tabela: saidas
DROP TABLE IF EXISTS `saidas`;
CREATE TABLE `saidas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tipo` varchar(50) NOT NULL,
  `descricao` varchar(255) NOT NULL,
  `valor` decimal(10,2) NOT NULL,
  `data` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `saidas` VALUES ('1', 'rh_material', 'Compra Material RH (Marcadores, Folhas, etc)', '10000.00', '2026-09-11');
INSERT INTO `saidas` VALUES ('2', 'aluguel', 'Renda Mensal', '20000.00', '2026-09-11');
INSERT INTO `saidas` VALUES ('3', 'financiador_25%', 'Repasse 25% - Bonifácio Xacazulu Mateus Maria Bony - 2026-09/2026', '1250.00', '2026-09-11');
INSERT INTO `saidas` VALUES ('4', 'financiador_25%', 'Repasse 25% - Bonifácio Xacazulu Mateus Maria Bony - 2026-09/2026', '1250.00', '2026-09-11');


-- Tabela: salarios
DROP TABLE IF EXISTS `salarios`;
CREATE TABLE `salarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_funcionario` int(11) NOT NULL,
  `mes` varchar(20) NOT NULL,
  `ano` int(11) NOT NULL,
  `valor_liquido` decimal(10,2) NOT NULL,
  `status_pagamento` varchar(20) DEFAULT 'pendente',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- Tabela: turmas
DROP TABLE IF EXISTS `turmas`;
CREATE TABLE `turmas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome_turma` varchar(100) NOT NULL,
  `id_professor` int(11) DEFAULT NULL,
  `id_nivel` int(11) DEFAULT NULL,
  `periodo` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `id_professor` (`id_professor`),
  KEY `id_nivel` (`id_nivel`),
  CONSTRAINT `turmas_ibfk_1` FOREIGN KEY (`id_professor`) REFERENCES `funcionarios` (`id`),
  CONSTRAINT `turmas_ibfk_2` FOREIGN KEY (`id_nivel`) REFERENCES `niveis` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `turmas` VALUES ('1', 'leão', '4', '2', 'manhã');


SET FOREIGN_KEY_CHECKS=1;
