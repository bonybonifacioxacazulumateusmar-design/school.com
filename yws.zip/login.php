<?php 
include 'config.php';
if (isset($_GET['logout'])) {
    session_destroy();
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - The Young Wise School</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body {
            background: linear-gradient(135deg, #0D47A1 0%, #1565C0 50%, #D32F2F 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .login-box {
            animation: fadeIn 0.6s ease;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .logo-login {
            max-width: 180px;
            margin-bottom: 20px;
            filter: drop-shadow(0 4px 12px rgba(0,0,0,0.2));
        }
        .login-box h2 {
            color: #0D47A1;
            margin-bottom: 5px;
        }
        .login-box .subtitulo {
            color: #666;
            font-size: 14px;
            margin-bottom: 25px;
        }
        .login-box input {
            margin-bottom: 15px;
            border: 2px solid #e0e0e0;
        }
        .login-box button {
            width: 100%;
            padding: 14px;
            font-size: 16px;
            background: linear-gradient(135deg, #0D47A1, #D32F2F);
            border: none;
            color: white;
            border-radius: 8px;
            cursor: pointer;
            font-weight: bold;
            transition: transform 0.3s;
        }
        .login-box button:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(0,0,0,0.2);
        }
        .footer-login {
            margin-top: 20px;
            font-size: 12px;
            color: #999;
        }
    </style>
</head>
<body>
    <div class="login-box">
        <img src="logo.png" alt="YWS Logo" class="logo-login" onerror="this.style.display='none'">
        <h2>The Young Wise School</h2>
        <p class="subtitulo">"More than just speak English"</p>
        
        <form action="auth_process.php" method="POST">
            <input type="text" name="usuario" placeholder="👤 Usuário" required>
            <input type="password" name="senha" placeholder="🔒 Senha" required>
            <button type="submit">ENTRAR</button>
        </form>
        
        <div class="footer-login">
            © 2026 YWS - Sistema de Gestão Escolar
        </div>
    </div>
</body>
</html>