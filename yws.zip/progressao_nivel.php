<?php
include 'config.php';
if (!isset($_SESSION['user']) || $_SESSION['user']['tipo'] !== 'funcionario') {
    header("Location: login.php"); exit;
}

// Função para promover alunos
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao']) && $_POST['acao'] === 'promover') {
    $id_aluno = $_POST['id_aluno'];
    $novo_nivel = $_POST['novo_nivel'];
    
    $conn->prepare("UPDATE alunos SET nivel_id = ? WHERE id = ?")
         ->execute([$novo_nivel, $id_aluno]);
    
    echo "<script>alert('✅ Aluno promovido com sucesso!'); window.location='progressao_nivel.php';</script>";
    exit;
}

// Busca alunos aprovados prontos para promoção
$aprovados = $conn->query("SELECT DISTINCT a.id, a.nome, a.nivel_id as nivel_atual,
                           n.nome_nivel, n.id as proximo_nivel,
                           (SELECT nome_nivel FROM niveis WHERE id = n.id + 1) as nivel_seguinte
                           FROM alunos a
                           LEFT JOIN niveis n ON a.nivel_id = n.id
                           LEFT JOIN notas nt ON a.id = nt.id_aluno
                           WHERE nt.status_aprovacao = 'aprovado'
                           AND a.status = 'ativo'
                           AND n.id < 6
                           GROUP BY a.id, a.nome, n.nome_nivel, n.id
                           HAVING COUNT(nt.id) >= 3")->fetchAll();

// Busca todos os níveis
$niveis = $conn->query("SELECT id, nome_nivel FROM niveis ORDER BY id")->fetchAll();
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Progressão de Nível - YWS</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="header">
    <h1>The Young Wise School - YWS</h1>
    <p>Sistema de Progressão Automática de Nível</p>
</div>
<?php include 'menu_admin.php'; ?>

<div class="container">
    <div class="card card-blue">
        <h3>📋 Como Funciona</h3>
        <p>O sistema identifica automaticamente alunos que:</p>
        <ul style="margin-left:20px; line-height:1.8;">
            <li>Têm pelo menos 3 notas com status "Aprovado"</li>
            <li>Estão no nível atual (não completaram todos os níveis)</li>
            <li>Estão com status "Ativo"</li>
        </ul>
        <p><strong>Regra:</strong> Aluno precisa de média >= 90 pontos (50%) para ser aprovado.</p>
    </div>

    <h2 style="margin-top:30px;">🎓 Alunos Elegíveis para Promoção</h2>
    
    <?php if (empty($aprovados)): ?>
        <div class="card" style="background:#e8f5e9; border-left-color: #2E7D32;">
            <p>✅ Nenhum aluno pendente de promoção no momento!</p>
        </div>
    <?php else: ?>
        <table>
            <tr>
                <th>Aluno</th>
                <th>Nível Atual</th>
                <th>Próximo Nível</th>
                <th>Notas Aprovadas</th>
                <th>Ação</th>
            </tr>
            <?php foreach ($aprovados as $a): ?>
                <tr>
                    <td><strong><?= htmlspecialchars($a['nome']) ?></strong></td>
                    <td><?= htmlspecialchars($a['nome_nivel']) ?></td>
                    <td><strong style="color:#2E7D32;"><?= htmlspecialchars($a['nivel_seguinte']) ?></strong></td>
                    <td>
                        <?php 
                        $stmt = $conn->prepare("SELECT COUNT(*) FROM notas WHERE id_aluno=? AND status_aprovacao='aprovado'");
                        $stmt->execute([$a['id']]);
                        echo $stmt->fetchColumn();
                        ?>
                    </td>
                    <td>
                        <form method="POST" style="display:inline;">
                            <input type="hidden" name="acao" value="promover">
                            <input type="hidden" name="id_aluno" value="<?= $a['id'] ?>">
                            <input type="hidden" name="novo_nivel" value="<?= $a['nivel_atual'] + 1 ?>">
                            <button type="submit" class="btn-yws btn-green" style="padding:5px 10px;" 
                                    onclick="return confirm('Promover <?= htmlspecialchars($a['nome']) ?> para <?= htmlspecialchars($a['nivel_seguinte']) ?>?')">
                                ✅ Promover
                            </button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php endif; ?>

    <h2 style="margin-top:30px;"> Estrutura de Níveis</h2>
    <table>
        <tr>
            <th>ID</th>
            <th>Nível</th>
            <th>Duração</th>
            <th>Pré-requisito</th>
        </tr>
        <?php foreach ($niveis as $n): ?>
            <tr>
                <td><strong><?= str_pad($n['id'], 2, '0', STR_PAD_LEFT) ?></strong></td>
                <td><?= htmlspecialchars($n['nome_nivel']) ?></td>
                <td>
                    <?php
                    $stmt = $conn->prepare("SELECT duracao FROM niveis WHERE id = ?");
                    $stmt->execute([$n['id']]);
                    echo htmlspecialchars($stmt->fetchColumn());
                    ?>
                </td>
                <td><?= $n['id'] > 1 ? 'Aprovação no nível anterior' : 'Nenhum' ?></td>
            </tr>
        <?php endforeach; ?>
    </table>

    <div style="text-align:center; margin-top:30px;">
        <a href="cadastro_alunos.php" class="btn-yws">🎓 Gerenciar Alunos</a>
        <a href="dashboard.php" class="btn-yws">📊 Voltar ao Dashboard</a>
    </div>
</div>
</body>
</html>