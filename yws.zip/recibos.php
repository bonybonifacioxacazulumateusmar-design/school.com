<?php
include 'config.php';
if (!isset($_SESSION['user']) || $_SESSION['user']['tipo'] !== 'funcionario') {
    header("Location: login.php"); exit;
}

// Gerar recibo
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao']) && $_POST['acao'] === 'gerar_recibo') {
    $id_aluno = $_POST['id_aluno'];
    $mes = $_POST['mes'];
    $valor = $_POST['valor'];
    $status = $_POST['status'];
    $data_pag = $_POST['data_pagamento'] ?? null;
    
    // Verifica se já existe
    $stmt = $conn->prepare("SELECT id FROM mensalidades WHERE id_aluno=? AND mes_referencia=?");
    $stmt->execute([$id_aluno, $mes]);
    
    if ($stmt->fetch()) {
        $conn->prepare("UPDATE mensalidades SET valor=?, status_pagamento=?, data_pagamento=? WHERE id_aluno=? AND mes_referencia=?")
             ->execute([$valor, $status, $data_pag, $id_aluno, $mes]);
    } else {
        $conn->prepare("INSERT INTO mensalidades (id_aluno, mes_referencia, valor, status_pagamento, data_pagamento) VALUES (?, ?, ?, ?, ?)")
             ->execute([$id_aluno, $mes, $valor, $status, $data_pag]);
    }
    
    echo "<script>alert('✅ Recibo gerado!'); window.location='recibos.php?id_aluno=$id_aluno';</script>";
    exit;
}

$alunos = $conn->query("SELECT a.*, n.nome_nivel, n.valor_propina FROM alunos a LEFT JOIN niveis n ON a.nivel_id = n.id WHERE a.status='ativo' ORDER BY a.nome")->fetchAll();

// Ver recibo de aluno específico
$recibo_aluno = null;
if (isset($_GET['id_aluno'])) {
    $stmt = $conn->prepare("SELECT a.*, n.nome_nivel, n.valor_propina FROM alunos a LEFT JOIN niveis n ON a.nivel_id = n.id WHERE a.id = ?");
    $stmt->execute([$_GET['id_aluno']]);
    $recibo_aluno = $stmt->fetch();
    
    $mensalidades = $conn->prepare("SELECT * FROM mensalidades WHERE id_aluno = ? ORDER BY mes_referencia DESC");
    $mensalidades->execute([$_GET['id_aluno']]);
    $lista_mens = $mensalidades->fetchAll();
}
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Recibos - YWS</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="header">
    <h1>The Young Wise School - YWS</h1>
    <p>Gestão de Recibos e Mensalidades</p>
</div>
<?php include 'menu_admin.php'; ?>

<div class="container">
    <h2>🧾 Gerar Recibo de Mensalidade</h2>
    <form method="POST" class="card">
        <input type="hidden" name="acao" value="gerar_recibo">
        <div style="display:grid; grid-template-columns: 2fr 1fr 1fr 1fr 1fr; gap:15px;">
            <div>
                <label>Aluno:</label>
                <select name="id_aluno" required onchange="atualizarValor(this)">
                    <option value="">-- Selecione --</option>
                    <?php foreach ($alunos as $a): ?>
                        <option value="<?= $a['id'] ?>" data-valor="<?= $a['valor_propina'] ?>">
                            <?= htmlspecialchars($a['nome']) ?> (<?= $a['nome_nivel'] ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label>Mês Referência:</label>
                <input type="month" name="mes" value="<?= date('Y-m') ?>" required>
            </div>
            <div>
                <label>Valor (Kz):</label>
                <input type="number" name="valor" id="valor" step="0.01" required>
            </div>
            <div>
                <label>Status:</label>
                <select name="status" required>
                    <option value="pago">Pago</option>
                    <option value="pendente">Pendente</option>
                    <option value="atrasado">Atrasado</option>
                </select>
            </div>
            <div>
                <label>Data Pagamento:</label>
                <input type="date" name="data_pagamento" value="<?= date('Y-m-d') ?>">
            </div>
        </div>
        <br>
        <button type="submit" class="btn-yws btn-green">💾 Gerar Recibo</button>
    </form>

    <?php if ($recibo_aluno): ?>
        <h2 style="margin-top:30px;">📋 Histórico de Mensalidades - <?= htmlspecialchars($recibo_aluno['nome']) ?></h2>
        <div class="card card-blue">
            <p><strong>Nível:</strong> <?= htmlspecialchars($recibo_aluno['nome_nivel']) ?></p>
            <p><strong>Valor da Mensalidade:</strong> <?= number_format($recibo_aluno['valor_propina'], 2, ',', '.') ?> Kz</p>
            <p><strong>Telefone:</strong> <?= htmlspecialchars($recibo_aluno['numero_telefone']) ?></p>
        </div>
        
        <table>
            <tr>
                <th>Mês</th>
                <th>Valor</th>
                <th>Status</th>
                <th>Data Pagamento</th>
                <th>Ação</th>
            </tr>
            <?php foreach ($lista_mens as $m): ?>
                <tr>
                    <td><?= htmlspecialchars($m['mes_referencia']) ?></td>
                    <td><?= number_format($m['valor'], 2, ',', '.') ?> Kz</td>
                    <td><span class="status-badge status-<?= $m['status_pagamento'] ?>"><?= strtoupper($m['status_pagamento']) ?></span></td>
                    <td><?= $m['data_pagamento'] ? date('d/m/Y', strtotime($m['data_pagamento'])) : '-' ?></td>
                    <td>
                        <?php if ($m['status_pagamento'] === 'pago'): ?>
                            <button onclick="imprimirRecibo(<?= $m['id'] ?>, '<?= htmlspecialchars($recibo_aluno['nome']) ?>', '<?= $m['mes_referencia'] ?>', <?= $m['valor'] ?>)" class="btn-yws" style="padding:5px 10px;">️</button>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php endif; ?>
</div>

<script>
function atualizarValor(select) {
    const option = select.options[select.selectedIndex];
    document.getElementById('valor').value = option.dataset.valor || '';
}

function imprimirRecibo(id, nome, mes, valor) {
    const janela = window.open('', '_blank', 'width=600,height=400');
    janela.document.write(`
        <html><head><title>Recibo - YWS</title>
        <style>body{font-family:Arial;padding:30px;} .header{text-align:center;border-bottom:3px solid #D32F2F;padding-bottom:15px;} 
        h1{color:#0D47A1;} .recibo{margin:30px 0;padding:20px;border:2px solid #0D47A1;border-radius:8px;}
        .valor{font-size:24px;color:#D32F2F;font-weight:bold;}</style></head><body>
        <div class="header">
            <h1>The Young Wise School - YWS</h1>
            <p>"More than just speak English"</p>
        </div>
        <div class="recibo">
            <h2>RECIBO DE PAGAMENTO</h2>
            <p><strong>Aluno:</strong> ${nome}</p>
            <p><strong>Referência:</strong> ${mes}</p>
            <p><strong>Valor Pago:</strong> <span class="valor">${valor.toLocaleString('pt-AO', {minimumFractionDigits:2})} Kz</span></p>
            <p><strong>Data:</strong> ${new Date().toLocaleDateString('pt-AO')}</p>
            <br><br>
            <p style="text-align:center;">_______________________________</p>
            <p style="text-align:center;">Assinatura da Secretária</p>
        </div>
        <script>window.print();<\/script>
        </body></html>
    `);
    janela.document.close();
}
</script>
</body>
</html>