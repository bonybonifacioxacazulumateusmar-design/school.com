<?php
include 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: login.php");
    exit;
}

if (!isset($_POST['usuario']) || !isset($_POST['senha'])) {
    die("❌ Formulário inválido. <a href='login.php'>Voltar</a>");
}

$usuario = trim($_POST['usuario']);
$senha   = $_POST['senha'];

if (empty($usuario) || empty($senha)) {
    echo "<script>alert('Preencha usuário e senha!'); window.location='login.php';</script>";
    exit;
}

// ===== FUNÇÃO DE VERIFICAÇÃO FLEXÍVEL (hash ou texto puro) =====
function verificar_senha_flexivel($senha_digitada, $senha_banco) {
    if (strlen($senha_banco) > 40) {
        return password_verify($senha_digitada, $senha_banco);
    }
    return $senha_digitada === $senha_banco;
}

// ===== FUNÇÃO DE REDIRECIONAMENTO POR CARGO =====
function redirecionar_por_cargo($user) {
    $cargo = $user['cargo'] ?? '';
    
    switch ($cargo) {
        case 'CEO':
        case 'Coordenador Geral':
            // Vê o painel mestre com as duas áreas
            return 'home.php';
            
        case 'Tesouraria':
            // Vai direto para o financeiro
            return 'dashboard_financeiro.php';
            
        case 'Professor':
            // Vai direto para suas turmas
            return 'minhas_turmas.php';
            
        case 'D. Pedagógico':
        case 'Secretária':
            // Vai para o dashboard estatístico/pedagógico
            return 'dashboard.php';
            
        case 'D. Marketing':
            // Vai para estatísticas de marketing
            return 'estatisticas_marketing.php';
            
        default:
            // Cargo desconhecido: vai para o painel mestre
            return 'home.php';
    }
}

// ===== TENTAR AUTENTICAR COMO FUNCIONÁRIO =====
try {
    $stmt = $conn->prepare("SELECT id, nome, cargo, senha, 'funcionario' as tipo FROM funcionarios WHERE usuario = ? AND status = 'ativo'");
    $stmt->execute([$usuario]);
    $func = $stmt->fetch();

    if ($func && verificar_senha_flexivel($senha, $func['senha'])) {
        unset($func['senha']);
        $_SESSION['user'] = $func;
        
        $destino = redirecionar_por_cargo($func);
        header("Location: $destino");
        exit;
    }
} catch (Exception $e) {
    // Silencioso - tenta aluno
}

// ===== TENTAR AUTENTICAR COMO ALUNO =====
try {
    $stmt = $conn->prepare("SELECT id, nome, senha, 'aluno' as tipo FROM alunos WHERE usuario = ? AND status = 'ativo'");
    $stmt->execute([$usuario]);
    $aluno = $stmt->fetch();

    if ($aluno && verificar_senha_flexivel($senha, $aluno['senha'])) {
        unset($aluno['senha']);
        $_SESSION['user'] = $aluno;
        header("Location: portal_aluno.php");
        exit;
    }
} catch (Exception $e) {
    // Silencioso
}

// ===== FALHOU =====
echo "<script>alert('❌ Usuário ou senha inválidos!'); window.location='login.php';</script>";
exit;
?>