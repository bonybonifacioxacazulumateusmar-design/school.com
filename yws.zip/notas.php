<?php
include 'config.php';
if (!isset($_SESSION['user'])) { header("Location: login.php"); exit; }

// Buscar todos os alunos com suas notas consolidadas
$sql = "SELECT a.id, a.nome, a.numero_telefone, n.nome_nivel, t.nome_turma,
        COUNT(DISTINCT av.id) as total_avaliacoes
        FROM alunos a
        LEFT JOIN niveis n ON a.nivel_id = n.id
        LEFT JOIN turmas t ON t.id_nivel = n.id
        LEFT JOIN avaliacoes av ON a.id = av.id_aluno
        WHERE a.status = 'ativo'
        GROUP BY a.id
        ORDER BY n.nome_nivel, a.nome";
$alunos = $conn->query($sql)->fetchAll();
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Resultados das Avaliações - YWS</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .filtro-box {
            background: #f5f7fa;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        .resultado-card {
            background: white;
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 15px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        .resultado-card h3 {
            margin: 0 0 10px 0;
            color: #0D47A1;
            border-bottom: 2px solid #D32F2F;
            padding-bottom: 8px;
        }
        .nota-item {
            display: inline-block;
            margin: 5px 10px 5px 0;
            padding: 5px 10px;
            background: #f0f0f0;
            border-radius: 4px;
            font-size: 13px;
        }
        .nota-item strong {
            color: #0D47A1;
        }
        .media-box {
            background: linear-gradient(135deg, #0D47A1, #1565C0);
            color: white;
            padding: 10px 15px;
            border-radius: 6px;
            display: inline-block;
            margin-top: 10px;
            font-weight: bold;
        }
        .status-aprovado { color: #2E7D32; font-weight: bold; }
        .status-reprovado { color: #D32F2F; font-weight: bold; }
    </style>
</head>
<body>
<div class="header">
    <h1>The Young Wise School</h1>
    <p style="font-size:14px; letter-spacing:2px;">CENTRO DE FORMAÇÃO</p>
    <p>📊 Resultados das Avaliações</p>
</div>
<?php include 'menu_admin.php'; ?>

<div class="container">
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
        <h2>📋 Consulta de Resultados</h2>
        <a href="avaliacoes.php" class="btn-yws btn-green">➕ Lançar Nova Avaliação</a>
    </div>

    <!-- FILTROS -->
    <div class="filtro-box">
        <strong>🔍 Filtrar por:</strong>
        <select id="filtroNivel" onchange="filtrarResultados()" style="padding:8px; margin-left:10px;">
            <option value="">Todos os Níveis</option>
            <?php
            $niveis = $conn->query("SELECT DISTINCT nome_nivel FROM niveis ORDER BY nome_nivel")->fetchAll();
            foreach ($niveis as $n):
            ?>
                <option value="<?= htmlspecialchars($n['nome_nivel']) ?>"><?= htmlspecialchars($n['nome_nivel']) ?></option>
            <?php endforeach; ?>
        </select>
    </div>

    <!-- RESULTADOS -->
    <?php if (empty($alunos)): ?>
        <div class="card" style="text-align:center; padding:30px;">
            Nenhum aluno encontrado com avaliações registradas.
        </div>
    <?php else: 
        $nivel_atual = '';
        foreach ($alunos as $aluno):
            // Buscar todas as avaliações deste aluno
            $stmt = $conn->prepare("SELECT av.*, t.nome_turma 
                                   FROM avaliacoes av 
                                   LEFT JOIN turmas t ON av.id_turma = t.id 
                                   WHERE av.id_aluno = ? 
                                   ORDER BY av.data_avaliacao DESC");
            $stmt->execute([$aluno['id']]);
            $avaliacoes = $stmt->fetchAll();
            
            // Calcular médias por tipo
            $medias = [];
            $total_geral = 0;
            $count_geral = 0;
            
            foreach ($avaliacoes as $av) {
                $tipo = $av['tipo_avaliacao'];
                if (!isset($medias[$tipo])) {
                    $medias[$tipo] = ['soma' => 0, 'count' => 0];
                }
                $medias[$tipo]['soma'] += $av['nota'];
                $medias[$tipo]['count']++;
                $total_geral += $av['nota'];
                $count_geral++;
            }
            
            $media_geral = $count_geral > 0 ? $total_geral / $count_geral : 0;
            $status = $media_geral >= 10 ? 'Aprovado' : ($count_geral > 0 ? 'Reprovado' : 'Sem Avaliações');
            
            if ($aluno['nome_nivel'] !== $nivel_atual):
                $nivel_atual = $aluno['nome_nivel'];
            ?>
                <h3 style="background:#0D47A1; color:white; padding:10px 15px; border-radius:6px; margin:20px 0 15px 0;">
                     <?= htmlspecialchars($nivel_atual) ?>
                </h3>
            <?php endif; ?>
            
            <div class="resultado-card" data-nivel="<?= htmlspecialchars($aluno['nome_nivel']) ?>">
                <h3>👤 <?= htmlspecialchars($aluno['nome']) ?></h3>
                <p style="margin:5px 0; color:#666; font-size:13px;">
                    <strong>Turma:</strong> <?= htmlspecialchars($aluno['nome_turma'] ?? 'N/A') ?> | 
                    <strong>Total de Avaliações:</strong> <?= $aluno['total_avaliacoes'] ?>
                </p>
                
                <?php if (empty($avaliacoes)): ?>
                    <p style="color:#999; font-style:italic; margin:10px 0;">Nenhuma avaliação registrada.</p>
                <?php else: ?>
                    <div style="margin:10px 0;">
                        <strong>Detalhes das Avaliações:</strong><br>
                        <?php foreach ($avaliacoes as $av): 
                            $pct = ($av['nota'] / $av['nota_maxima']) * 100;
                        ?>
                            <div class="nota-item">
                                <strong><?= strtoupper(str_replace('_', ' ', $av['tipo_avaliacao'])) ?>:</strong> 
                                <?= number_format($av['nota'], 1) ?>/<?= $av['nota_maxima'] ?> 
                                (<?= number_format($pct, 1) ?>%) - 
                                <small><?= date('d/m/Y', strtotime($av['data_avaliacao'])) ?></small>
                            </div>
                        <?php endforeach; ?>
                    </div>
                    
                    <!-- Médias por tipo -->
                    <div style="margin:10px 0; padding:10px; background:#f9f9f9; border-radius:6px;">
                        <strong>Médias por Tipo:</strong><br>
                        <?php foreach ($medias as $tipo => $dados): 
                            $media = $dados['soma'] / $dados['count'];
                        ?>
                            <span class="nota-item" style="background:#e3f2fd;">
                                <strong><?= strtoupper(str_replace('_', ' ', $tipo)) ?>:</strong> 
                                <?= number_format($media, 1) ?>
                            </span>
                        <?php endforeach; ?>
                    </div>
                    
                    <!-- Média Geral -->
                    <div class="media-box">
                        📊 Média Geral: <?= number_format($media_geral, 1) ?> | 
                        <span class="<?= $status === 'Aprovado' ? 'status-aprovado' : 'status-reprovado' ?>">
                            <?= $status ?>
                        </span>
                    </div>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<script>
function filtrarResultados() {
    const nivelFiltro = document.getElementById('filtroNivel').value;
    const cards = document.querySelectorAll('.resultado-card');
    
    cards.forEach(card => {
        if (nivelFiltro === '' || card.dataset.nivel === nivelFiltro) {
            card.style.display = 'block';
        } else {
            card.style.display = 'none';
        }
    });
}
</script>
</body>
</html>