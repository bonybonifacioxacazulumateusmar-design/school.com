<?php
include 'config.php';
if (!isset($_SESSION['user'])) { header("Location: login.php"); exit; }

$ano = $_GET['ano'] ?? date('Y');

// Calcular dados mensais com lucro líquido
$meses = ['Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];
$dados_mensais = [];
$total_anual_arrecadado = 0;
$total_anual_repasse = 0;

for ($m = 1; $m <= 12; $m++) {
    $entradas = $conn->query("SELECT COALESCE(SUM(valor),0) FROM entradas WHERE MONTH(data)=$m AND YEAR(data)=$ano")->fetchColumn();
    $saidas = $conn->query("SELECT COALESCE(SUM(valor),0) FROM saidas WHERE MONTH(data)=$m AND YEAR(data)=$ano")->fetchColumn();
    
    // Despesas fixas: Aluguel (15.000) + RH Material (7.000) = 22.000
    $despesas_fixas = 22000.00;
    $lucro_liquido = $entradas - $saidas - $despesas_fixas;
    if ($lucro_liquido < 0) $lucro_liquido = 0;
    
    $repasse_25 = $lucro_liquido * 0.25;
    
    $dados_mensais[] = [
        'mes' => $meses[$m-1],
        'entradas' => $entradas,
        'saidas' => $saidas,
        'lucro' => $lucro_liquido,
        'repasse' => $repasse_25
    ];
    
    $total_anual_arrecadado += $entradas;
    $total_anual_repasse += $repasse_25;
}
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Relatório ao Financiador - YWS</title>
    <link rel="stylesheet" href="style.css">
    <style>
        @media print {
            .no-print { display: none !important; }
            body { background: white; }
            .container { box-shadow: none; border: none; max-width: 100%; }
        }
        .assinatura-box {
            display: flex;
            justify-content: space-between;
            margin-top: 80px;
            gap: 40px;
        }
        .assinatura {
            flex: 1;
            text-align: center;
            padding-top: 10px;
        }
        .assinatura .linha {
            border-top: 1px solid #333;
            padding-top: 10px;
            margin-bottom: 5px;
        }
        .assinatura .cargo {
            font-weight: bold;
            font-size: 14px;
        }
        .assinatura .nome {
            font-size: 13px;
            color: #666;
        }
        .total-box {
            background: linear-gradient(135deg, #0D47A1, #1565C0);
            color: white;
            padding: 25px;
            border-radius: 10px;
            text-align: center;
            margin-top: 30px;
        }
        .total-box h2 { margin: 10px 0; font-size: 32px; }
    </style>
</head>
<body>
<div class="no-print">
    <div class="header"><h1>The Young Wise School - YWS</h1><p>Relatório Financeiro para Financiador</p></div>
    <?php include 'menu_admin.php'; ?>
</div>

<div class="container">
    <div style="text-align:center; border-bottom: 3px solid #D32F2F; padding-bottom: 20px; margin-bottom: 30px;">
        <img src="logo.png" alt="YWS" style="max-width:100px;" onerror="this.style.display='none'">
        <h1 style="color:#0D47A1; margin:10px 0;">The Young Wise School - YWS</h1>
        <p style="font-style:italic; color:#666;">"More than just speak English"</p>
        <h2 style="margin-top:20px;">RELATÓRIO ANUAL DE REPASSE AO FINANCIADOR</h2>
        <p><strong>Período:</strong> Ano de <?= $ano ?></p>
        <p><strong>Regra:</strong> 25% do Lucro Líquido Mensal da Empresa</p>
        <p style="font-size:13px; color:#666;"><em>(Lucro Líquido = Entradas - Saídas - Despesas Fixas: Aluguel 15.000 Kz + Material RH 7.000 Kz)</em></p>
    </div>

    <table style="margin-top:20px;">
        <tr>
            <th>Mês</th>
            <th>Entradas</th>
            <th>Saídas</th>
            <th>Despesas Fixas</th>
            <th>Lucro Líquido</th>
            <th>Repasse 25%</th>
        </tr>
        <?php foreach ($dados_mensais as $d): ?>
        <tr>
            <td><strong><?= $d['mes'] ?></strong></td>
            <td><?= number_format($d['entradas'], 2, ',', '.') ?> Kz</td>
            <td><?= number_format($d['saidas'], 2, ',', '.') ?> Kz</td>
            <td>22.000,00 Kz</td>
            <td><strong><?= number_format($d['lucro'], 2, ',', '.') ?> Kz</strong></td>
            <td style="color:#D32F2F; font-weight:bold;"><?= number_format($d['repasse'], 2, ',', '.') ?> Kz</td>
        </tr>
        <?php endforeach; ?>
    </table>

    <div class="total-box">
        <p style="margin:0; font-size:16px; opacity:0.9;">TOTAL REPASSADO AO FINANCIADOR NO ANO DE <?= $ano ?></p>
        <h2><?= number_format($total_anual_repasse, 2, ',', '.') ?> Kz</h2>
        <p style="margin:5px 0 0 0; font-size:14px;">(Sobre um total arrecadado de <?= number_format($total_anual_arrecadado, 2, ',', '.') ?> Kz)</p>
    </div>

    <!-- ASSINATURAS SEPARADAS -->
    <div class="assinatura-box">
        <div class="assinatura">
            <div class="linha">
                <div class="cargo">Direção Financeira - YWS</div>
                <div class="nome">_______________________________</div>
                <div class="nome">Nome e Carimbo</div>
            </div>
        </div>
        <div class="assinatura">
            <div class="linha">
                <div class="cargo">Representante do Financiador</div>
                <div class="nome">_______________________________</div>
                <div class="nome">Nome e Carimbo</div>
            </div>
        </div>
    </div>
    
    <p style="text-align:center; margin-top:40px; font-size:12px; color:#999;" class="no-print">
        Documento gerado eletronicamente pelo Sistema YWS em <?= date('d/m/Y H:i:s') ?>
    </p>

    <div style="text-align:center; margin-top:30px;" class="no-print">
        <button onclick="window.print()" class="btn-yws btn-green">🖨️ Imprimir / Salvar PDF</button>
        <a href="dashboard_financeiro.php" class="btn-yws">← Voltar</a>
    </div>
</div>
</body>
</html>