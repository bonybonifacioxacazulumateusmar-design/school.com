<?php
include 'config.php';
if (!isset($_SESSION['user'])) { header("Location: login.php"); exit; }

// Exclusão
if (isset($_GET['excluir_saida'])) {
    if (!pode_excluir()) {
        die("<script>alert('Apenas administradores podem excluir.'); window.history.back();</script>");
    }
    $conn->prepare("DELETE FROM saidas WHERE id = ?")->execute([$_GET['excluir_saida']]);
    echo "<script>alert('Saída excluída.'); window.location='financeiro_saidas.php';</script>";
    exit;
}

// Registrar saída manual
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao']) && $_POST['acao'] === 'registrar_saida') {
    $tipo = $_POST['tipo'];
    $descricao = $_POST['descricao'];
    $valor = $_POST['valor'];
    $data = $_POST['data'];
    
    $conn->prepare("INSERT INTO saidas (tipo, descricao, valor, data) VALUES (?, ?, ?, ?)")
         ->execute([$tipo, $descricao, $valor, $data]);
    
    // Se for salário, registrar na tabela salarios também
    if ($tipo === 'salario' && isset($_POST['id_funcionario'])) {
        $mes_atual = date('F');
        $ano_atual = date('Y');
        $conn->prepare("INSERT INTO salarios (id_funcionario, mes, ano, valor_liquido, status_pagamento) VALUES (?, ?, ?, ?, 'pago')")
             ->execute([$_POST['id_funcionario'], $mes_atual, $ano_atual, $valor]);
    }
    
    echo "<script>alert('✅ Saída registrada!'); window.location='financeiro_saidas.php';</script>";
    exit;
}

// Despesas fixas automáticas
if (isset($_GET['fixo'])) {
    $data = date('Y-m-d');
    $mes_atual = date('F Y');
    if ($_GET['fixo'] === 'aluguel') {
        $conn->prepare("INSERT INTO saidas (tipo, descricao, valor, data) VALUES ('aluguel', 'Aluguel - $mes_atual', 15000.00, ?)")->execute([$data]);
    } elseif ($_GET['fixo'] === 'rh') {
        $conn->prepare("INSERT INTO saidas (tipo, descricao, valor, data) VALUES ('rh_material', 'Material RH - $mes_atual', 7000.00, ?)")->execute([$data]);
    } elseif ($_GET['fixo'] === 'energia') {
        $conn->prepare("INSERT INTO saidas (tipo, descricao, valor, data) VALUES ('energia', 'Energia Elétrica - $mes_atual', ?, ?)")->execute([$_GET['valor'] ?? 0, $data]);
    }
    echo "<script>alert('✅ Despesa fixa registrada!'); window.location='financeiro_saidas.php';</script>";
    exit;
}

$saidas = $conn->query("SELECT * FROM saidas ORDER BY data DESC LIMIT 20")->fetchAll();
$funcionarios = $conn->query("SELECT id, nome, cargo, salario FROM funcionarios WHERE status='ativo'")->fetchAll();
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Saídas Financeiras - YWS</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="header" style="background: linear-gradient(135deg, #B71C1C 0%, #D32F2F 100%);">
    <h1>The Young Wise School - YWS</h1>
    <p style="font-style: italic; color: #ffcc00;">"More than just speak English"</p>
    <p>Módulo Financeiro: Saídas</p>
</div>
<?php include 'menu_admin.php'; ?>

<div class="container">
    <!-- DESPESAS FIXAS RÁPIDAS -->
    <h2>⚡ Despesas Fixas Mensais</h2>
    <div style="display:flex; gap:10px; flex-wrap:wrap; margin-bottom:20px;">
        <a href="?fixo=aluguel" class="btn-yws" style="background:#F57C00;" onclick="return confirm('Registrar Aluguel de 15.000 Kz?')">🏠 Aluguel (15.000 Kz)</a>
        <a href="?fixo=rh" class="btn-yws" style="background:#1565C0;" onclick="return confirm('Registrar Material RH de 7.000 Kz?')">📎 Material RH (7.000 Kz)</a>
        <a href="?fixo=energia&valor=5000" class="btn-yws" style="background:#6A1B9A;" onclick="return confirm('Registrar Energia de 5.000 Kz?')">⚡ Energia (5.000 Kz)</a>
    </div>

    <!-- REGISTRAR SAÍDA MANUAL -->
    <h2>💸 Registrar Nova Saída</h2>
    <form method="POST" class="card">
        <input type="hidden" name="acao" value="registrar_saida">
        <div style="display:grid; grid-template-columns: 1fr 2fr 1fr 1fr; gap:15px;">
            <div>
                <label><strong>Tipo:</strong></label>
                <select name="tipo" id="tipoSaida" required onchange="mostrarFuncionario()" style="width:100%; padding:10px;">
                    <option value="salario">Salário Funcionário</option>
                    <option value="estoque">Compra de Estoque</option>
                    <option value="manutencao">Manutenção</option>
                    <option value="outro">Outro</option>
                </select>
            </div>
            <div>
                <label><strong>Descrição:</strong></label>
                <input type="text" name="descricao" id="descricaoSaida" placeholder="Ex: Salário Setembro" required style="width:100%; padding:10px;">
            </div>
            <div>
                <label><strong>Valor (Kz):</strong></label>
                <input type="number" name="valor" id="valorSaida" step="0.01" required style="width:100%; padding:10px;">
            </div>
            <div>
                <label><strong>Data:</strong></label>
                <input type="date" name="data" value="<?= date('Y-m-d') ?>" required style="width:100%; padding:10px;">
            </div>
        </div>
        
        <div id="divFuncionario" style="margin-top:15px; display:none;">
            <label><strong>Funcionário:</strong></label>
            <select name="id_funcionario" id="selectFuncionario" onchange="preencherSalario()" style="width:100%; padding:10px; margin-top:5px;">
                <option value="">-- Selecione --</option>
                <?php foreach ($funcionarios as $f): ?>
                    <option value="<?= $f['id'] ?>" data-salario="<?= $f['salario'] ?>"><?= htmlspecialchars($f['nome']) ?> - <?= htmlspecialchars($f['cargo']) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        
        <br>
        <button type="submit" class="btn-yws" style="background:#D32F2F;">💸 Registrar Saída</button>
    </form>

    <!-- HISTÓRICO -->
    <h2 style="margin-top:30px;">📜 Histórico de Saídas</h2>
    <table>
        <tr><th>Data</th><th>Tipo</th><th>Descrição</th><th>Valor</th><?php if (pode_excluir()): ?><th>Ação</th><?php endif; ?></tr>
        <?php foreach ($saidas as $s): ?>
        <tr>
            <td><?= date('d/m/Y', strtotime($s['data'])) ?></td>
            <td><span class="status-badge" style="background:#D32F2F;"><?= strtoupper(str_replace('_', ' ', $s['tipo'])) ?></span></td>
            <td><?= htmlspecialchars($s['descricao']) ?></td>
            <td><strong><?= formatar_moeda($s['valor']) ?></strong></td>
            <?php if (pode_excluir()): ?>
                <td><a href="?excluir_saida=<?= $s['id'] ?>" class="btn-yws" style="padding:5px 10px; background:#D32F2F;" onclick="return confirm('Excluir?')">🗑️</a></td>
            <?php endif; ?>
        </tr>
        <?php endforeach; ?>
    </table>
</div>

<script>
function mostrarFuncionario() {
    const tipo = document.getElementById('tipoSaida').value;
    document.getElementById('divFuncionario').style.display = (tipo === 'salario') ? 'block' : 'none';
}
function preencherSalario() {
    const select = document.getElementById('selectFuncionario');
    const salario = select.options[select.selectedIndex].getAttribute('data-salario');
    document.getElementById('valorSaida').value = salario || '';
    const mes = new Date().toLocaleDateString('pt-BR', {month: 'long', year: 'numeric'});
    document.getElementById('descricaoSaida').value = 'Salário - ' + mes;
}
</script>
</body>
</html>