<?php
// Controle de acesso baseado no cargo
function verificar_acesso($acao_requerida) {
    if (!isset($_SESSION['user'])) {
        header("Location: login.php");
        exit;
    }
    
    if ($_SESSION['user']['tipo'] !== 'funcionario') {
        return false;
    }
    
    if (!tem_permissao($_SESSION['user']['cargo'], $acao_requerida)) {
        echo "<div style='background:#f8d7da;color:#721c24;padding:20px;border-radius:8px;margin:20px;text-align:center;'>";
        echo "<h2>🚫 Acesso Negado</h2>";
        echo "<p>Seu cargo (<strong>" . $_SESSION['user']['cargo'] . "</strong>) não tem permissão para esta ação.</p>";
        echo "<a href='dashboard.php' class='btn-yws'>Voltar ao Dashboard</a>";
        echo "</div>";
        exit;
    }
    
    return true;
}
?>