<?php
$host = 'localhost';
$db   = 'yws_db';
$user = 'root';
$pass = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db;charset=utf8mb4", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    echo "<h1 style='color:green;'>Criando tabelas financeiras...</h1>";
    
    $pdo->exec("CREATE TABLE IF NOT EXISTS entradas (id INT AUTO_INCREMENT PRIMARY KEY, tipo VARCHAR(50) NOT NULL, origem VARCHAR(100) NOT NULL, valor DECIMAL(10,2) NOT NULL, data DATE NOT NULL)");
    echo "✅ Tabela 'entradas' criada<br>";
    
    $pdo->exec("CREATE TABLE IF NOT EXISTS propinas_pagas (id INT AUTO_INCREMENT PRIMARY KEY, id_aluno INT NOT NULL, mes VARCHAR(20) NOT NULL, ano INT NOT NULL, valor_pago DECIMAL(10,2) NOT NULL, data_pagamento DATE NOT NULL)");
    echo "✅ Tabela 'propinas_pagas' criada<br>";
    
    $pdo->exec("CREATE TABLE IF NOT EXISTS saidas (id INT AUTO_INCREMENT PRIMARY KEY, tipo VARCHAR(50) NOT NULL, descricao VARCHAR(255) NOT NULL, valor DECIMAL(10,2) NOT NULL, data DATE NOT NULL)");
    echo "✅ Tabela 'saidas' criada<br>";
    
    $pdo->exec("CREATE TABLE IF NOT EXISTS salarios (id INT AUTO_INCREMENT PRIMARY KEY, id_funcionario INT NOT NULL, mes VARCHAR(20) NOT NULL, ano INT NOT NULL, valor_liquido DECIMAL(10,2) NOT NULL, status_pagamento VARCHAR(20) DEFAULT 'pendente')");
    echo "✅ Tabela 'salarios' criada<br>";
    
    $pdo->exec("CREATE TABLE IF NOT EXISTS repasse_financiador (id INT AUTO_INCREMENT PRIMARY KEY, mes VARCHAR(20) NOT NULL, ano INT NOT NULL, total_arrecadado DECIMAL(10,2) NOT NULL, valor_25_porcento DECIMAL(10,2) NOT NULL, status VARCHAR(20) DEFAULT 'pendente', data_repasse DATE)");
    echo "✅ Tabela 'repasse_financiador' criada<br>";
    
    $pdo->exec("CREATE TABLE IF NOT EXISTS estoque (id_item INT AUTO_INCREMENT PRIMARY KEY, nome VARCHAR(100) NOT NULL, qtd_entrada INT DEFAULT 0, qtd_saida INT DEFAULT 0, qtd_atual INT DEFAULT 0)");
    echo "✅ Tabela 'estoque' criada<br>";
    
    $pdo->exec("INSERT IGNORE INTO estoque (nome, qtd_entrada, qtd_atual) VALUES ('Marcadores', 50, 50), ('Folhas A4', 20, 20), ('Apagadores', 10, 10)");
    echo "✅ Itens de estoque inseridos<br>";
    
    echo "<h2 style='color:green; margin-top:30px;'>🎉 SUCESSO! Todas as tabelas foram criadas!</h2>";
    echo "<a href='financeiro_entradas.php' style='padding:15px 30px; background:#0D47A1; color:white; text-decoration:none; border-radius:5px; display:inline-block; margin-top:20px;'>Ir para Entradas Financeiras</a>";
    echo "<p style='color:red; margin-top:30px;'><strong>⚠️ DELETE este arquivo (setup.php) agora!</strong></p>";
    
} catch (PDOException $e) {
    echo "<h1 style='color:red;'>ERRO: " . $e->getMessage() . "</h1>";
}
?>