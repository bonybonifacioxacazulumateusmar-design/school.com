<?php
include 'config.php';
if (!isset($_SESSION['user'])) { header("Location: login.php"); exit; }

// Processar cadastro
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao']) && $_POST['acao'] === 'cadastrar') {
    $nome = trim($_POST['nome']);
    $curso = trim($_POST['curso'] ?? 'Ingles');
    $nivel_id = (int)$_POST['nivel_id'];
    $telefone = trim($_POST['telefone'] ?? '');
    $usuario = trim($_POST['usuario']);
    $senha = trim($_POST['senha']);
    $data_matricula = $_POST['data_matricula'] ?? date('Y-m-d');
    
    try {
        // Verifica se usuário já existe
        $check = $conn->prepare("SELECT id FROM alunos WHERE usuario = ?");
        $check->execute([$usuario]);
        if ($check->fetch()) {
            echo "<script>alert('⚠️ Este usuário/e-mail já está cadastrado! Use outro.'); window.history.back();</script>";
            exit;
        }
        
        $senha_hash = hash_senha($senha);
        
        $conn->prepare("INSERT INTO alunos (nome, curso, nivel_id, data_matricula, status, numero_telefone, usuario, senha) 
                        VALUES (?, ?, ?, ?, 'ativo', ?, ?, ?)")
             ->execute([$nome, $curso, $nivel_id, $data_matricula, $telefone, $usuario, $senha_hash]);
        
        echo "<script>alert('✅ Aluno cadastrado com sucesso!'); window.location='cadastro_alunos.php';</script>";
        exit;
    } catch (PDOException $e) {
        echo "<script>alert(' Erro: " . addslashes($e->getMessage()) . "'); window.history.back();</script>";
        exit;
    }
}

// Eliminar aluno
if (isset($_GET['eliminar']) && pode_excluir()) {
    $conn->prepare("DELETE FROM alunos WHERE id = ?")->execute([$_GET['eliminar']]);
    echo "<script>alert('Aluno eliminado!'); window.location='cadastro_alunos.php';</script>";
    exit;
}

$alunos = $conn->query("SELECT a.*, n.nome_nivel FROM alunos a LEFT JOIN niveis n ON a.nivel_id = n.id ORDER BY a.nome")->fetchAll();
$niveis = $conn->query("SELECT id, nome_nivel FROM niveis ORDER BY id")->fetchAll();
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Cadastro de Alunos - YWS</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="header">
    <h1>The Young Wise School</h1>
    <p style="font-size:14px; letter-spacing:2px;">CENTRO DE FORMAÇÃO</p>
    <p>Cadastro de Alunos</p>
</div>
<?php include 'menu_admin.php'; ?>

<div class="container">
    <h2>➕ Cadastrar Novo Aluno</h2>
    <form method="POST" class="card">
        <input type="hidden" name="acao" value="cadastrar">
        <div style="display:grid; grid-template-columns: 1fr 1fr; gap:15px;">
            <div>
                <label><strong>Nome Completo:</strong></label>
                <input type="text" name="nome" required style="width:100%; padding:10px;">
            </div>
            <div>
                <label><strong>Curso:</strong></label>
                <input type="text" name="curso" value="Inglês" required style="width:100%; padding:10px;">
            </div>
            <div>
                <label><strong>Nível:</strong></label>
                <select name="nivel_id" required style="width:100%; padding:10px;">
                    <?php foreach ($niveis as $n): ?>
                        <option value="<?= $n['id'] ?>"><?= htmlspecialchars($n['nome_nivel']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label><strong>Telefone:</strong></label>
                <input type="text" name="telefone" style="width:100%; padding:10px;">
            </div>
            <div>
                <label><strong>Usuário (e-mail):</strong></label>
                <input type="text" name="usuario" required style="width:100%; padding:10px;">
            </div>
            <div>
                <label><strong>Senha:</strong></label>
                <input type="password" name="senha" required style="width:100%; padding:10px;">
            </div>
            <div>
                <label><strong>Data de Matrícula:</strong></label>
                <input type="date" name="data_matricula" value="<?= date('Y-m-d') ?>" required style="width:100%; padding:10px;">
            </div>
        </div>
        <br>
        <button type="submit" class="btn-yws btn-green">💾 Cadastrar Aluno</button>
    </form>

    <h2 style="margin-top:30px;">📋 Lista de Alunos</h2>
    <div style="margin-bottom:15px;">
        <button onclick="window.print()" class="btn-yws">🖨️ Imprimir Lista</button>
    </div>
    <table>
        <tr><th>ID</th><th>Nome</th><th>Nível</th><th>Telefone</th><th>Usuário</th><th>Status</th>
        <?php if (pode_excluir()): ?><th>Ação</th><?php endif; ?></tr>
        <?php foreach ($alunos as $a): ?>
        <tr>
            <td><?= $a['id'] ?></td>
            <td><strong><?= htmlspecialchars($a['nome']) ?></strong></td>
            <td><?= htmlspecialchars($a['nome_nivel']) ?></td>
            <td><?= htmlspecialchars($a['numero_telefone']) ?></td>
            <td><?= htmlspecialchars($a['usuario']) ?></td>
            <td><span class="status-badge status-<?= $a['status'] ?>"><?= strtoupper($a['status']) ?></span></td>
            <?php if (pode_excluir()): ?>
                <td><a href="?eliminar=<?= $a['id'] ?>" class="btn-yws" style="padding:5px 10px; background:#D32F2F;" onclick="return confirm('Eliminar?')">🗑️</a></td>
            <?php endif; ?>
        </tr>
        <?php endforeach; ?>
    </table>
</div>
</body>
</html>