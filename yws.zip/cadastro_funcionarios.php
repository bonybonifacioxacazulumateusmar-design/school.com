<?php
include 'config.php';
if (!isset($_SESSION['user']) || !pode_excluir()) { header("Location: dashboard.php"); exit; }

// Tabela de backup de funcionários (crie-a se não existir, veja Passo 6)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao'])) {
    $nome = trim($_POST['nome']);
    $cargo = trim($_POST['cargo']);
    $salario = (float)$_POST['salario'];
    $usuario = trim($_POST['usuario']);
    $senha = trim($_POST['senha']);
    $data_adm = $_POST['data_admissao'] ?? date('Y-m-d');
    $depto = (int)$_POST['departamento_id'];

    try {
        // 1. BACKUP AUTOMÁTICO (Log de segurança)
        $conn->prepare("INSERT INTO log_backup_funcionarios (nome, usuario, senha_criptografada, data_backup, acao) VALUES (?, ?, ?, NOW(), 'CADASTRO/ATUALIZAÇÃO')")
             ->execute([$nome, $usuario, hash_senha($senha)]);

        // 2. Salvar no banco principal
        if (isset($_POST['id']) && $_POST['id'] > 0) {
            // Edição
            $conn->prepare("UPDATE funcionarios SET nome=?, cargo=?, salario=?, usuario=?, senha=?, data_admissao=?, departamento_id=? WHERE id=?")
                 ->execute([$nome, $cargo, $salario, $usuario, hash_senha($senha), $data_adm, $depto, $_POST['id']]);
            $msg = "Funcionário atualizado e backup gerado!";
        } else {
            // Novo
            $conn->prepare("INSERT INTO funcionarios (nome, cargo, salario, usuario, senha, data_admissao, departamento_id, status) VALUES (?, ?, ?, ?, ?, ?, ?, 'ativo')")
                 ->execute([$nome, $cargo, $salario, $usuario, hash_senha($senha), $data_adm, $depto]);
            $msg = "Funcionário cadastrado e backup gerado!";
        }
        echo "<script>alert('✅ $msg'); window.location='cadastro_funcionarios.php';</script>";
        exit;
    } catch (PDOException $e) {
        echo "<script>alert('Erro: " . addslashes($e->getMessage()) . "'); window.history.back();</script>";
        exit;
    }
}

$funcionarios = $conn->query("SELECT f.*, d.nome as depto FROM funcionarios f LEFT JOIN departamentos d ON f.departamento_id = d.id")->fetchAll();
$deptos = $conn->query("SELECT id, nome FROM departamentos")->fetchAll();
?>
<!-- (O HTML do formulário permanece o mesmo do seu arquivo atual, apenas garanta que o form tenha method="POST") -->
<!DOCTYPE html>
<html lang="pt">
<head><title>Funcionários - YWS</title><link rel="stylesheet" href="style.css"></head>
<body>
<div class="header"><h1>The Young Wise School</h1><p style="font-size:14px; letter-spacing:2px;">CENTRO DE FORMAÇÃO</p><p>Gestão de Funcionários</p></div>
<?php include 'menu_admin.php'; ?>
<div class="container">
    <h2>➕ Cadastrar / Editar Funcionário</h2>
    <form method="POST" class="card">
        <input type="hidden" name="acao" value="salvar">
        <!-- Adicione seus inputs de nome, cargo, salario, usuario, senha, data_admissao, departamento_id aqui -->
        <div style="display:grid; grid-template-columns: 1fr 1fr; gap:15px;">
            <input type="text" name="nome" placeholder="Nome Completo" required style="padding:10px;">
            <input type="text" name="cargo" placeholder="Cargo" required style="padding:10px;">
            <input type="number" name="salario" placeholder="Salário (Kz)" step="0.01" required style="padding:10px;">
            <input type="text" name="usuario" placeholder="Usuário (Login)" required style="padding:10px;">
            <input type="password" name="senha" placeholder="Senha" required style="padding:10px;">
            <select name="departamento_id" required style="padding:10px;">
                <?php foreach($deptos as $d): ?><option value="<?= $d['id'] ?>"><?= $d['nome'] ?></option><?php endforeach; ?>
            </select>
        </div>
        <br><button type="submit" class="btn-yws btn-green">💾 Salvar com Backup Automático</button>
    </form>
    
    <h2 style="margin-top:30px;">📋 Lista de Funcionários</h2>
    <button onclick="window.print()" class="btn-yws no-print">🖨️ Imprimir Lista</button>
    <table>
        <tr><th>Nome</th><th>Cargo</th><th>Departamento</th><th>Salário</th><th>Usuário</th></tr>
        <?php foreach($funcionarios as $f): ?>
        <tr><td><?= htmlspecialchars($f['nome']) ?></td><td><?= htmlspecialchars($f['cargo']) ?></td><td><?= htmlspecialchars($f['depto']) ?></td><td><?= formatar_moeda($f['salario']) ?></td><td><?= htmlspecialchars($f['usuario']) ?></td></tr>
        <?php endforeach; ?>
    </table>
</div>
</body>
</html>