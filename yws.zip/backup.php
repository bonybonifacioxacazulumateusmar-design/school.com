<?php
include 'config.php';
if (!isset($_SESSION['user'])) { header("Location: login.php"); exit; }

// Criar pasta de backups se não existir
if (!is_dir('backups')) {
    mkdir('backups', 0777, true);
}

// ===== EXCLUIR BACKUP (ação separada) =====
if (isset($_GET['excluir'])) {
    if (!pode_excluir()) {
        die("<script>alert('Apenas administradores podem excluir backups.'); window.history.back();</script>");
    }
    $arquivo = 'backups/' . basename($_GET['excluir']);
    if (file_exists($arquivo)) {
        unlink($arquivo);
        echo "<script>alert('Backup excluído!'); window.location='backup.php';</script>";
    }
    exit;
}

// ===== GERAR NOVO BACKUP =====
if (isset($_GET['gerar'])) {
    try {
        $return = "-- Backup YWS\n";
        $return .= "-- Data: " . date('Y-m-d H:i:s') . "\n";
        $return .= "-- Usuário: " . $_SESSION['user']['nome'] . "\n\n";
        $return .= "SET FOREIGN_KEY_CHECKS=0;\n\n";

        $tabelas = $conn->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);

        foreach ($tabelas as $tabela) {
            $estrutura = $conn->query("SHOW CREATE TABLE `$tabela`")->fetch(PDO::FETCH_NUM);
            $return .= "DROP TABLE IF EXISTS `$tabela`;\n";
            $return .= $estrutura[1] . ";\n\n";

            $dados = $conn->query("SELECT * FROM `$tabela`")->fetchAll(PDO::FETCH_ASSOC);
            foreach ($dados as $linha) {
                $valores = [];
                foreach ($linha as $valor) {
                    $valores[] = ($valor === null) ? "NULL" : $conn->quote($valor);
                }
                $return .= "INSERT INTO `$tabela` VALUES (" . implode(", ", $valores) . ");\n";
            }
            $return .= "\n";
        }

        $return .= "SET FOREIGN_KEY_CHECKS=1;\n";

        $nome_arquivo = 'backups/yws_backup_' . date('Y-m-d_H-i-s') . '.sql';
        file_put_contents($nome_arquivo, $return);

        echo "<script>alert('✅ Backup gerado com sucesso!'); window.location='backup.php';</script>";
        exit;
    } catch (Exception $e) {
        echo "<script>alert('Erro: " . addslashes($e->getMessage()) . "'); window.location='backup.php';</script>";
        exit;
    }
}

// Listar backups existentes
$backups = glob('backups/*.sql');
rsort($backups);
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Backup - YWS</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="header">
    <h1>The Young Wise School - YWS</h1>
    <p style="font-style: italic; color: #ffcc00;">"More than just speak English"</p>
    <p>Sistema de Backup</p>
</div>
<?php include 'menu_admin.php'; ?>

<div class="container">
    <div style="text-align:center; margin-bottom:30px;">
        <a href="?gerar=1" class="btn-yws btn-green" style="font-size:18px; padding:15px 30px;">💾 Gerar Novo Backup Agora</a>
    </div>

    <h2>📁 Backups Existentes (<?= count($backups) ?>)</h2>
    <?php if (empty($backups)): ?>
        <div class="card" style="text-align:center; padding:30px;">Nenhum backup encontrado.</div>
    <?php else: ?>
        <table>
            <tr><th>Arquivo</th><th>Tamanho</th><th>Data</th><th>Ações</th></tr>
            <?php foreach ($backups as $b): ?>
            <tr>
                <td><?= basename($b) ?></td>
                <td><?= number_format(filesize($b) / 1024, 2) ?> KB</td>
                <td><?= date('d/m/Y H:i', filemtime($b)) ?></td>
                <td>
                    <a href="<?= $b ?>" download class="btn-yws" style="padding:5px 10px; background:#2E7D32;">💾 Baixar</a>
                    <?php if (pode_excluir()): ?>
                        <a href="?excluir=<?= basename($b) ?>" class="btn-yws" style="padding:5px 10px; background:#D32F2F;" onclick="return confirm('Excluir este backup?')">🗑️</a>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        </table>
    <?php endif; ?>
</div>
</body>
</html>