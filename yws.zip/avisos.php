<?php
include 'config.php';
if (!isset($_SESSION['user']) || $_SESSION['user']['tipo'] !== 'funcionario') {
    header("Location: login.php"); exit;
}

$cargo = $_SESSION['user']['cargo'] ?? '';
$id_user = $_SESSION['user']['id'] ?? 0;

// Criar aviso
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao']) && $_POST['acao'] === 'criar') {
    $titulo = trim($_POST['titulo']);
    $mensagem = trim($_POST['mensagem']);
    $tipo = $_POST['tipo'];
    $destinatario_id = !empty($_POST['destinatario_id']) ? $_POST['destinatario_id'] : null;
    $data_expiracao = !empty($_POST['data_expiracao']) ? $_POST['data_expiracao'] : null;
    $prioridade = $_POST['prioridade'];
    
    $stmt = $conn->prepare("INSERT INTO avisos (titulo, mensagem, tipo, destinatario_id, criado_por, data_expiracao, prioridade) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$titulo, $mensagem, $tipo, $destinatario_id, $id_user, $data_expiracao, $prioridade]);
    
    echo "<script>alert('✅ Aviso criado com sucesso!'); window.location='avisos.php';</script>";
    exit;
}

// Excluir aviso
if (isset($_GET['excluir'])) {
    $conn->prepare("DELETE FROM avisos WHERE id = ?")->execute([$_GET['excluir']]);
    echo "<script>alert('Aviso excluído!'); window.location='avisos.php';</script>";
    exit;
}

// Marcar como lido
if (isset($_GET['marcar_lido'])) {
    $conn->prepare("UPDATE avisos SET lido = 'sim' WHERE id = ?")->execute([$_GET['marcar_lido']]);
    echo "<script>window.location='avisos.php';</script>";
    exit;
}

// Atualizar status (ativo/inativo)
if (isset($_GET['status'])) {
    $id = $_GET['id'];
    $novo_status = $_GET['status'];
    $conn->prepare("UPDATE avisos SET status = ? WHERE id = ?")->execute([$novo_status, $id]);
    echo "<script>window.location='avisos.php';</script>";
    exit;
}

// Buscar avisos
$filtro = $_GET['filtro'] ?? 'todos';
$sql = "SELECT a.*, f.nome as criador, n.nome_nivel, t.nome_turma, al.nome as aluno_nome
        FROM avisos a
        LEFT JOIN funcionarios f ON a.criado_por = f.id
        LEFT JOIN niveis n ON a.destinatario_id = n.id AND a.tipo = 'nivel'
        LEFT JOIN turmas t ON a.destinatario_id = t.id AND a.tipo = 'turma'
        LEFT JOIN alunos al ON a.destinatario_id = al.id AND a.tipo = 'individual'";

if ($filtro === 'ativos') {
    $sql .= " WHERE a.status = 'ativo'";
} elseif ($filtro === 'expirados') {
    $sql .= " WHERE a.status = 'expirado' OR (a.data_expiracao IS NOT NULL AND a.data_expiracao < CURDATE())";
} elseif ($filtro === 'meus') {
    $sql .= " WHERE a.criado_por = $id_user";
}

$sql .= " ORDER BY a.data_criacao DESC";
$avisos = $conn->query($sql)->fetchAll();

// Buscar níveis e turmas para o formulário
$niveis = $conn->query("SELECT id, nome_nivel FROM niveis ORDER BY id")->fetchAll();
$turmas = $conn->query("SELECT id, nome_turma FROM turmas ORDER BY nome_turma")->fetchAll();
$alunos = $conn->query("SELECT id, nome FROM alunos WHERE status='ativo' ORDER BY nome")->fetchAll();

// Contadores
$total_avisos = count($avisos);
$avisos_urgentes = $conn->query("SELECT COUNT(*) FROM avisos WHERE prioridade='urgente' AND status='ativo'")->fetchColumn();
$avisos_nao_lidos = $conn->query("SELECT COUNT(*) FROM avisos WHERE lido='nao' AND status='ativo'")->fetchColumn();
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Avisos e Mensagens - YWS</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .aviso-card {
            background: white;
            padding: 20px;
            margin: 15px 0;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            border-left: 5px solid #0D47A1;
            transition: transform 0.2s;
        }
        .aviso-card:hover { transform: translateX(5px); }
        .aviso-card.urgente { border-left-color: #D32F2F; background: #ffebee; }
        .aviso-card.alta { border-left-color: #F57C00; }
        .aviso-card.media { border-left-color: #0D47A1; }
        .aviso-card.baixa { border-left-color: #2E7D32; }
        .aviso-card.nao-lido { background: #e3f2fd; }
        .aviso-header { display: flex; justify-content: space-between; align-items: start; margin-bottom: 10px; }
        .aviso-titulo { font-size: 18px; font-weight: bold; color: #0D47A1; margin: 0; }
        .aviso-meta { font-size: 12px; color: #666; margin-top: 5px; }
        .badge { display: inline-block; padding: 3px 10px; border-radius: 12px; font-size: 11px; font-weight: bold; color: white; }
        .badge-urgente { background: #D32F2F; }
        .badge-alta { background: #F57C00; }
        .badge-media { background: #0D47A1; }
        .badge-baixa { background: #2E7D32; }
        .badge-tipo { background: #666; }
        .aviso-actions { display: flex; gap: 5px; margin-top: 10px; }
        .modal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; }
        .modal-content { background: white; max-width: 600px; margin: 50px auto; padding: 30px; border-radius: 12px; max-height: 80vh; overflow-y: auto; }
        .stats-avisos { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 15px; margin-bottom: 20px; }
        .stat-aviso { background: white; padding: 15px; border-radius: 8px; text-align: center; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        .stat-aviso .numero { font-size: 28px; font-weight: bold; color: #0D47A1; }
        .stat-aviso.urgente .numero { color: #D32F2F; }
        .stat-aviso.nao-lido .numero { color: #F57C00; }
    </style>
</head>
<body>
<div class="header">
    <h1>The Young Wise School - YWS</h1>
    <p style="font-style: italic; color: #ffcc00;">"More than just speak English"</p>
    <p>Sistema de Avisos e Mensagens</p>
</div>
<?php include 'menu_admin.php'; ?>

<div class="container">
    <!-- Estatísticas -->
    <div class="stats-avisos">
        <div class="stat-aviso">
            <div class="numero"><?= $total_avisos ?></div>
            <p>Total de Avisos</p>
        </div>
        <div class="stat-aviso urgente">
            <div class="numero"><?= $avisos_urgentes ?></div>
            <p>Urgentes</p>
        </div>
        <div class="stat-aviso nao-lido">
            <div class="numero"><?= $avisos_nao_lidos ?></div>
            <p>Não Lidos</p>
        </div>
    </div>

    <!-- Filtros e Botões -->
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; flex-wrap: wrap; gap: 10px;">
        <div>
            <a href="avisos.php?filtro=todos" class="btn-yws <?= $filtro === 'todos' ? 'btn-blue' : '' ?>" style="padding: 8px 15px;">Todos</a>
            <a href="avisos.php?filtro=ativos" class="btn-yws <?= $filtro === 'ativos' ? 'btn-blue' : '' ?>" style="padding: 8px 15px;">Ativos</a>
            <a href="avisos.php?filtro=meus" class="btn-yws <?= $filtro === 'meus' ? 'btn-blue' : '' ?>" style="padding: 8px 15px;">Meus Avisos</a>
            <a href="avisos.php?filtro=expirados" class="btn-yws <?= $filtro === 'expirados' ? 'btn-blue' : '' ?>" style="padding: 8px 15px;">Expirados</a>
        </div>
        <button onclick="abrirModal()" class="btn-yws btn-green">➕ Novo Aviso</button>
    </div>

    <!-- Lista de Avisos -->
    <?php if (empty($avisos)): ?>
        <div class="card" style="text-align: center; padding: 40px;">
            <p style="font-size: 18px; color: #666;"> Nenhum aviso encontrado</p>
        </div>
    <?php else: ?>
        <?php foreach ($avisos as $av): 
            $classe = $av['prioridade'];
            if ($av['lido'] === 'nao') $classe .= ' nao-lido';
        ?>
        <div class="aviso-card <?= $classe ?>">
            <div class="aviso-header">
                <div>
                    <h3 class="aviso-titulo"><?= htmlspecialchars($av['titulo']) ?></h3>
                    <div class="aviso-meta">
                        <span class="badge badge-<?= $av['prioridade'] ?>"><?= strtoupper($av['prioridade']) ?></span>
                        <span class="badge badge-tipo"><?= strtoupper($av['tipo']) ?></span>
                        <?php if ($av['tipo'] === 'nivel' && $av['nome_nivel']): ?>
                            <span class="badge" style="background: #1565C0;">🎓 <?= htmlspecialchars($av['nome_nivel']) ?></span>
                        <?php elseif ($av['tipo'] === 'turma' && $av['nome_turma']): ?>
                            <span class="badge" style="background: #1565C0;">🏫 <?= htmlspecialchars($av['nome_turma']) ?></span>
                        <?php elseif ($av['tipo'] === 'individual' && $av['aluno_nome']): ?>
                            <span class="badge" style="background: #1565C0;">👤 <?= htmlspecialchars($av['aluno_nome']) ?></span>
                        <?php endif; ?>
                        <?php if ($av['data_expiracao']): ?>
                            <span style="color: #D32F2F;">📅 Expira: <?= date('d/m/Y', strtotime($av['data_expiracao'])) ?></span>
                        <?php endif; ?>
                    </div>
                </div>
                <div style="text-align: right;">
                    <div style="font-size: 12px; color: #666;">
                        Por: <?= htmlspecialchars($av['criador']) ?><br>
                        <?= date('d/m/Y H:i', strtotime($av['data_criacao'])) ?>
                    </div>
                    <span class="badge" style="background: <?= $av['status'] === 'ativo' ? '#2E7D32' : '#999' ?>; margin-top: 5px;">
                        <?= strtoupper($av['status']) ?>
                    </span>
                </div>
            </div>
            
            <p style="margin: 15px 0; line-height: 1.6;"><?= nl2br(htmlspecialchars($av['mensagem'])) ?></p>
            
            <div class="aviso-actions">
                <?php if ($av['lido'] === 'nao'): ?>
                    <a href="?marcar_lido=<?= $av['id'] ?>" class="btn-yws" style="padding: 5px 10px; background: #2E7D32;">✅ Marcar como Lido</a>
                <?php endif; ?>
                
                <?php if ($av['status'] === 'ativo'): ?>
                    <a href="?status=inativo&id=<?= $av['id'] ?>" class="btn-yws" style="padding: 5px 10px; background: #F57C00;">️ Desativar</a>
                <?php else: ?>
                    <a href="?status=ativo&id=<?= $av['id'] ?>" class="btn-yws" style="padding: 5px 10px; background: #2E7D32;">▶️ Ativar</a>
                <?php endif; ?>
                
                <a href="?excluir=<?= $av['id'] ?>" class="btn-yws" style="padding: 5px 10px;" onclick="return confirm('Excluir este aviso?')">🗑️ Excluir</a>
            </div>
        </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<!-- Modal de Novo Aviso -->
<div id="modalAviso" class="modal">
    <div class="modal-content">
        <h2 style="color: #0D47A1; margin-bottom: 20px;">➕ Criar Novo Aviso</h2>
        <form method="POST">
            <input type="hidden" name="acao" value="criar">
            
            <div style="margin-bottom: 15px;">
                <label><strong>Título:</strong></label>
                <input type="text" name="titulo" required style="width: 100%; padding: 10px; margin-top: 5px;">
            </div>
            
            <div style="margin-bottom: 15px;">
                <label><strong>Mensagem:</strong></label>
                <textarea name="mensagem" rows="5" required style="width: 100%; padding: 10px; margin-top: 5px;"></textarea>
            </div>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-bottom: 15px;">
                <div>
                    <label><strong>Tipo de Destinatário:</strong></label>
                    <select name="tipo" id="tipoAviso" onchange="mostrarDestinatario()" style="width: 100%; padding: 10px; margin-top: 5px;">
                        <option value="geral"> Geral (Todos)</option>
                        <option value="nivel">🎓 Por Nível</option>
                        <option value="turma"> Por Turma</option>
                        <option value="individual">👤 Individual (Aluno)</option>
                        <option value="funcionarios">👔 Apenas Funcionários</option>
                    </select>
                </div>
                
                <div>
                    <label><strong>Prioridade:</strong></label>
                    <select name="prioridade" style="width: 100%; padding: 10px; margin-top: 5px;">
                        <option value="baixa">🟢 Baixa</option>
                        <option value="media" selected>🔵 Média</option>
                        <option value="alta">🟠 Alta</option>
                        <option value="urgente">🔴 Urgente</option>
                    </select>
                </div>
            </div>
            
            <div id="destinatarioDiv" style="display: none; margin-bottom: 15px;">
                <label><strong>Destinatário Específico:</strong></label>
                <select name="destinatario_id" id="destinatarioSelect" style="width: 100%; padding: 10px; margin-top: 5px;">
                    <option value="">-- Selecione --</option>
                </select>
            </div>
            
            <div style="margin-bottom: 15px;">
                <label><strong>Data de Expiração (opcional):</strong></label>
                <input type="date" name="data_expiracao" style="width: 100%; padding: 10px; margin-top: 5px;">
            </div>
            
            <div style="display: flex; gap: 10px; justify-content: flex-end;">
                <button type="button" onclick="fecharModal()" class="btn-yws" style="background: #666;">Cancelar</button>
                <button type="submit" class="btn-yws btn-green">💾 Criar Aviso</button>
            </div>
        </form>
    </div>
</div>

<script>
function abrirModal() {
    document.getElementById('modalAviso').style.display = 'block';
}

function fecharModal() {
    document.getElementById('modalAviso').style.display = 'none';
}

function mostrarDestinatario() {
    const tipo = document.getElementById('tipoAviso').value;
    const div = document.getElementById('destinatarioDiv');
    const select = document.getElementById('destinatarioSelect');
    
    if (tipo === 'geral' || tipo === 'funcionarios') {
        div.style.display = 'none';
        select.value = '';
    } else {
        div.style.display = 'block';
        select.innerHTML = '<option value="">-- Selecione --</option>';
        
        if (tipo === 'nivel') {
            <?php foreach ($niveis as $n): ?>
                select.innerHTML += '<option value="<?= $n['id'] ?>"><?= htmlspecialchars($n['nome_nivel']) ?></option>';
            <?php endforeach; ?>
        } else if (tipo === 'turma') {
            <?php foreach ($turmas as $t): ?>
                select.innerHTML += '<option value="<?= $t['id'] ?>"><?= htmlspecialchars($t['nome_turma']) ?></option>';
            <?php endforeach; ?>
        } else if (tipo === 'individual') {
            <?php foreach ($alunos as $a): ?>
                select.innerHTML += '<option value="<?= $a['id'] ?>"><?= htmlspecialchars($a['nome']) ?></option>';
            <?php endforeach; ?>
        }
    }
}

// Fechar modal ao clicar fora
window.onclick = function(event) {
    const modal = document.getElementById('modalAviso');
    if (event.target === modal) {
        fecharModal();
    }
}
</script>
</body>
</html>