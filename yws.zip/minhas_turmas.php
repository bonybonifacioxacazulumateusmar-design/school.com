<?php
include 'config.php';
if (!isset($_SESSION['user']) || $_SESSION['user']['tipo'] !== 'funcionario') {
    header("Location: login.php"); exit;
}

$id_professor = $_SESSION['user']['id'];
$nome_professor = $_SESSION['user']['nome'];

// Busca apenas as turmas deste professor
$turmas = $conn->prepare("SELECT t.*, n.nome_nivel, COUNT(DISTINCT a.id) as total_alunos
                          FROM turmas t
                          LEFT JOIN niveis n ON t.id_nivel = n.id
                          LEFT JOIN alunos a ON a.nivel_id = n.id AND a.status='ativo'
                          WHERE t.id_professor = ?
                          GROUP BY t.id ORDER BY t.nome_turma");
$turmas->execute([$id_professor]);
$lista_turmas = $turmas->fetchAll();

// Busca alunos das turmas do professor
$alunos_turmas = $conn->prepare("SELECT a.*, n.nome_nivel, t.nome_turma, t.id as id_turma
                                 FROM alunos a
                                 LEFT JOIN niveis n ON a.nivel_id = n.id
                                 LEFT JOIN turmas t ON t.id_nivel = n.id
                                 WHERE t.id_professor = ? AND a.status='ativo'
                                 ORDER BY a.nome");
$alunos_turmas->execute([$id_professor]);
$alunos = $alunos_turmas->fetchAll();
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Minhas Turmas - YWS</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="header">
    <h1>The Young Wise School - YWS</h1>
    <p>Portal do Professor - <?= htmlspecialchars($nome_professor) ?></p>
</div>
<?php include 'menu_admin.php'; ?>

<div class="container">
    <h2>📚 Minhas Turmas</h2>
    
    <?php if (empty($lista_turmas)): ?>
        <div class="card" style="background:#fff3cd; border-left-color: #ffc107;">
            <p>⚠️ Você ainda não tem turmas atribuídas. Entre em contato com a coordenação pedagógica.</p>
        </div>
    <?php else: ?>
        <div class="stats-grid">
            <?php foreach ($lista_turmas as $t): ?>
                <div class="stat-card card-blue">
                    <h3><?= htmlspecialchars($t['nome_turma']) ?></h3>
                    <div class="number" style="font-size:24px;"><?= $t['total_alunos'] ?></div>
                    <p>Alunos | <?= htmlspecialchars($t['nome_nivel']) ?></p>
                    <p style="font-size:12px; margin-top:10px;">Período: <?= htmlspecialchars($t['periodo'] ?: 'Não definido') ?></p>
                </div>
            <?php endforeach; ?>
        </div>

        <h2 style="margin-top:30px;">👨‍ Meus Alunos</h2>
        <table>
            <tr>
                <th>Nome</th>
                <th>Turma</th>
                <th>Nível</th>
                <th>Telefone</th>
                <th>Status</th>
                <th>Ações</th>
            </tr>
            <?php foreach ($alunos as $a): ?>
                <tr>
                    <td><strong><?= htmlspecialchars($a['nome']) ?></strong></td>
                    <td><?= htmlspecialchars($a['nome_turma'] ?? '-') ?></td>
                    <td><?= htmlspecialchars($a['nome_nivel'] ?? '-') ?></td>
                    <td><?= htmlspecialchars($a['numero_telefone']) ?></td>
                    <td><span class="status-badge status-<?= $a['status'] ?>"><?= strtoupper($a['status']) ?></span></td>
                    <td>
                        <a href="lancar_notas.php?id_aluno=<?= $a['id'] ?>&id_turma=<?= $a['id_turma'] ?>" class="btn-yws" style="padding:5px 10px;">📝 Lançar Notas</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php endif; ?>

    <div style="text-align:center; margin-top:30px;">
        <a href="lancar_notas.php" class="btn-yws btn-green">📝 Lançar Notas</a>
        <a href="dashboard.php" class="btn-yws">📊 Voltar ao Dashboard</a>
    </div>
</div>
</body>
</html>