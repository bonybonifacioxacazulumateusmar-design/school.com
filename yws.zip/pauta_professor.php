<?php
include 'config.php';
include_once 'permissoes.php';
if (!isset($_SESSION['user'])) { header("Location: login.php"); exit; }

if (!eh_professor()) {
    die("<script>alert('Acesso restrito a professores!'); window.location='home.php';</script>");
}

$id_prof = $_SESSION['user']['id'];
$turmas = turmas_do_professor($conn, $id_prof);

// Buscar avaliações apenas das turmas do professor
$turma_ids = array_column($turmas, 'id');
if (empty($turma_ids)) {
    $avaliacoes = [];
    $alunos = [];
} else {
    $ids_str = implode(',', $turma_ids);
    $alunos = $conn->query("SELECT a.id, a.nome, n.nome_nivel, t.nome_turma, t.id as turma_id
                            FROM alunos a
                            JOIN niveis n ON a.nivel_id = n.id
                            JOIN turmas t ON t.id_nivel = n.id
                            WHERE t.id IN ($ids_str)
                            ORDER BY n.id ASC, a.nome ASC")->fetchAll();
    
    $avals_stmt = $conn->query("SELECT av.id_aluno, av.tipo_avaliacao, av.nota
                                FROM avaliacoes av
                                WHERE av.id_turma IN ($ids_str)
                                ORDER BY av.id_aluno, av.data_avaliacao");
    $avaliacoes = $avals_stmt->fetchAll();
}

$notas_por_aluno = [];
foreach ($avaliacoes as $av) {
    $notas_por_aluno[$av['id_aluno']][] = $av;
}

function calcular_media($notas) {
    if (empty($notas)) return 0;
    return array_sum($notas) / count($notas);
}
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Minha Pauta - YWS</title>
    <style>
        @page { size: landscape; margin: 1cm; }
        body { font-family: 'Times New Roman', Times, serif; font-size: 9px; margin: 0; padding: 10px; }
        .header-instituicao { text-align: center; border-bottom: 3px double #0D47A1; padding-bottom: 10px; margin-bottom: 15px; background: white; padding: 15px; border-radius: 6px; }
        .header-instituicao h1 { font-size: 20px; margin: 5px 0; text-transform: uppercase; letter-spacing: 2px; color: #0D47A1; }
        .header-instituicao h2 { font-size: 12px; margin: 0; letter-spacing: 3px; font-weight: normal; color: #333; }
        .titulo-pauta { text-align: center; font-size: 18px; font-weight: bold; margin: 15px 0; text-decoration: underline; color: #0D47A1; }
        .info-doc { text-align: center; font-size: 11px; margin-bottom: 15px; color: #666; }
        .nivel-separator { background: linear-gradient(135deg, #F57C00, #FF9800); color: white; font-weight: bold; font-size: 13px; padding: 8px 15px; margin-top: 25px; border-radius: 6px 6px 0 0; }
        table { width: 100%; border-collapse: collapse; background: white; }
        th, td { border: 1px solid #000; padding: 3px 4px; text-align: center; font-size: 8px; }
        th { background-color: #f0f0f0; font-weight: bold; font-size: 7px; }
        .nome-col { width: 130px; text-align: left; padding-left: 4px !important; }
        .nota-col { width: 28px; }
        .media-col { width: 32px; font-weight: bold; background: #fff9c4; }
        .status-col { width: 55px; }
        .assinaturas { margin-top: 40px; display: flex; justify-content: space-between; }
        .assinatura { width: 45%; text-align: center; border-top: 1px solid #000; padding-top: 5px; font-size: 10px; }
        @media print { .no-print { display: none; } body { padding: 0; } }
    </style>
</head>
<body>
    <div class="no-print" style="text-align:center; margin-bottom:15px; padding:10px; background:white; border-radius:6px;">
        <button onclick="window.print()" style="padding:10px 20px; background:#F57C00; color:white; border:none; cursor:pointer; font-size:14px; border-radius:4px;">🖨️ Imprimir Minha Pauta</button>
        <a href="avaliacoes.php" style="margin-left:10px; padding:10px 20px; background:#666; color:white; text-decoration:none; border-radius:4px;">← Voltar</a>
    </div>

    <div class="header-instituicao">
        <img src="logo.png" alt="Logo" style="max-width:80px;" onerror="this.style.display='none'">
        <h1>THE YOUNG WISE SCHOOL</h1>
        <h2>CENTRO DE FORMAÇÃO</h2>
    </div>

    <div class="titulo-pauta">PAUTA DO PROFESSOR</div>
    <div class="info-doc">
        Ano Lectivo: <?= date('Y') ?> | Professor: <strong><?= htmlspecialchars($_SESSION['user']['nome']) ?></strong>
    </div>

    <?php if (empty($turmas)): ?>
        <p style="text-align:center; padding:30px; background:white; border-radius:6px;">Você não tem turmas atribuídas.</p>
    <?php else: 
        // Agrupar alunos por turma/nível
        $alunos_por_turma = [];
        foreach ($alunos as $al) {
            $key = $al['turma_id'];
            $alunos_por_turma[$key]['turma'] = $al['nome_turma'];
            $alunos_por_turma[$key]['nivel'] = $al['nome_nivel'];
            $alunos_por_turma[$key]['alunos'][] = $al;
        }
        
        foreach ($alunos_por_turma as $turma_id => $dados):
    ?>
    
    <div class="nivel-separator">
         Turma: <?= htmlspecialchars($dados['turma']) ?> | Nível: <?= htmlspecialchars($dados['nivel']) ?> | <?= count($dados['alunos']) ?> alunos
    </div>

    <table>
        <thead>
            <tr>
                <th style="width:22px;">Nº</th>
                <th class="nome-col">Nome do Aluno</th>
                <th>A1 E.</th><th>A2 E.</th><th>A3 E.</th><th>A4 E.</th>
                <th>A1 O.</th><th>A2 O.</th><th>A3 O.</th><th>A4 O.</th>
                <th>D1</th><th>D2</th><th>D3</th>
                <th>M.D</th><th>M.E</th><th>M.O</th>
                <th>Ex.E</th><th>Ex.O</th>
                <th>Mg.A</th><th>Mg.E</th>
                <th>Obs.</th>
            </tr>
        </thead>
        <tbody>
            <?php 
            $num = 1;
            foreach ($dados['alunos'] as $aluno): 
                $notas = $notas_por_aluno[$aluno['id']] ?? [];
                
                $escritas = []; $orais = []; $ditados = [];
                $exame_escrito = 0; $exame_oral = 0;
                
                foreach ($notas as $n) {
                    $tipo = $n['tipo_avaliacao'];
                    if ($tipo === 'avaliacao_escrita' || $tipo === 'avaliacao') $escritas[] = $n['nota'];
                    elseif ($tipo === 'avaliacao_oral') $orais[] = $n['nota'];
                    elseif ($tipo === 'ditado') $ditados[] = $n['nota'];
                    elseif ($tipo === 'exame_escrito') $exame_escrito = $n['nota'];
                    elseif ($tipo === 'exame_oral') $exame_oral = $n['nota'];
                }
                
                $media_ditados = calcular_media($ditados);
                $media_escritas = calcular_media($escritas);
                $media_orais = calcular_media($orais);
                $mg_a = calcular_media(array_merge($escritas, $orais, $ditados));
                
                $exames = [];
                if ($exame_escrito > 0) $exames[] = $exame_escrito;
                if ($exame_oral > 0) $exames[] = $exame_oral;
                $mg_e = calcular_media($exames);
                
                $media_final = ($mg_a + $mg_e) / 2;
                $status = $media_final >= 10 ? 'Aprovado' : 'Reprovado';
            ?>
            <tr>
                <td><?= str_pad($num++, 2, '0', STR_PAD_LEFT) ?></td>
                <td class="nome-col"><strong><?= htmlspecialchars($aluno['nome']) ?></strong></td>
                <td class="nota-col"><?= $escritas[0] ?? '-' ?></td>
                <td class="nota-col"><?= $escritas[1] ?? '-' ?></td>
                <td class="nota-col"><?= $escritas[2] ?? '-' ?></td>
                <td class="nota-col"><?= $escritas[3] ?? '-' ?></td>
                <td class="nota-col"><?= $orais[0] ?? '-' ?></td>
                <td class="nota-col"><?= $orais[1] ?? '-' ?></td>
                <td class="nota-col"><?= $orais[2] ?? '-' ?></td>
                <td class="nota-col"><?= $orais[3] ?? '-' ?></td>
                <td class="nota-col"><?= $ditados[0] ?? '-' ?></td>
                <td class="nota-col"><?= $ditados[1] ?? '-' ?></td>
                <td class="nota-col"><?= $ditados[2] ?? '-' ?></td>
                <td class="media-col"><?= $media_ditados > 0 ? number_format($media_ditados, 1) : '-' ?></td>
                <td class="media-col"><?= $media_escritas > 0 ? number_format($media_escritas, 1) : '-' ?></td>
                <td class="media-col"><?= $media_orais > 0 ? number_format($media_orais, 1) : '-' ?></td>
                <td class="nota-col"><?= $exame_escrito > 0 ? $exame_escrito : '-' ?></td>
                <td class="nota-col"><?= $exame_oral > 0 ? $exame_oral : '-' ?></td>
                <td class="media-col"><?= $mg_a > 0 ? number_format($mg_a, 1) : '-' ?></td>
                <td class="media-col"><?= $mg_e > 0 ? number_format($mg_e, 1) : '-' ?></td>
                <td class="status-col" style="font-weight:bold; color:<?= $status === 'Aprovado' ? '#2E7D32' : '#D32F2F' ?>;"><?= $status ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <?php endforeach; ?>

    <div class="assinaturas">
        <div class="assinatura">
            <br>
            <strong>Professor(a): <?= htmlspecialchars($_SESSION['user']['nome']) ?></strong><br>
            Assinatura: _______________
        </div>
        <div class="assinatura">
            <br>
            <strong>Coordenação Pedagógica</strong><br>
            Assinatura: _______________
        </div>
    </div>
</body>
</html>