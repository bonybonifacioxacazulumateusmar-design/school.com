<?php
include 'config.php';
if (!isset($_SESSION['user'])) { header("Location: login.php"); exit; }

$mes_atual = date('m');
$ano_atual = date('Y');

// ===== DADOS FINANCEIROS COM PROTEÇÃO =====
$total_entradas = 0;
$total_saidas = 0;
$lucro_mes = 0;
$total_financiador_ano = 0;
$propinas_nivel = [];

try {
    $total_entradas = $conn->query("SELECT COALESCE(SUM(valor),0) FROM entradas WHERE MONTH(data)=$mes_atual AND YEAR(data)=$ano_atual")->fetchColumn();
    $total_saidas = $conn->query("SELECT COALESCE(SUM(valor),0) FROM saidas WHERE MONTH(data)=$mes_atual AND YEAR(data)=$ano_atual")->fetchColumn();
    $lucro_mes = $total_entradas - $total_saidas;
    $total_financiador_ano = $conn->query("SELECT COALESCE(SUM(valor_25_porcento),0) FROM repasse_financiador WHERE ano=$ano_atual")->fetchColumn();
    $propinas_nivel = $conn->query("SELECT n.nome_nivel, COALESCE(SUM(p.valor_pago),0) as total 
                                    FROM niveis n 
                                    LEFT JOIN alunos a ON n.id = a.nivel_id 
                                    LEFT JOIN propinas_pagas p ON a.id = p.id_aluno AND p.ano=$ano_atual 
                                    GROUP BY n.id")->fetchAll();
} catch (PDOException $e) {
    // Tabelas financeiras ainda não criadas - usa valores padrão
    $total_entradas = 0;
    $total_saidas = 0;
    $lucro_mes = 0;
    $total_financiador_ano = 0;
    $propinas_nivel = [];
}
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Dashboard Financeiro - YWS</title>
    <link rel="stylesheet" href="style.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
<div class="header" style="background: linear-gradient(135deg, #1B5E20 0%, #2E7D32 100%);">
    <h1>The Young Wise School - YWS</h1>
    <p style="font-style: italic; color: #ffcc00;">"More than just speak English"</p>
    <p>Painel Financeiro e Contábil</p>
</div>

<?php include 'menu_admin.php'; ?>

<div class="container">
    <h2>💰 Resumo Financeiro do Mês (<?= date('m/Y') ?>)</h2>
    <div class="stats-grid">
        <div class="stat-card green">
            <h3>Total Entradas</h3>
            <div class="number"><?= number_format($total_entradas, 2, ',', '.') ?> Kz</div>
        </div>
        <div class="stat-card red">
            <h3>Total Saídas</h3>
            <div class="number"><?= number_format($total_saidas, 2, ',', '.') ?> Kz</div>
        </div>
        <div class="stat-card" style="border-left-color: <?= $lucro_mes >= 0 ? '#2E7D32' : '#D32F2F' ?>">
            <h3>Saldo / Lucro do Mês</h3>
            <div class="number" style="color: <?= $lucro_mes >= 0 ? '#2E7D32' : '#D32F2F' ?>"><?= number_format($lucro_mes, 2, ',', '.') ?> Kz</div>
        </div>
        <div class="stat-card">
            <h3>Repasse ao Financiador (Ano <?= $ano_atual ?>)</h3>
            <div class="number" style="font-size:22px;"><?= number_format($total_financiador_ano, 2, ',', '.') ?> Kz</div>
        </div>
    </div>

    <?php if (!empty($propinas_nivel)): ?>
    <div style="display:grid; grid-template-columns: 1fr 1fr; gap:20px; margin-top:30px;">
        <div class="card">
            <h3>📈 Propinas Arrecadadas por Nível (Ano <?= $ano_atual ?>)</h3>
            <canvas id="graficoPropinas"></canvas>
        </div>
        <div class="card">
            <h3> Ações Financeiras Rápidas</h3>
            <ul style="line-height:2.5; list-style:none; padding:0;">
                <li>📥 <a href="financeiro_entradas.php" style="color:#0D47A1; text-decoration:none; font-weight:bold;">Registrar Pagamento de Propina</a></li>
                <li>📤 <a href="financeiro_saidas.php" style="color:#D32F2F; text-decoration:none; font-weight:bold;">Registrar Saída / Despesa</a></li>
                <li>📦 <a href="estoque.php" style="color:#F57C00; text-decoration:none; font-weight:bold;">Gerenciar Estoque</a></li>
                <li>📄 <a href="relatorio_financiador.php" target="_blank" style="color:#1565C0; text-decoration:none; font-weight:bold;">Imprimir Relatório para o Financiador</a></li>
                <li>💾 <a href="backup.php" style="color:#666; text-decoration:none; font-weight:bold;">Fazer Backup do Banco de Dados</a></li>
            </ul>
        </div>
    </div>
    <?php else: ?>
    <div class="card" style="background:#fff3cd; border-left-color:#F57C00; margin-top:30px;">
        <h3>⚠️ Sistema Financeiro em Configuração</h3>
        <p>As tabelas financeiras ainda não possuem dados. Use os atalhos abaixo para começar:</p>
        <div style="display:flex; gap:10px; flex-wrap:wrap; margin-top:15px;">
            <a href="financeiro_entradas.php" class="btn-yws">📥 Registrar Primeira Propina</a>
            <a href="financeiro_saidas.php" class="btn-yws" style="background:#D32F2F;">📤 Registrar Primeira Saída</a>
            <a href="estoque.php" class="btn-yws" style="background:#F57C00;"> Configurar Estoque</a>
        </div>
    </div>
    <?php endif; ?>
</div>

<?php if (!empty($propinas_nivel)): ?>
<script>
const ctx = document.getElementById('graficoPropinas').getContext('2d');
new Chart(ctx, {
    type: 'doughnut',
    data: {
        labels: [<?php foreach($propinas_nivel as $p) echo "'".addslashes($p['nome_nivel'])."',"; ?>],
        datasets: [{
            label: 'Total Arrecadado (Kz)',
            data: [<?php foreach($propinas_nivel as $p) echo $p['total'].","; ?>],
            backgroundColor: ['#0D47A1', '#1565C0', '#1976D2', '#1E88E5', '#42A5F5', '#D32F2F']
        }]
    },
    options: { responsive: true, plugins: { legend: { position: 'bottom' } } }
});
</script>
<?php endif; ?>
</body>
</html>