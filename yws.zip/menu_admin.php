<?php
if (!isset($_SESSION['user'])) { header("Location: login.php"); exit; }
include_once 'permissoes.php';

$cargo = $_SESSION['user']['cargo'] ?? '';
$nome = $_SESSION['user']['nome'] ?? '';
$id_user = $_SESSION['user']['id'] ?? 0;
?>
<nav style="background: linear-gradient(135deg, #0D47A1 0%, #1565C0 100%); padding: 10px 20px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
    <div style="display: flex; gap: 10px; flex-wrap: wrap; align-items: center;">
        <a href="home.php" style="color: white; text-decoration: none; font-weight: bold; padding: 8px 15px; border-radius: 4px; <?= tem_permissao('inicio') ? '' : 'display:none;' ?>">🏠 Início</a>
        
        <!-- ESTATÍSTICA -->
        <?php if (tem_permissao('estatistica_geral')): ?>
        <a href="dashboard.php" style="color: white; text-decoration: none; padding: 8px 15px; border-radius: 4px; <?= eh_secretaria() ? 'background:rgba(255,255,255,0.2);' : '' ?>">📊 Estatística</a>
        <?php endif; ?>
        
        <!-- FINANCEIRO (Apenas CEO/Coordenador e Secretaria com período) -->
        <?php if (eh_admin_geral()): ?>
            <a href="financeiro_entradas.php" style="color: white; text-decoration: none; padding: 8px 15px; border-radius: 4px;">💰 Entradas</a>
            <a href="financeiro_saidas.php" style="color: white; text-decoration: none; padding: 8px 15px; border-radius: 4px;">💸 Saídas</a>
            <a href="relatorio_financiador.php" style="color: white; text-decoration: none; padding: 8px 15px; border-radius: 4px;">📈 Relatório</a>
        <?php elseif (eh_secretaria()): ?>
            <a href="financeiro_entradas.php?periodo=1" style="color: white; text-decoration: none; padding: 8px 15px; border-radius: 4px; background:rgba(255,255,255,0.2);">💰 Entradas (Período)</a>
        <?php endif; ?>
        
        <!-- CADASTROS -->
        <?php if (tem_permissao('cadastro_alunos')): ?>
        <a href="cadastro_alunos.php" style="color: white; text-decoration: none; padding: 8px 15px; border-radius: 4px;">🎓 Alunos</a>
        <?php endif; ?>
        
        <?php if (tem_permissao('cadastro_funcionarios')): ?>
        <a href="cadastro_funcionarios.php" style="color: white; text-decoration: none; padding: 8px 15px; border-radius: 4px;">👥 Funcionários</a>
        <?php endif; ?>
        
        <!-- TURMAS -->
        <?php if (tem_permissao('turmas')): ?>
        <a href="turmas.php" style="color: white; text-decoration: none; padding: 8px 15px; border-radius: 4px;">🏫 Turmas</a>
        <?php endif; ?>
        
        <!-- AVALIAÇÕES E NOTAS (Professor, Pedagógico, CEO/Coord) -->
        <?php if (tem_permissao('avaliacoes')): ?>
        <a href="avaliacoes.php" style="color: white; text-decoration: none; padding: 8px 15px; border-radius: 4px;">✏️ Avaliações</a>
        <?php endif; ?>
        
        <?php if (tem_permissao('notas')): ?>
        <a href="notas.php" style="color: white; text-decoration: none; padding: 8px 15px; border-radius: 4px;">📝 Notas</a>
        <?php endif; ?>
        
        <!-- PAUTA GERAL (Apenas CEO, Coordenador e Pedagógico) -->
        <?php if (tem_permissao('pauta_geral')): ?>
        <a href="pauta_geral.php" style="color: white; text-decoration: none; padding: 8px 15px; border-radius: 4px;">📊 Pauta Geral</a>
        <?php endif; ?>
        
        <!-- PAUTA DO PROFESSOR (Apenas Professor - só suas turmas) -->
        <?php if (eh_professor()): ?>
        <a href="pauta_professor.php" style="color: white; text-decoration: none; padding: 8px 15px; border-radius: 4px; background:#F57C00;">📋 Minha Pauta</a>
        <?php endif; ?>
        
        <!-- AVISOS -->
        <?php if (tem_permissao('avisos')): ?>
        <a href="avisos.php" style="color: white; text-decoration: none; padding: 8px 15px; border-radius: 4px;"> Avisos</a>
        <?php endif; ?>
        
        <!-- ESTOQUE (Apenas CEO/Coordenador) -->
        <?php if (tem_permissao('estoque')): ?>
        <a href="estoque.php" style="color: white; text-decoration: none; padding: 8px 15px; border-radius: 4px;">📦 Estoque</a>
        <?php endif; ?>
        
        <!-- BACKUP (Apenas CEO/Coordenador) -->
        <?php if (tem_permissao('backup')): ?>
        <a href="backup.php" style="color: white; text-decoration: none; padding: 8px 15px; border-radius: 4px;">💾 Backup</a>
        <?php endif; ?>
    </div>
    
    <div style="display: flex; gap: 10px; align-items: center;">
        <span style="color: white; font-size: 13px;">
            👤 <strong><?= htmlspecialchars($nome) ?></strong><br>
            <small style="opacity: 0.8;"><?= htmlspecialchars($cargo) ?></small>
        </span>
        <a href="login.php?logout=1" style="color: white; text-decoration: none; padding: 8px 15px; background: #D32F2F; border-radius: 4px; font-weight: bold;">🚪 Sair</a>
    </div>
</nav>