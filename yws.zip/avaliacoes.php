<?php
include 'config.php';
if (!isset($_SESSION['user'])) { 
    header("Location: login.php"); 
    exit; 
}

// ===== SALVAR AVALIAÇÃO =====
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao']) && $_POST['acao'] === 'salvar') {
    $id_aluno = (int)$_POST['id_aluno'];
    $id_turma = (int)$_POST['id_turma'];
    $tipo = $_POST['tipo'];
    $nota = (float)$_POST['nota'];
    $nota_max = (float)$_POST['nota_maxima'];
    $data = $_POST['data'];
    $obs = $_POST['observacao'] ?? '';
    
    try {
        $conn->prepare("INSERT INTO avaliacoes (id_aluno, id_turma, tipo_avaliacao, nota, nota_maxima, data_avaliacao, observacao) 
                        VALUES (?, ?, ?, ?, ?, ?, ?)")
             ->execute([$id_aluno, $id_turma, $tipo, $nota, $nota_max, $data, $obs]);
        
        echo "<script>alert('✅ Avaliação registrada com sucesso!'); window.location='avaliacoes.php';</script>";
        exit;
    } catch (PDOException $e) {
        echo "<script>alert('❌ Erro ao salvar: " . addslashes($e->getMessage()) . "'); window.history.back();</script>";
        exit;
    }
}

// ===== ELIMINAR AVALIAÇÃO =====
if (isset($_GET['eliminar']) && pode_excluir()) {
    try {
        $conn->prepare("DELETE FROM avaliacoes WHERE id = ?")->execute([(int)$_GET['eliminar']]);
        echo "<script>alert('Avaliação eliminada!'); window.location='avaliacoes.php';</script>";
        exit;
    } catch (PDOException $e) {
        echo "<script>alert('Erro ao eliminar: " . addslashes($e->getMessage()) . "'); window.history.back();</script>";
        exit;
    }
}

// ===== BUSCAR DADOS PARA O FORMULÁRIO =====
$turmas = $conn->query("SELECT t.*, n.nome_nivel FROM turmas t LEFT JOIN niveis n ON t.id_nivel = n.id ORDER BY n.nome_nivel, t.nome_turma")->fetchAll();
$alunos = $conn->query("SELECT a.*, n.nome_nivel FROM alunos a LEFT JOIN niveis n ON a.nivel_id = n.id WHERE a.status='ativo' ORDER BY a.nome")->fetchAll();

// Buscar últimas 15 avaliações
$ultimas = $conn->query("SELECT av.*, a.nome as aluno, t.nome_turma 
                        FROM avaliacoes av 
                        LEFT JOIN alunos a ON av.id_aluno = a.id 
                        LEFT JOIN turmas t ON av.id_turma = t.id 
                        ORDER BY av.id DESC LIMIT 15")->fetchAll();
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Lançamento de Avaliações - YWS</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="header">
    <h1>The Young Wise School</h1>
    <p style="font-size:14px; letter-spacing:2px;">CENTRO DE FORMAÇÃO</p>
    <p>✏️ Lançamento de Avaliações</p>
</div>
<?php include 'menu_admin.php'; ?>

<div class="container">
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:20px;">
        <h2>📝 Registrar Nova Avaliação</h2>
        <a href="notas.php" class="btn-yws">📊 Ver Resultados Completos</a>
    </div>

    <!-- FORMULÁRIO DE LANÇAMENTO -->
    <form method="POST" class="card">
        <input type="hidden" name="acao" value="salvar">
        <div style="display:grid; grid-template-columns: 1fr 1fr 1fr 1fr; gap:15px;">
            <div>
                <label><strong>Aluno:</strong></label>
                <select name="id_aluno" required style="width:100%; padding:10px;">
                    <option value="">-- Selecione o Aluno --</option>
                    <?php foreach ($alunos as $a): ?>
                        <option value="<?= $a['id'] ?>"><?= htmlspecialchars($a['nome']) ?> (<?= $a['nome_nivel'] ?>)</option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label><strong>Turma:</strong></label>
                <select name="id_turma" required style="width:100%; padding:10px;">
                    <option value="">-- Selecione a Turma --</option>
                    <?php foreach ($turmas as $t): ?>
                        <option value="<?= $t['id'] ?>"><?= htmlspecialchars($t['nome_turma']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label><strong>Tipo de Avaliação:</strong></label>
                <select name="tipo" id="tipoAval" required onchange="atualizarMax()" style="width:100%; padding:10px;">
                    <option value="avaliacao_escrita" data-max="30">Avaliação Escrita (max 30)</option>
                    <option value="avaliacao_oral" data-max="30">Avaliação Oral (max 30)</option>
                    <option value="avaliacao" data-max="30">Avaliação Geral (max 30)</option>
                    <option value="ditado" data-max="30">Ditado (max 30)</option>
                    <option value="exame_escrito" data-max="150">Exame Escrito (max 150)</option>
                    <option value="exame_oral" data-max="100">Exame Oral (max 100%)</option>
                    <option value="defesa_final" data-max="100">Defesa Final (max 100%)</option>
                </select>
            </div>
            <div>
                <label><strong>Nota Máxima:</strong></label>
                <input type="number" name="nota_maxima" id="notaMaxima" value="30" step="0.01" required readonly 
                       style="width:100%; padding:10px; background:#e3f2fd; font-weight:bold; color:#0D47A1;">
            </div>
            <div>
                <label><strong>Nota Obtida:</strong></label>
                <input type="number" name="nota" id="notaInput" step="0.01" max="30" required 
                       style="width:100%; padding:10px;">
            </div>
            <div>
                <label><strong>Data:</strong></label>
                <input type="date" name="data" value="<?= date('Y-m-d') ?>" required style="width:100%; padding:10px;">
            </div>
            <div style="grid-column: span 2;">
                <label><strong>Observação:</strong></label>
                <input type="text" name="observacao" placeholder="Ex: 1º Teste do mês" style="width:100%; padding:10px;">
            </div>
        </div>
        <br>
        <button type="submit" class="btn-yws btn-green">💾 Salvar Avaliação</button>
    </form>

    <!-- TABELA DE ÚLTIMAS AVALIAÇÕES -->
    <h3 style="margin-top:40px;"> Últimas Avaliações Registradas</h3>
    <div style="overflow-x:auto;">
        <table>
            <tr>
                <th>Aluno</th>
                <th>Turma</th>
                <th>Tipo</th>
                <th>Nota</th>
                <th>Máxima</th>
                <th>%</th>
                <th>Data</th>
                <?php if (pode_excluir()): ?>
                    <th>Ação</th>
                <?php endif; ?>
            </tr>
            <?php foreach ($ultimas as $av): 
                // Proteção contra divisão por zero e valores nulos
                $nota_max = $av['nota_maxima'] ?? 0;
                $percentual = ($nota_max > 0) ? ($av['nota'] / $nota_max) * 100 : 0;
                $status_cor = $percentual >= 50 ? '#2E7D32' : '#D32F2F';
            ?>
            <tr>
                <td><?= htmlspecialchars($av['aluno'] ?? 'N/A') ?></td>
                <td><?= htmlspecialchars($av['nome_turma'] ?? 'N/A') ?></td>
                <td><?= strtoupper(str_replace('_', ' ', $av['tipo_avaliacao'] ?? '')) ?></td>
                <td><strong><?= number_format($av['nota'] ?? 0, 1) ?></strong></td>
                <td><?= $nota_max > 0 ? $nota_max : '-' ?></td>
                <td style="color:<?= $status_cor ?>; font-weight:bold;">
                    <?= $nota_max > 0 ? number_format($percentual, 1) . '%' : 'N/D' ?>
                </td>
                <td><?= date('d/m/Y', strtotime($av['data_avaliacao'])) ?></td>
                <?php if (pode_excluir()): ?>
                    <td>
                        <a href="?eliminar=<?= $av['id'] ?>" class="btn-yws" style="padding:5px 10px; background:#D32F2F; color:white; text-decoration:none; border-radius:4px;" 
                           onclick="return confirm('Tem certeza que deseja eliminar esta avaliação?')">🗑️</a>
                    </td>
                <?php endif; ?>
            </tr>
            <?php endforeach; ?>
        </table>
    </div>
    
    <p style="text-align:center; margin-top:20px; color:#666;">
        <a href="notas.php" style="color:#0D47A1; font-weight:bold;">📊 Ver todos os resultados →</a>
    </p>
</div>

<script>
function atualizarMax() {
    const select = document.getElementById('tipoAval');
    const selectedOption = select.options[select.selectedIndex];
    const max = selectedOption.getAttribute('data-max');
    
    document.getElementById('notaMaxima').value = max;
    document.getElementById('notaInput').max = max;
    document.getElementById('notaInput').placeholder = 'Máximo: ' + max;
}

// Inicializar no carregamento da página
window.onload = function() {
    atualizarMax();
};
</script>
</body>
</html>