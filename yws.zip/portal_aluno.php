<?php
include 'config.php';
if (!isset($_SESSION['user']) || $_SESSION['user']['tipo'] !== 'aluno') { 
    header("Location: login.php"); 
    exit; 
}

$id_aluno = $_SESSION['user']['id'];
$nome_aluno = $_SESSION['user']['nome'];

// Dados do aluno
$dados = $conn->prepare("SELECT a.*, n.nome_nivel, n.id as nivel_atual 
                         FROM alunos a 
                         LEFT JOIN niveis n ON a.nivel_id = n.id 
                         WHERE a.id = ?");
$dados->execute([$id_aluno]);
$aluno = $dados->fetch();

// Buscar todos os níveis que o aluno tem avaliações (histórico)
$niveis_sql = "SELECT DISTINCT n.id, n.nome_nivel 
               FROM avaliacoes av
               JOIN turmas t ON av.id_turma = t.id
               JOIN niveis n ON t.id_nivel = n.id
               WHERE av.id_aluno = ?
               ORDER BY n.id ASC";
$niveis_stmt = $conn->prepare($niveis_sql);
$niveis_stmt->execute([$id_aluno]);
$niveis_aluno = $niveis_stmt->fetchAll();

// Se não houver níveis no histórico, usar o nível atual
if (empty($niveis_aluno)) {
    $niveis_aluno = [['id' => $aluno['nivel_atual'], 'nome_nivel' => $aluno['nome_nivel']]];
}

// Buscar todas as avaliações do aluno
$avals_sql = "SELECT av.*, t.nome_turma, n.nome_nivel, n.id as nivel_id
              FROM avaliacoes av
              JOIN turmas t ON av.id_turma = t.id
              JOIN niveis n ON t.id_nivel = n.id
              WHERE av.id_aluno = ?
              ORDER BY n.id ASC, av.data_avaliacao ASC";
$avals_stmt = $conn->prepare($avals_sql);
$avals_stmt->execute([$id_aluno]);
$todas_avaliacoes = $avals_stmt->fetchAll();

// Agrupar avaliações por nível
$avals_por_nivel = [];
foreach ($todas_avaliacoes as $av) {
    $avals_por_nivel[$av['nivel_id']][] = $av;
}

// Função para calcular média
function calcular_media($notas) {
    if (empty($notas)) return 0;
    return array_sum($notas) / count($notas);
}
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Portal do Aluno - YWS</title>
    <link rel="stylesheet" href="style.css">
    <style>
        body { font-family: 'Times New Roman', Times, serif; font-size: 11px; margin: 0; padding: 20px; background: #f4f6f9; }
        .header-instituicao { text-align: center; border-bottom: 3px double #0D47A1; padding-bottom: 10px; margin-bottom: 20px; background: white; padding: 20px; border-radius: 8px; }
        .header-instituicao h1 { font-size: 22px; margin: 5px 0; text-transform: uppercase; letter-spacing: 2px; color: #0D47A1; }
        .header-instituicao h2 { font-size: 13px; margin: 0; letter-spacing: 3px; font-weight: normal; color: #333; }
        
        .info-aluno { background: linear-gradient(135deg, #0D47A1, #1565C0); color: white; padding: 20px; border-radius: 8px; margin-bottom: 25px; box-shadow: 0 4px 10px rgba(0,0,0,0.1); }
        .info-aluno h2 { margin: 0 0 10px 0; font-size: 22px; }
        .info-aluno p { margin: 5px 0; font-size: 14px; }

        .nivel-separator { background: #D32F2F; color: white; font-weight: bold; font-size: 15px; padding: 10px 15px; margin: 30px 0 10px 0; border-radius: 6px 6px 0 0; display: flex; justify-content: space-between; align-items: center; }
        .badge-atual { background: #2E7D32; padding: 4px 10px; border-radius: 12px; font-size: 12px; }
        .badge-concluido { background: #666; padding: 4px 10px; border-radius: 12px; font-size: 12px; }

        .tabela-wrapper { overflow-x: auto; background: white; border-radius: 0 0 6px 6px; box-shadow: 0 2px 8px rgba(0,0,0,0.05); }
        table { width: 100%; border-collapse: collapse; min-width: 900px; }
        th, td { border: 1px solid #ccc; padding: 6px 4px; text-align: center; vertical-align: middle; }
        th { background-color: #0D47A1; color: white; font-weight: bold; font-size: 10px; text-transform: uppercase; }
        td { font-size: 11px; }
        .nome-col { text-align: left !important; padding-left: 10px !important; font-weight: bold; min-width: 150px; }
        
        .resumo-nivel { background: #e8f5e9; border: 1px solid #2E7D32; padding: 15px; border-radius: 6px; margin-top: 15px; display: flex; flex-wrap: wrap; gap: 15px; align-items: center; }
        .resumo-item { font-size: 13px; }
        .resumo-item strong { color: #0D47A1; }
        .status-final { background: #0D47A1; color: white; padding: 8px 15px; border-radius: 6px; font-weight: bold; font-size: 14px; margin-left: auto; }
        .status-reprovado { background: #D32F2F; }

        .legenda { margin-top: 30px; font-size: 10px; line-height: 1.6; color: #666; background: white; padding: 15px; border-radius: 6px; border-left: 4px solid #0D47A1; }
        .btn-sair { display: inline-block; margin-top: 30px; padding: 12px 30px; background: #D32F2F; color: white; text-decoration: none; border-radius: 6px; font-weight: bold; font-size: 14px; transition: 0.3s; }
        .btn-sair:hover { background: #B71C1C; }
    </style>
</head>
<body>

<div class="header-instituicao">
    <img src="logo.png" alt="Logo" style="max-width:80px;" onerror="this.style.display='none'">
    <h1>THE YOUNG WISE SCHOOL</h1>
    <h2>CENTRO DE FORMAÇÃO</h2>
</div>

<div class="container">
    <!-- INFORMAÇÕES DO ALUNO -->
    <div class="info-aluno">
        <h2>👋 Bem-vindo(a), <?= htmlspecialchars($nome_aluno) ?>!</h2>
        <p><strong>Nível Atual:</strong> <?= htmlspecialchars($aluno['nome_nivel']) ?> | <strong>Curso:</strong> <?= htmlspecialchars($aluno['curso'] ?? 'Inglês') ?></p>
    </div>

    <?php if (empty($todas_avaliacoes)): ?>
        <div style="background:white; text-align:center; padding:40px; border-radius:8px;">
            <h3>📚 Nenhuma avaliação registrada ainda.</h3>
            <p>Assim que o professor lançar suas notas, elas aparecerão aqui organizadas por nível.</p>
        </div>
    <?php else: 
        foreach ($niveis_aluno as $nivel):
            $nivel_id = $nivel['id'];
            $nivel_nome = $nivel['nome_nivel'];
            $avals_nivel = $avals_por_nivel[$nivel_id] ?? [];
            
            if (empty($avals_nivel)) continue;
            
            $eh_nivel_atual = ($nivel_id == $aluno['nivel_atual']);
            
            // Extrair notas por tipo
            $escritas = []; $orais = []; $ditados = [];
            $exame_esc = 0; $exame_oral = 0;
            
            foreach ($avals_nivel as $av) {
                if ($av['tipo_avaliacao'] === 'avaliacao_escrita' || $av['tipo_avaliacao'] === 'avaliacao') $escritas[] = $av['nota'];
                elseif ($av['tipo_avaliacao'] === 'avaliacao_oral') $orais[] = $av['nota'];
                elseif ($av['tipo_avaliacao'] === 'ditado') $ditados[] = $av['nota'];
                elseif ($av['tipo_avaliacao'] === 'exame_escrito') $exame_esc = $av['nota'];
                elseif ($av['tipo_avaliacao'] === 'exame_oral') $exame_oral = $av['nota'];
            }
            
            // Cálculos de Médias
            $med_esc = calcular_media($escritas);
            $med_oral = calcular_media($orais);
            $med_dit = calcular_media($ditados);
            $med_geral_avals = calcular_media(array_merge($escritas, $orais, $ditados));
            
            $exames_valores = [];
            if ($exame_esc > 0) $exames_valores[] = $exame_esc;
            if ($exame_oral > 0) $exames_valores[] = $exame_oral;
            $med_exames = calcular_media($exames_valores);
            
            $media_final = ($med_geral_avals + $med_exames) / 2;
            $status_final = $media_final >= 10 ? 'Aprovado' : 'Reprovado';
            $cor_status = $status_final === 'Aprovado' ? '#2E7D32' : '#D32F2F';
    ?>
    
    <!-- SEPARADOR DE NÍVEL -->
    <div class="nivel-separator">
        <span>📚 Nível: <?= htmlspecialchars($nivel_nome) ?></span>
        <?php if ($eh_nivel_atual): ?>
            <span class="badge-atual">Nível Atual</span>
        <?php else: ?>
            <span class="badge-concluido">Concluído</span>
        <?php endif; ?>
    </div>

    <!-- TABELA ÚNICA CONSOLIDADA -->
    <div class="tabela-wrapper">
        <table>
            <thead>
                <tr>
                    <th>Nº</th>
                    <th class="nome-col">Nome do Aluno</th>
                    <th>A1 E.</th><th>A2 E.</th><th>A3 E.</th><th>A4 E.</th>
                    <th>A1 O.</th><th>A2 O.</th><th>A3 O.</th><th>A4 O.</th>
                    <th>D1</th><th>D2</th><th>D3</th><th>D4</th>
                    <th style="background:#1565C0;">M.D</th>
                    <th style="background:#1565C0;">M.E</th>
                    <th style="background:#1565C0;">M.O</th>
                    <th style="background:#F57C00;">Ex.E</th>
                    <th style="background:#F57C00;">Ex.O</th>
                    <th style="background:#0D47A1;">Mg.A</th>
                    <th style="background:#0D47A1;">Mg.E</th>
                    <th style="background:<?= $cor_status ?>;">Obs.</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>01</td>
                    <td class="nome-col"><?= htmlspecialchars($nome_aluno) ?></td>
                    
                    <!-- Escritas -->
                    <td><?= $escritas[0] ?? '-' ?></td>
                    <td><?= $escritas[1] ?? '-' ?></td>
                    <td><?= $escritas[2] ?? '-' ?></td>
                    <td><?= $escritas[3] ?? '-' ?></td>
                    
                    <!-- Orais -->
                    <td><?= $orais[0] ?? '-' ?></td>
                    <td><?= $orais[1] ?? '-' ?></td>
                    <td><?= $orais[2] ?? '-' ?></td>
                    <td><?= $orais[3] ?? '-' ?></td>
                    
                    <!-- Ditados -->
                    <td><?= $ditados[0] ?? '-' ?></td>
                    <td><?= $ditados[1] ?? '-' ?></td>
                    <td><?= $ditados[2] ?? '-' ?></td>
                    <td><?= $ditados[3] ?? '-' ?></td>
                    
                    <!-- Médias -->
                    <td style="font-weight:bold;"><?= $med_dit > 0 ? number_format($med_dit, 1) : '-' ?></td>
                    <td style="font-weight:bold;"><?= $med_esc > 0 ? number_format($med_esc, 1) : '-' ?></td>
                    <td style="font-weight:bold;"><?= $med_oral > 0 ? number_format($med_oral, 1) : '-' ?></td>
                    
                    <!-- Exames -->
                    <td><?= $exame_esc > 0 ? $exame_esc : '-' ?></td>
                    <td><?= $exame_oral > 0 ? $exame_oral . '%' : '-' ?></td>
                    
                    <!-- Médias Gerais -->
                    <td style="font-weight:bold;"><?= $med_geral_avals > 0 ? number_format($med_geral_avals, 1) : '-' ?></td>
                    <td style="font-weight:bold;"><?= $med_exames > 0 ? number_format($med_exames, 1) : '-' ?></td>
                    
                    <!-- Status -->
                    <td style="font-weight:bold; color:<?= $cor_status ?>;"><?= $status_final ?></td>
                </tr>
            </tbody>
        </table>
    </div>

    <!-- RESUMO DO NÍVEL -->
    <div class="resumo-nivel">
        <div class="resumo-item"><strong>Média Escritas:</strong> <?= $med_esc > 0 ? number_format($med_esc, 1) : '-' ?></div>
        <div class="resumo-item"><strong>Média Orais:</strong> <?= $med_oral > 0 ? number_format($med_oral, 1) : '-' ?></div>
        <div class="resumo-item"><strong>Média Ditados:</strong> <?= $med_dit > 0 ? number_format($med_dit, 1) : '-' ?></div>
        <div class="resumo-item"><strong>Média Final:</strong> <?= number_format($media_final, 1) ?></div>
        <div class="status-final <?= $status_final === 'Reprovado' ? 'status-reprovado' : '' ?>">
            <?= $status_final ?>
        </div>
    </div>

    <?php 
        endforeach; // Fim do foreach de níveis
    endif; // Fim do if de avaliações vazias
    ?>

    <!-- LEGENDA -->
    <div class="legenda">
        <strong>Legenda:</strong> A1-A4 E. = Avaliações Escritas | A1-A4 O. = Avaliações Orais | D1-D4 = Ditados<br>
        M.D = Média Ditados | M.E = Média Escritas | M.O = Média Orais | Ex.E = Exame Escrito | Ex.O = Exame Oral<br>
        Mg.A = Média Geral das Avaliações | Mg.E = Média Geral dos Exames | Obs. = Aprovado (≥10) / Reprovado (<10)
    </div>

    <div style="text-align:center; margin-top:30px;">
        <a href="login.php?logout=1" class="btn-sair">🚪 Sair do Portal</a>
    </div>
</div>

</body>
</html>