<?php
include 'config.php';
if (!isset($_SESSION['user']) || $_SESSION['user']['tipo'] !== 'funcionario') {
    header("Location: login.php"); exit;
}

// SALVAR MOVIMENTO (falta, férias, contrato)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['acao']) && $_POST['acao'] === 'movimento') {
    $conn->prepare("INSERT INTO rh_movimentos (id_funcionario, tipo_movimento, data, observacao) VALUES (?, ?, ?, ?)")
         ->execute([$_POST['id_funcionario'], $_POST['tipo'], $_POST['data'], limpar($_POST['observacao'])]);
    header("Location: rh_folha.php"); exit;
}

// EXCLUIR MOVIMENTO
if (isset($_GET['excluir_mov'])) {
    $conn->prepare("DELETE FROM rh_movimentos WHERE id = ?")->execute([$_GET['excluir_mov']]);
    header("Location: rh_folha.php"); exit;
}

$funcs = $conn->query("SELECT * FROM funcionarios WHERE status='ativo' ORDER BY nome")->fetchAll();
$movimentos = $conn->query("SELECT m.*, f.nome FROM rh_movimentos m LEFT JOIN funcionarios f ON m.id_funcionario=f.id ORDER BY m.data DESC")->fetchAll();

// FILTRO DE MÊS PARA FOLHA
$mes_folha = $_GET['mes'] ?? date('Y-m');

// CÁLCULO DA FOLHA
$folha = [];
$total_folha = 0;
foreach ($funcs as $f) {
    // Conta faltas no mês
    $stmt = $conn->prepare("SELECT COUNT(*) FROM rh_movimentos WHERE id_funcionario=? AND tipo_movimento='falta' AND DATE_FORMAT(data, '%Y-%m')=?");
    $stmt->execute([$f['id'], $mes_folha]);
    $faltas = $stmt->fetchColumn();

    // Desconto: cada falta = salário/30
    $desconto_falta = ($f['salario'] / 30) * $faltas;
    $liquido = $f['salario'] - $desconto_falta;
    $total_folha += $liquido;

    $folha[] = [
        'func' => $f,
        'faltas' => $faltas,
        'desconto' => $desconto_falta,
        'liquido' => $liquido
    ];
}
?>
<!DOCTYPE html>
<html lang="pt">
<head><meta charset="UTF-8"><title>RH e Folha - YWS</title><link rel="stylesheet" href="style.css"></head>
<body>
<div class="header"><h1>The Young Wise School - YWS</h1><p>Recursos Humanos e Folha de Pagamento</p></div>
<?php include 'menu_admin.php'; ?>

<div class="container">
    <!-- LANÇAMENTO DE MOVIMENTOS -->
    <h2>📅 Lançar Movimento (Falta / Férias / Contrato)</h2>
    <form method="POST" class="card">
        <input type="hidden" name="acao" value="movimento">
        <div style="display:grid; grid-template-columns: 2fr 1fr 1fr 2fr; gap:15px;">
            <div><label>Funcionário:</label>
                <select name="id_funcionario" required style="width:100%; padding:8px;">
                    <?php foreach ($funcs as $f): ?>
                        <option value="<?= $f['id'] ?>"><?= limpar($f['nome']) ?> - <?= limpar($f['cargo']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div><label>Tipo:</label>
                <select name="tipo" required style="width:100%; padding:8px;">
                    <option value="falta">Falta</option>
                    <option value="férias">Férias</option>
                    <option value="contrato">Contrato</option>
                    <option value="outro">Outro</option>
                </select>
            </div>
            <div><label>Data:</label><input type="date" name="data" required style="width:100%; padding:8px;"></div>
            <div><label>Observação:</label><input type="text" name="observacao" style="width:100%; padding:8px;"></div>
        </div>
        <br>
        <button type="submit" class="btn-yws">💾 Lançar</button>
    </form>

    <!-- HISTÓRICO -->
    <h2 style="margin-top:30px;">📋 Histórico de Movimentos</h2>
    <table>
        <tr><th>Funcionário</th><th>Tipo</th><th>Data</th><th>Observação</th><th>Ação</th></tr>
        <?php foreach ($movimentos as $m): ?>
            <tr>
                <td><?= limpar($m['nome']) ?></td>
                <td><span class="status-badge" style="background:<?= $m['tipo_movimento']=='falta'?'var(--yws-red)':($m['tipo_movimento']=='férias'?'#28a745':'#0066cc') ?>; color:white; padding:3px 8px; border-radius:10px;"><?= strtoupper($m['tipo_movimento']) ?></span></td>
                <td><?= date('d/m/Y', strtotime($m['data'])) ?></td>
                <td><?= limpar($m['observacao'] ?? '-') ?></td>
                <td><a href="?excluir_mov=<?= $m['id'] ?>" class="btn-yws" style="padding:5px 10px;" onclick="return confirm('Excluir?')">🗑️</a></td>
            </tr>
        <?php endforeach; ?>
    </table>

    <!-- FOLHA DE PAGAMENTO -->
    <h2 style="margin-top:40px;">💰 Folha de Pagamento — <?= date('m/Y', strtotime($mes_folha.'-01')) ?></h2>
    <form method="GET" style="margin-bottom:15px;">
        <label>Referência:</label>
        <input type="month" name="mes" value="<?= $mes_folha ?>" style="padding:8px;">
        <button type="submit" class="btn-yws">🔍 Filtrar</button>
        <button type="button" onclick="window.print()" class="btn-yws" style="background:#28a745;">🖨️ Imprimir Folha</button>
    </form>

    <table>
        <tr>
            <th>Funcionário</th><th>Cargo</th><th>IBAN</th><th>Salário Base</th>
            <th>Faltas</th><th>Desconto</th><th>Líquido</th>
        </tr>
        <?php foreach ($folha as $f): ?>
            <tr>
                <td><?= limpar($f['func']['nome']) ?></td>
                <td><?= limpar($f['func']['cargo']) ?></td>
                <td><?= limpar($f['func']['iban'] ?? '-') ?></td>
                <td><?= number_format($f['func']['salario'], 2, ',', '.') ?> Kz</td>
                <td><?= $f['faltas'] ?></td>
                <td style="color:var(--yws-red);">- <?= number_format($f['desconto'], 2, ',', '.') ?> Kz</td>
                <td><strong><?= number_format($f['liquido'], 2, ',', '.') ?> Kz</strong></td>
            </tr>
        <?php endforeach; ?>
        <tr style="background:var(--yws-blue); color:white; font-weight:bold;">
            <td colspan="6" style="text-align:right;">TOTAL DA FOLHA:</td>
            <td><?= number_format($total_folha, 2, ',', '.') ?> Kz</td>
        </tr>
    </table>
</div>
</body>
</html>