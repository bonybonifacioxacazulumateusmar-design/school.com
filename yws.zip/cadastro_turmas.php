<?php
include 'config.php';
if (!isset($_SESSION['user']) || $_SESSION['user']['tipo'] !== 'funcionario') {
    header("Location: login.php"); exit;
}

if (isset($_GET['excluir'])) {
    $conn->prepare("DELETE FROM turmas WHERE id = ?")->execute([$_GET['excluir']]);
    header("Location: cadastro_turmas.php"); exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome     = limpar($_POST['nome_turma']);
    $prof     = $_POST['id_professor'];
    $nivel    = $_POST['id_nivel'];
    $periodo  = limpar($_POST['periodo']);

    if (isset($_POST['id']) && $_POST['id'] > 0) {
        $conn->prepare("UPDATE turmas SET nome_turma=?, id_professor=?, id_nivel=?, periodo=? WHERE id=?")
             ->execute([$nome, $prof, $nivel, $periodo, $_POST['id']]);
    } else {
        $conn->prepare("INSERT INTO turmas (nome_turma, id_professor, id_nivel, periodo) VALUES (?, ?, ?, ?)")
             ->execute([$nome, $prof, $nivel, $periodo]);
    }
    header("Location: cadastro_turmas.php"); exit;
}

$turmas = $conn->query("SELECT t.*, f.nome as professor, n.nome_nivel FROM turmas t LEFT JOIN funcionarios f ON t.id_professor=f.id LEFT JOIN niveis n ON t.id_nivel=n.id ORDER BY t.nome_turma")->fetchAll();
$professores = $conn->query("SELECT id, nome FROM funcionarios WHERE cargo='Professor' OR departamento_id=6")->fetchAll();
$niveis = $conn->query("SELECT * FROM niveis")->fetchAll();

$editando = null;
if (isset($_GET['editar'])) {
    $stmt = $conn->prepare("SELECT * FROM turmas WHERE id = ?");
    $stmt->execute([$_GET['editar']]);
    $editando = $stmt->fetch();
}
?>
<!DOCTYPE html>
<html lang="pt">
<head><meta charset="UTF-8"><title>Cadastro de Turmas - YWS</title><link rel="stylesheet" href="style.css"></head>
<body>
<div class="header"><h1>The Young Wise School - YWS</h1><p>Gestão de Turmas</p></div>
<?php include 'menu_admin.php'; ?>

<div class="container">
    <h2><?= $editando ? '✏️ Editar Turma' : '➕ Nova Turma' ?></h2>
    <form method="POST" class="card">
        <input type="hidden" name="id" value="<?= $editando['id'] ?? 0 ?>">
        <div style="display:grid; grid-template-columns: 1fr 1fr; gap:15px;">
            <div><label>Nome da Turma:</label><input type="text" name="nome_turma" required value="<?= $editando['nome_turma'] ?? '' ?>" style="width:100%; padding:8px;"></div>
            <div><label>Período:</label><input type="text" name="periodo" placeholder="Ex: Manhã, Tarde, Noite" value="<?= $editando['periodo'] ?? '' ?>" style="width:100%; padding:8px;"></div>
            <div><label>Professor:</label>
                <select name="id_professor" required style="width:100%; padding:8px;">
                    <option value="">-- Selecione --</option>
                    <?php foreach ($professores as $p): ?>
                        <option value="<?= $p['id'] ?>" <?= ($editando['id_professor'] ?? '') == $p['id'] ? 'selected' : '' ?>><?= limpar($p['nome']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div><label>Nível:</label>
                <select name="id_nivel" required style="width:100%; padding:8px;">
                    <?php foreach ($niveis as $n): ?>
                        <option value="<?= $n['id'] ?>" <?= ($editando['id_nivel'] ?? '') == $n['id'] ? 'selected' : '' ?>><?= limpar($n['nome_nivel']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
        <br>
        <button type="submit" class="btn-yws">💾 Salvar</button>
    </form>

    <h2 style="margin-top:30px;">📋 Lista de Turmas (<?= count($turmas) ?>)</h2>
    <table>
        <tr><th>ID</th><th>Turma</th><th>Professor</th><th>Nível</th><th>Período</th><th>Ações</th></tr>
        <?php foreach ($turmas as $t): ?>
            <tr>
                <td><?= $t['id'] ?></td>
                <td><?= limpar($t['nome_turma']) ?></td>
                <td><?= limpar($t['professor'] ?? 'Não atribuído') ?></td>
                <td><?= limpar($t['nome_nivel']) ?></td>
                <td><?= limpar($t['periodo']) ?></td>
                <td>
                    <a href="?editar=<?= $t['id'] ?>" class="btn-yws" style="padding:5px 10px; background:#0066cc;">✏️</a>
                    <a href="?excluir=<?= $t['id'] ?>" class="btn-yws" style="padding:5px 10px;" onclick="return confirm('Excluir esta turma?')">🗑️</a>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>
</div>
</body>
</html>