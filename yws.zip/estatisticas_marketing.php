<?php
include 'config.php';
if (!isset($_SESSION['user']) || $_SESSION['user']['tipo'] !== 'funcionario') {
    header("Location: login.php"); exit;
}

// Novos alunos por mês (últimos 12 meses)
$novos_por_mes = $conn->query("SELECT 
    DATE_FORMAT(data_matricula, '%Y-%m') as mes,
    COUNT(*) as total
    FROM alunos 
    WHERE data_matricula >= DATE_SUB(CURRENT_DATE, INTERVAL 12 MONTH)
    GROUP BY DATE_FORMAT(data_matricula, '%Y-%m')
    ORDER BY mes DESC")->fetchAll();

// Taxa de conversão (matrículas vs consultas)
$total_ativos = $conn->query("SELECT COUNT(*) FROM alunos WHERE status='ativo'")->fetchColumn();
$total_inativos = $conn->query("SELECT COUNT(*) FROM alunos WHERE status='inativo'")->fetchColumn();
$taxa_retencao = $total_ativos > 0 ? round(($total_ativos / ($total_ativos + $total_inativos)) * 100, 2) : 0;

// Alunos por nível (gráfico simplificado)
$alunos_nivel = $conn->query("SELECT n.nome_nivel, COUNT(a.id) as total
                              FROM niveis n
                              LEFT JOIN alunos a ON n.id = a.nivel_id AND a.status='ativo'
                              GROUP BY n.id ORDER BY total DESC")->fetchAll();

// Projeção de receita
$receita_mensal = $conn->query("SELECT SUM(n.valor_propina * (SELECT COUNT(*) FROM alunos WHERE nivel_id = n.id AND status='ativo')) as total
                                FROM niveis n")->fetchColumn();

// Crescimento mensal
$crescimento = $conn->query("SELECT 
    (SELECT COUNT(*) FROM alunos WHERE MONTH(data_matricula) = MONTH(CURRENT_DATE) AND YEAR(data_matricula) = YEAR(CURRENT_DATE)) -
    (SELECT COUNT(*) FROM alunos WHERE MONTH(data_matricula) = MONTH(DATE_SUB(CURRENT_DATE, INTERVAL 1 MONTH)) AND YEAR(data_matricula) = YEAR(DATE_SUB(CURRENT_DATE, INTERVAL 1 MONTH)))
    as diff")->fetchColumn();
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Estatísticas de Marketing - YWS</title>
    <link rel="stylesheet" href="style.css">
    <style>
        .chart-bar {
            background: linear-gradient(135deg, #0D47A1, #D32F2F);
            height: 30px;
            border-radius: 4px;
            margin: 5px 0;
            display: flex;
            align-items: center;
            padding: 0 10px;
            color: white;
            font-weight: bold;
            transition: width 0.6s ease;
        }
        .metric-box {
            background: white;
            padding: 20px;
            border-radius: 8px;
            margin: 10px 0;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            border-left: 5px solid #0D47A1;
        }
        .metric-box h3 { margin: 0 0 10px 0; color: #666; font-size: 14px; }
        .metric-box .value { font-size: 32px; font-weight: bold; color: #0D47A1; }
        .metric-box.positive { border-left-color: #2E7D32; }
        .metric-box.positive .value { color: #2E7D32; }
        .metric-box.negative { border-left-color: #D32F2F; }
        .metric-box.negative .value { color: #D32F2F; }
    </style>
</head>
<body>
<div class="header">
    <h1>The Young Wise School - YWS</h1>
    <p>Painel de Marketing e Vendas</p>
</div>
<?php include 'menu_admin.php'; ?>

<div class="container">
    <h2>📊 Indicadores de Performance</h2>
    <div class="stats-grid">
        <div class="metric-box <?= $crescimento >= 0 ? 'positive' : 'negative' ?>">
            <h3>Crescimento Mensal</h3>
            <div class="value"><?= $crescimento >= 0 ? '+' : '' ?><?= $crescimento ?></div>
            <p>novos alunos este mês</p>
        </div>
        <div class="metric-box positive">
            <h3>Taxa de Retenção</h3>
            <div class="value"><?= $taxa_retencao ?>%</div>
            <p>alunos ativos</p>
        </div>
        <div class="metric-box">
            <h3>Receita Mensal Projetada</h3>
            <div class="value" style="font-size:24px;"><?= number_format($receita_mensal ?? 0, 2, ',', '.') ?> Kz</div>
        </div>
        <div class="metric-box">
            <h3>Total de Alunos Ativos</h3>
            <div class="value"><?= $total_ativos ?></div>
        </div>
    </div>

    <h2 style="margin-top:30px;">📈 Novos Alunos por Mês (Últimos 12 Meses)</h2>
    <div class="card">
        <?php foreach (array_reverse($novos_por_mes) as $m): ?>
            <div style="margin:10px 0;">
                <div style="display:flex; justify-content:space-between; margin-bottom:5px;">
                    <strong><?= date('m/Y', strtotime($m['mes'] . '-01')) ?></strong>
                    <span><?= $m['total'] ?> alunos</span>
                </div>
                <div class="chart-bar" style="width: <?= min($m['total'] * 10, 100) ?>%;">
                    <?= $m['total'] ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <h2 style="margin-top:30px;">🎓 Distribuição por Nível</h2>
    <div class="card">
        <?php 
        $max_alunos = max(array_column($alunos_nivel, 'total'));
        foreach ($alunos_nivel as $n): 
            $percentual = $max_alunos > 0 ? ($n['total'] / $max_alunos) * 100 : 0;
        ?>
            <div style="margin:10px 0;">
                <div style="display:flex; justify-content:space-between; margin-bottom:5px;">
                    <strong><?= htmlspecialchars($n['nome_nivel']) ?></strong>
                    <span><?= $n['total'] ?> alunos</span>
                </div>
                <div class="chart-bar" style="width: <?= $percentual ?>%; background: linear-gradient(135deg, #0D47A1, #1565C0);">
                    <?= $n['total'] ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <h2 style="margin-top:30px;">💡 Insights de Marketing</h2>
    <div class="card card-blue">
        <ul style="line-height:2;">
            <?php if ($crescimento > 0): ?>
                <li>✅ Crescimento positivo de <strong><?= $crescimento ?> alunos</strong> este mês</li>
            <?php else: ?>
                <li>⚠️ Atenção: crescimento negativo. Reforce campanhas de captação.</li>
            <?php endif; ?>
            
            <?php if ($taxa_retencao > 80): ?>
                <li>✅ Excelente taxa de retenção (<?= $taxa_retencao ?>%)</li>
            <?php elseif ($taxa_retencao > 60): ?>
                <li>⚠️ Taxa de retenção razoável. Invista em fidelização.</li>
            <?php else: ?>
                <li> Taxa de retenção baixa. Ação urgente necessária!</li>
            <?php endif; ?>
            
            <li>📊 Nível mais procurado: <strong><?= $alunos_nivel[0]['nome_nivel'] ?? 'N/A' ?></strong></li>
        </ul>
    </div>

    <div style="text-align:center; margin-top:30px;">
        <button onclick="window.print()" class="btn-yws btn-green">🖨️ Imprimir Relatório</button>
        <a href="dashboard.php" class="btn-yws">📊 Voltar ao Dashboard</a>
    </div>
</div>
</body>
</html>