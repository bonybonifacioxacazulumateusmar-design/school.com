<?php
include 'config.php';
if (!isset($_SESSION['user'])) { header("Location: login.php"); exit; }

$cargo = $_SESSION['user']['cargo'] ?? '';
$nome = $_SESSION['user']['nome'] ?? '';

// Estatísticas Pedagógicas
$total_alunos = $conn->query("SELECT COUNT(*) FROM alunos WHERE status='ativo'")->fetchColumn();
$total_func = $conn->query("SELECT COUNT(*) FROM funcionarios WHERE status='ativo'")->fetchColumn();
$total_turmas = $conn->query("SELECT COUNT(*) FROM turmas")->fetchColumn();
$novos_alunos = $conn->query("SELECT COUNT(*) FROM alunos WHERE MONTH(data_matricula) = MONTH(CURRENT_DATE()) AND YEAR(data_matricula) = YEAR(CURRENT_DATE())")->fetchColumn();

// Alunos por nível
$niveis = $conn->query("SELECT n.nome_nivel, COUNT(a.id) as total 
                        FROM niveis n LEFT JOIN alunos a ON n.id = a.nivel_id 
                        GROUP BY n.id ORDER BY n.id")->fetchAll();

// Turmas por período
$turmas_periodo = $conn->query("SELECT t.periodo, t.nome_turma, f.nome as professor, n.nome_nivel
                                FROM turmas t 
                                LEFT JOIN funcionarios f ON t.id_professor = f.id
                                LEFT JOIN niveis n ON t.id_nivel = n.id
                                ORDER BY t.periodo, t.nome_turma")->fetchAll();

// Funcionários por departamento
$deptos = $conn->query("SELECT d.nome, COUNT(f.id) as total FROM departamentos d LEFT JOIN funcionarios f ON d.id = f.departamento_id GROUP BY d.id")->fetchAll();
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Estatística Geral - YWS</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="header">
    <h1>The Young Wise School - YWS</h1>
    <p style="font-style: italic; color: #ffcc00;">"More than just speak English"</p>
    <p>Painel Estatístico e Pedagógico | Bem-vindo, <strong><?= htmlspecialchars($nome) ?></strong></p>
</div>

<?php include 'menu_admin.php'; ?>

<div class="container">
    <!-- LOGOTIPO -->
    <div class="logo-container">
        <img src="logo.png" alt="YWS Logo" onerror="this.style.display='none'">
        <div class="lema">"More than just speak English"</div>
    </div>

    <!-- ESTATÍSTICAS GERAIS -->
    <h2>📊 Indicadores da Escola</h2>
    <div class="stats-grid">
        <div class="stat-card">
            <h3>Total de Alunos Ativos</h3>
            <div class="number"><?= $total_alunos ?></div>
        </div>
        <div class="stat-card green">
            <h3>Total de Funcionários</h3>
            <div class="number"><?= $total_func ?></div>
        </div>
        <div class="stat-card">
            <h3>Total de Turmas</h3>
            <div class="number"><?= $total_turmas ?></div>
        </div>
        <div class="stat-card green">
            <h3>Novos Alunos (Este Mês)</h3>
            <div class="number"><?= $novos_alunos ?></div>
        </div>
    </div>

    <!-- ALUNOS POR NÍVEL -->
    <h2 style="margin-top:30px;">🎓 Distribuição de Alunos por Nível</h2>
    <table>
        <tr><th>Nível</th><th>Quantidade de Alunos</th><th>% do Total</th></tr>
        <?php foreach ($niveis as $n): 
            $percentual = $total_alunos > 0 ? round(($n['total'] / $total_alunos) * 100, 1) : 0;
        ?>
            <tr>
                <td><strong><?= htmlspecialchars($n['nome_nivel']) ?></strong></td>
                <td><?= $n['total'] ?></td>
                <td>
                    <div style="background:#e0e0e0; border-radius:10px; height:20px; width:100%;">
                        <div style="background:#0D47A1; height:100%; border-radius:10px; width:<?= $percentual ?>%; text-align:center; color:white; font-size:12px; line-height:20px;">
                            <?= $percentual ?>%
                        </div>
                    </div>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>

    <!-- TURMAS POR PERÍODO -->
    <h2 style="margin-top:30px;">🏫 Turmas Ativas por Período</h2>
    <table>
        <tr><th>Período</th><th>Turma</th><th>Nível</th><th>Professor Responsável</th></tr>
        <?php foreach ($turmas_periodo as $t): ?>
            <tr>
                <td><strong><?= htmlspecialchars($t['periodo'] ?: 'Não definido') ?></strong></td>
                <td><?= htmlspecialchars($t['nome_turma'] ?? '-') ?></td>
                <td><?= htmlspecialchars($t['nome_nivel'] ?? '-') ?></td>
                <td><?= htmlspecialchars($t['professor'] ?? 'Não atribuído') ?></td>
            </tr>
        <?php endforeach; ?>
    </table>

    <div style="text-align:center; margin-top:30px;">
        <button onclick="window.print()" class="btn-yws btn-green">🖨️ Imprimir Relatório Pedagógico</button>
    </div>
</div>
</body>
</html>