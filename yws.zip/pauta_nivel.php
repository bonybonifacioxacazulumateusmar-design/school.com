<?php
include 'config.php';
if (!isset($_SESSION['user'])) { header("Location: login.php"); exit; }

$id_turma = $_GET['turma'] ?? 0;
$nome_turma = $_GET['nome'] ?? 'Turma';

// Buscar alunos da turma
$sql = "SELECT a.id, a.nome, n.nome_nivel, t.nome_turma
        FROM alunos a
        JOIN niveis n ON a.nivel_id = n.id
        JOIN turmas t ON t.id_nivel = n.id
        WHERE t.id = ?
        ORDER BY a.nome";
$stmt = $conn->prepare($sql);
$stmt->execute([$id_turma]);
$alunos = $stmt->fetchAll();

// Buscar todas as avaliações dos alunos desta turma
$avals_sql = "SELECT id_aluno, tipo_avaliacao, nota, nota_maxima, data_avaliacao
              FROM avaliacoes 
              WHERE id_turma = ? 
              ORDER BY id_aluno, data_avaliacao";
$avals_stmt = $conn->prepare($avals_sql);
$avals_stmt->execute([$id_turma]);
$avaliacoes = $avals_stmt->fetchAll();

// Agrupar avaliações por aluno e tipo
$notas_por_aluno = [];
foreach ($avaliacoes as $av) {
    $notas_por_aluno[$av['id_aluno']][] = $av;
}

// Função para calcular média
function calcular_media($notas) {
    if (empty($notas)) return 0;
    return array_sum($notas) / count($notas);
}

// Função para gerar tabela
function gerar_tabela($titulo, $colunas, $alunos, $notas_por_aluno, $tipo_filtro, $max_colunas) {
    echo "<h3 style='background:#0D47A1; color:white; padding:8px 12px; margin:20px 0 10px 0; font-size:14px; text-transform:uppercase; letter-spacing:1px;'>📋 $titulo</h3>";
    echo "<table>";
    echo "<thead><tr>";
    echo "<th class='num-col'>Nº</th>";
    echo "<th class='nome-col'>Nome do Aluno</th>";
    foreach ($colunas as $col) {
        echo "<th>$col</th>";
    }
    echo "<th class='media-col'>Média</th>";
    echo "<th class='status-col'>Obs.</th>";
    echo "</tr></thead><tbody>";
    
    $num = 1;
    foreach ($alunos as $aluno) {
        $notas = $notas_por_aluno[$aluno['id']] ?? [];
        $notas_filtradas = [];
        
        foreach ($notas as $n) {
            if ($n['tipo_avaliacao'] === $tipo_filtro) {
                $notas_filtradas[] = $n['nota'];
            }
        }
        
        $media = calcular_media($notas_filtradas);
        $status = $media >= 10 ? 'Aprovado' : ($media > 0 ? 'Reprovado' : '-');
        $cor = $media >= 10 ? '#2E7D32' : ($media > 0 ? '#D32F2F' : '#666');
        
        echo "<tr>";
        echo "<td class='num-col'>" . str_pad($num++, 2, '0', STR_PAD_LEFT) . "</td>";
        echo "<td class='nome-col'><strong>" . htmlspecialchars($aluno['nome']) . "</strong></td>";
        
        for ($i = 0; $i < $max_colunas; $i++) {
            echo "<td class='nota-col'>" . (isset($notas_filtradas[$i]) ? $notas_filtradas[$i] : '-') . "</td>";
        }
        
        echo "<td class='media-col'>" . ($media > 0 ? number_format($media, 1) : '-') . "</td>";
        echo "<td class='status-col' style='color:$cor; font-weight:bold;'>$status</td>";
        echo "</tr>";
    }
    
    echo "</tbody></table>";
}
?>
<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <title>Pauta - <?= htmlspecialchars($nome_turma) ?> - YWS</title>
    <style>
        @page { size: landscape; margin: 1cm; }
        body { 
            font-family: 'Times New Roman', Times, serif; 
            font-size: 10px;
            margin: 0;
            padding: 10px;
        }
        .header-instituicao { 
            text-align: center; 
            border-bottom: 2px solid #000; 
            padding-bottom: 10px; 
            margin-bottom: 15px; 
        }
        .header-instituicao h1 { 
            font-size: 18px; 
            margin: 5px 0; 
            text-transform: uppercase; 
            letter-spacing: 2px;
        }
        .header-instituicao h2 { 
            font-size: 12px; 
            margin: 0; 
            letter-spacing: 3px; 
            font-weight: normal;
        }
        .titulo-pauta {
            text-align: center;
            font-size: 16px;
            font-weight: bold;
            margin: 15px 0;
            text-decoration: underline;
        }
        .info-turma {
            text-align: center;
            font-size: 12px;
            margin-bottom: 15px;
        }
        table { 
            width: 100%; 
            border-collapse: collapse; 
            margin-bottom: 20px;
        }
        th, td { 
            border: 1px solid #000; 
            padding: 4px 6px; 
            text-align: center;
            vertical-align: middle;
        }
        th { 
            background-color: #f0f0f0; 
            font-weight: bold;
            font-size: 10px;
        }
        .num-col { width: 30px; }
        .nome-col { width: 180px; text-align: left; padding-left:8px !important; }
        .nota-col { width: 40px; }
        .media-col { width: 45px; font-weight: bold; }
        .status-col { width: 70px; }
        .assinaturas {
            margin-top: 40px;
            display: flex;
            justify-content: space-between;
        }
        .assinatura {
            width: 40%;
            text-align: center;
            border-top: 1px solid #000;
            padding-top: 5px;
            font-size: 11px;
        }
        .legenda {
            margin-top: 20px;
            font-size: 9px;
            line-height: 1.6;
            border-top: 1px solid #ccc;
            padding-top: 10px;
        }
        @media print {
            .no-print { display: none; }
            body { padding: 0; }
        }
    </style>
</head>
<body>
    <div class="no-print" style="text-align:center; margin-bottom:15px; padding:10px; background:#f0f0f0;">
        <button onclick="window.print()" style="padding:10px 20px; background:#0D47A1; color:white; border:none; cursor:pointer; font-size:14px;">🖨️ Imprimir Pauta</button>
        <a href="pauta_geral.php" style="margin-left:10px; padding:10px 20px; background:#666; color:white; text-decoration:none;">← Voltar</a>
    </div>

    <div class="header-instituicao">
        <img src="logo.png" alt="Logo" style="max-width:70px;" onerror="this.style.display='none'">
        <h1>THE YOUNG WISE SCHOOL</h1>
        <h2>CENTRO DE FORMAÇÃO</h2>
    </div>

    <div class="titulo-pauta">PAUTA DE AVALIAÇÕES - <?= strtoupper(htmlspecialchars($nome_turma)) ?></div>
    <div class="info-turma">
        Ano Lectivo: <?= date('Y') ?> | Nível: <?= $alunos[0]['nome_nivel'] ?? '' ?> | Total de Alunos: <?= count($alunos) ?>
    </div>

    <?php if (empty($alunos)): ?>
        <p style="text-align:center; padding:30px;">Nenhum aluno encontrado nesta turma.</p>
    <?php else: ?>
        
        <!-- TABELA 1: AVALIAÇÕES ESCRITAS -->
        <?php 
        gerar_tabela(
            'Avaliações Escritas',
            ['A1 Escr.', 'A2 Escr.', 'A3 Escr.', 'A4 Escr.'],
            $alunos,
            $notas_por_aluno,
            'avaliacao_escrita',
            4
        );
        ?>

        <!-- TABELA 2: AVALIAÇÕES ORAIS -->
        <?php 
        gerar_tabela(
            'Avaliações Orais',
            ['A1 Oral', 'A2 Oral', 'A3 Oral', 'A4 Oral'],
            $alunos,
            $notas_por_aluno,
            'avaliacao_oral',
            4
        );
        ?>

        <!-- TABELA 3: DITADOS -->
        <?php 
        gerar_tabela(
            'Ditados',
            ['Ditado 1', 'Ditado 2', 'Ditado 3', 'Ditado 4'],
            $alunos,
            $notas_por_aluno,
            'ditado',
            4
        );
        ?>

        <!-- TABELA 4: EXAME ESCRITO -->
        <h3 style='background:#0D47A1; color:white; padding:8px 12px; margin:20px 0 10px 0; font-size:14px; text-transform:uppercase; letter-spacing:1px;'>📋 Exame Escrito</h3>
        <table>
            <thead>
                <tr>
                    <th class="num-col">Nº</th>
                    <th class="nome-col">Nome do Aluno</th>
                    <th>Nota</th>
                    <th class="status-col">Obs.</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $num = 1;
                foreach ($alunos as $aluno): 
                    $notas = $notas_por_aluno[$aluno['id']] ?? [];
                    $nota_exame = 0;
                    foreach ($notas as $n) {
                        if ($n['tipo_avaliacao'] === 'exame_escrito') {
                            $nota_exame = $n['nota'];
                            break;
                        }
                    }
                    $status = $nota_exame >= 75 ? 'Aprovado' : ($nota_exame > 0 ? 'Reprovado' : '-');
                    $cor = $nota_exame >= 75 ? '#2E7D32' : ($nota_exame > 0 ? '#D32F2F' : '#666');
                ?>
                <tr>
                    <td class="num-col"><?= str_pad($num++, 2, '0', STR_PAD_LEFT) ?></td>
                    <td class="nome-col"><strong><?= htmlspecialchars($aluno['nome']) ?></strong></td>
                    <td class="nota-col"><?= $nota_exame > 0 ? $nota_exame : '-' ?></td>
                    <td class="status-col" style="color:<?= $cor ?>; font-weight:bold;"><?= $status ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <!-- TABELA 5: EXAME ORAL -->
        <h3 style='background:#0D47A1; color:white; padding:8px 12px; margin:20px 0 10px 0; font-size:14px; text-transform:uppercase; letter-spacing:1px;'>📋 Exame Oral</h3>
        <table>
            <thead>
                <tr>
                    <th class="num-col">Nº</th>
                    <th class="nome-col">Nome do Aluno</th>
                    <th>Nota (%)</th>
                    <th class="status-col">Obs.</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $num = 1;
                foreach ($alunos as $aluno): 
                    $notas = $notas_por_aluno[$aluno['id']] ?? [];
                    $nota_exame = 0;
                    foreach ($notas as $n) {
                        if ($n['tipo_avaliacao'] === 'exame_oral') {
                            $nota_exame = $n['nota'];
                            break;
                        }
                    }
                    $status = $nota_exame >= 50 ? 'Aprovado' : ($nota_exame > 0 ? 'Reprovado' : '-');
                    $cor = $nota_exame >= 50 ? '#2E7D32' : ($nota_exame > 0 ? '#D32F2F' : '#666');
                ?>
                <tr>
                    <td class="num-col"><?= str_pad($num++, 2, '0', STR_PAD_LEFT) ?></td>
                    <td class="nome-col"><strong><?= htmlspecialchars($aluno['nome']) ?></strong></td>
                    <td class="nota-col"><?= $nota_exame > 0 ? $nota_exame . '%' : '-' ?></td>
                    <td class="status-col" style="color:<?= $cor ?>; font-weight:bold;"><?= $status ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

    <?php endif; ?>

    <div class="legenda">
        <strong>Legenda:</strong><br>
        • Avaliações Escritas e Orais: Nota máxima 30 valores | Critério de aprovação: Média ≥ 10 valores<br>
        • Ditados: Nota máxima 30 valores | Critério de aprovação: Média ≥ 10 valores<br>
        • Exame Escrito: Nota máxima 150 valores | Critério de aprovação: ≥ 75 valores (50%)<br>
        • Exame Oral: Nota máxima 100% | Critério de aprovação: ≥ 50%<br>
        • Obs.: Aprovado (verde) | Reprovado (vermelho) | - (sem nota registrada)
    </div>

    <div class="assinaturas">
        <div class="assinatura">
            <br>
            <strong>Professor(a) Responsável</strong><br>
            Assinatura: _______________________
        </div>
        <div class="assinatura">
            <br>
            <strong>Coordenação Pedagógica</strong><br>
            Assinatura: _______________________
        </div>
    </div>

    <p style="text-align:center; font-size:9px; margin-top:20px; color:#666;">
        Documento gerado em <?= date('d/m/Y H:i') ?> pelo Sistema YWS - The Young Wise School
    </p>
</body>
</html>